module.exports = {
  //publicPath:'./',
  //baseUrl: '/',
  // devServer: {
  //   //proxy: 'http://172.27.74.25/',
  // },
  // devServer: {
  //   proxy: { 
  //     "/Docs": {
  //       target: "http://localhost:8080/",
  //       pathRewrite: {
  //         "^/Docs": "/Docs"
  //       }
  //     }
  //   }
  // },
	transpileDependencies: [
        'vuex-persist', 
      'vue2-dropzone', 
    //'vue-bootstrap-typeahead',
      'vue-json-csv',
      'webpackBootstrap'
     
    ],
    // configureWebpack: {
    //     resolve: {
    //       alias: {
    //         querystring: 'querystring-browser'
    //       }
    //     }
    // }
  }