/* eslint-disable spaced-comment */

import Vue from 'vue';
import Vuex from 'vuex';
Vue.use(Vuex);
import axiosAuth from '../axios-auth';
import axios from 'axios';
import router from '../router/AllRoutes';
//import { stat } from 'fs';
export const store = new Vuex.Store({
  state:
  {
    ServiceID: null,
    Mainmenu: "",
    RefreshToken: null,
    AccessToken:null,
    UserID : null,
    BuildMenu:false,
    menuToggle:false,
    DentalServiceID:132,
    MedicalServiceID:42234,
    OpticalServiceID:734211,
    HearingServiceID:941331,
    PodiatryServiceID:4513434,
    DefaultServiceID:0,
    DPEBBServiceID:6,
    faq: "DpebbFaq",
    ContactUs: "DpebbContactus",
    PWDminLen: 12,
    ReturnUrl: "",
    AllApplevel:false,
    DateFormat:'yyyy/MM/dd',
    message:'',
    ShowLoginMsg:false
    },
    mutations: {
    
    },
    getters: {
    
    },
    actions: {
     
    }
});
