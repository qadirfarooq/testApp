
//import "@babel/polyfill";
import Vue from "vue";
import App from "./App.vue";
//require("@babel/polyfill");
//require("es6-symbol/implement");
import "core-js/stable";
import "regenerator-runtime/runtime";
import 'babel-polyfill';
//import "@babel/polyfill";
import Es6Promise from "es6-promise";
import router from "./router/AllRoutes";
import axios from "axios";
import {store} from "./Store/store";
import VueRadioToggleButtons from 'vue-radio-toggle-buttons';
import 'vue-radio-toggle-buttons/dist/vue-radio-toggle-buttons.css';
import IdleVue from "idle-vue";
import 'url-search-params-polyfill';
axios.defaults.baseURL = "http://localhost:7923";
import vueDropzone from "vue2-dropzone";
Vue.component('vue-dropzone', vueDropzone); 
import ToggleButton from 'vue-js-toggle-button'; 
import moment from 'moment';
import {ServerTable, ClientTable, Event} from 'vue-tables-2';

import "./Css/app.css";
import "./Css/Site.css";
import BootstrapVue from "bootstrap-vue"; 
import "bootstrap-vue/dist/bootstrap-vue.css";
import {BModal} from "bootstrap-vue/esm/components/modal/modal";
import { BCollapse } from 'bootstrap-vue'; 
import {BModalDirective} from 'bootstrap-vue/esm/directives/modal/modal';
import VueBootstrapTypeahead from 'vue-bootstrap-typeahead';
import { VueSpinners } from '@saeris/vue-spinners';
Vue.use(BootstrapVue);
const eventsHub = new Vue();
Vue.use(IdleVue, {
  eventEmitter: eventsHub,
  store,
  idleTime: 900000 , // 15 mint // 3000, // 3 seconds
  startAtIdle: false
});
//Vue.use(require('vue-moment'));
//Vue.use(VueLazyload);
Vue.use(ClientTable, [], false, 'bootstrap4', 'default');
Vue.component("b-modal", BModal);
Vue.component('b-collapse', BCollapse); 
Vue.component('vue-bootstrap-typeahead', VueBootstrapTypeahead);
Vue.use(VueSpinners);
Vue.use(VueRadioToggleButtons);
Vue.directive("b-modal", {BModalDirective});
Vue.use(ToggleButton); 
var _ = require('lodash');
Es6Promise.polyfill();
require('es6-promise/auto');
Vue.config.productionTip = false;
new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app');

axios.interceptors.response.use((response) => {
  return response;
}, function (error) {
  if (error.response.status === 401) {
      //console.log('unauthorized, logging out ...');
      store.state.message = "Your session has expired. Please Login again to restore your session.";
      store.state.ShowLoginMsg = true;
      store.dispatch('Logout');
  }
  return Promise.reject(error.response);
});

