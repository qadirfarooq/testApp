<template>
    <div>
    <b-modal id="modal-sm" size="md" title="Confirm Message" v-model="ShowMsg" no-close-on-esc no-close-on-backdrop hide-header-close>
    <div slot="default">
    <div class='alert alert-danger' role='alert' > {{errorMsg}} <br>  </div>
    <!-- <div class='alert alert-danger' role='alert' > Your session has expired. please Login again to restore your session. <br>  </div> -->

    </div> 
    <div slot="modal-footer" class="w-100">
    <p class="float-left" variant="primary"></p>
    <b-button variant="primary"  size="md"  class="float-right" @click="HideMsg"> Close </b-button>
    </div>
    </b-modal>
    <b-modal id="modal-sm" size="md" v-model="loading" no-close-on-esc no-close-on-backdrop hide-header-close hide-footer>
        <div slot="default">
        <div class='alert alert-danger' role='alert' > Logging in with your credentials, please wait.... <br>  </div>

        <!-- Auth :{{IsAuth}} -->
        <!-- <bar-loader class="custom-class" :color="color" :loading="loading" :size="size" :sizeUnit="unit"></bar-loader>  -->
        <div class="text-center justify-content-center row col-12">
            <ring-loader class="text-center justify-content-center" :color="color" :loading="loading" :size="Ringsize" :sizeUnit="unit"></ring-loader> 
            <rise-loader class="text-center justify-content-center" :color="color" :loading="loading" :size="Risesize" :sizeUnit="unit"></rise-loader> 
            <ring-loader class="text-center justify-content-center" :color="color" :loading="loading" :size="Ringsize" :sizeUnit="unit"></ring-loader> 
          
        </div>          
        <!-- <div class='alert alert-danger' role='alert' > Your session has expired. please Login again to restore your session. <br>  </div> -->
        </div>  
    </b-modal>
    <span class="Maintitle">
    <i class="fas fa-clinic-medical"></i>
    <strong></strong>
    </span>
    <hr>
  <hr><hr>
    <div >
    <strong>Please Note:</strong>
    <hr><hr>
   </div>
    <!-- un check if you want this card in center  <div class="card card-login mx-auto text-center row justify-content-center" > -->
<div class="card card-login  text-center justify-content-center" > 
    <div class="card-header" data-my-theme="saskGreen" >
        <span class="logo_title">  </span>
    </div>
    <div class="card-body mx-auto" >
        <div  class="mx-auto   justify-content-center">
        <div class="input-group form-group">
            <div class="input-group-prepend">
            <span class="input-group-text"><i class="fas fa-user"></i></span>
            </div>
            <input type="text" name="uid" v-model="uid" id="uid" class="form-control" placeholder="Username" required autofocus />
        </div>
        <div  class="col-sm-4 mb-2 mt-0"   v-show="$v.uid.$error">
            <div class="row">
            <small class="sml-red" v-if="!$v.uid.required">User name is required.</small>
            <small class="sml-red" v-if="!$v.uid.minLength">Invalid User Name.</small> 
            <small class="sml-red" v-if="!$v.uid.maxLength">Invalid User Name.</small>
            </div>
        </div> 
        <div class="input-group form-group">
            <div class="input-group-prepend">
                <span class="input-group-text"><i class="fas fa-key"></i></span>
            </div>
            <input type="password" name="password" v-model ="password" id="password" class="form-control" placeholder="Password">
        </div>
        <div  class="col-sm-4 mb-0"   v-show="$v.password.$error">
            <div class="row">
            <small class="sml-red" v-if="!$v.password.required">Password is required.</small>
            <small class="sml-red" v-if="!$v.password.minLength">Invalid password.</small> 
            <!-- <small class="sml-red" v-if="!$v.passwor.numeric">must be a number.</small> -->
            </div>
        </div> 
        <div :key="MessageKey" class="col-md-12 mb-2 mt-0">
            <small class="sml-red">{{errorMsg}}</small>
        </div>
        <div class="col-md-6 offset-md-2">
            <!-- <input  v-on:click="SaskApi" :disabled="counter>0" type="button" class="btn btn-primary login_btn" value="Login" /> -->
            <input  v-on:click="SaskApi"  type="button" class="btn btn-primary login_btn" value="Login" />
        </div> 

        </div> 
    </div>
</div>
</div>
</template>
<script>
import axios from 'axios'
import axiosauth from '@/axios-auth'
import Vue from 'vue'; 
import Vuelidate from 'vuelidate'
import LoginLayout from '@/Common/Default/LoginLayout.vue';
import { mapGetters } from 'vuex'; 
import { RingLoader } from '@saeris/vue-spinners';
import { RiseLoader } from '@saeris/vue-spinners';
import {required,minLength,sameAs, not, maxLength} from 'vuelidate/lib/validators'
Vue.use(Vuelidate);
export default  {
     props:{
        error:''
     }, //['ServiceID','msg', 'MenuArray','error'],
  data: function () {
      
    return {
        PWDminLength:'', 
        counter: 0,
        loading: false,
        size: 150,
        Ringsize: 30,
        Risesize: 12,
        margin :'2px',
        unit: 'px',
        color:'#bada55',
        msg:'',
        uid:'',
        password: '',
        newpassword: '', 
        refresh_token: '',
        MessageKey:0,
        //ShowMsg:false
        }
    },
    components:{ 
        RingLoader,
        RiseLoader
    }, 
    mounted: function () {
    this.$nextTick(function () {  
    })
    },
    created: function() { 
        this.PWDminLength= this.$store.getters.GetPwdMinLength; 
        this.$emit('update:layout', LoginLayout);
       
    },
    computed:{
        ...mapGetters({
                GetMessage: 'GetMessage',
                ShowLoginMsg: 'ShowLoginMsg'
            }),
        errorMsg: {
           get(){
             return this.GetMessage
           },
           set(newName){
             return newName
           } 
        },


        ...mapGetters({
                 
                ShowLoginMsg: 'ShowLoginMsg'
            }),
        ShowMsg: {
           get(){
             return this.ShowLoginMsg
           },
           set(val){
             return val
           } 
        },
      IsAuth : function()
        { 
          return this.$store.getters.IsAuth;
        },
    },
    watch: {
    ShowMsg: function (val) { 
        if(val)
        {
            //this.showMsg1("Seesion","","Con")
        }
    },
    IsAuth : function(val)
    { 
        console.log('is auth' + val)
        if(val)
        {
            this.loading = false;
        }
    },
    },
    methods: {
    HideMsg: function(val){
        this.$store.dispatch('ResetLoginMSg');
        this.$bvModal.hide('modal-sm');
        },
    showMsg1(msg,data,Title) {
        this.boxTwo = ''
        this.$bvModal.msgBoxOk(msg, {
        title: Title,
        size: 'md',
        buttonSize: 'md',
        okVariant: 'primary',          
        okTitle: 'Close', 
        footerClass: 'p-2',
        hideHeaderClose: true,
        hideHeaderCancel: true,
        centered: true, 
        });
           
      },
        SaskApi: function () {
            this.$v.$touch();
            if (!this.$v.$invalid){
                localStorage.refresh_token = "";
                localStorage.isAuth = false;
                localStorage.Expires = "";
                localStorage.issued = "";
                localStorage.access_token = "";
                localStorage.refresh_token = "";
                localStorage.token_type = "";
                localStorage.ServiceUrl = "";
                localStorage.IsAssessor = false;
                this.counter++;
                var vm = this;
                var mainmenu = [];
                var accessToken;
                localStorage.isAuth = false;
                var params = new URLSearchParams();
                params.append('grant_type', 'password');
                params.append('username', this.uid);
                params.append('password', this.password); 
                params.append('client_Id', 'sdfsdafa');	
                params.append('client_Secret', 'sdasdf'); 
                this.$store.dispatch('Login',params);
               
                if(this.counter >0)
                vm.loading =true;
            }
        },
    },
    validations(){
        return { 
            uid:{
               required,
               minLength: minLength(7),
               maxLength: maxLength(15),
            },
            password:{
                required,
                minLength: minLength(this.PWDminLength),
            }
        }
     },
}
</script>
<style scoped>
[data-my-theme="green"] {
background-color: #4caf50;
}
.card {
border: 1px solid #28a745;
width: 100%;

}
.card-login {
    margin-top:  5px;
    max-width: 40rem;
}
.card-header {
        color: #fff;
    /*background: #634911;
    font-family: sans-serif;*/
    font-size: 20px;
    font-weight: 600 !important;
    margin-top: 0px;
    border-bottom: 0;
}

.input-group-prepend span{
    width: 50px;
    /* background-color: #ff0000;
    color: #fff; */
    border:0 !important;
}

input:focus{
    outline: 0 0 0 0  !important;
    box-shadow: 0 0 0 0 !important;
}

.login_btn{
    width: 150px;
    align-content:inherit;
}
.form-control {
    display: block;
    width: 80%;
    height: calc(2.25rem + 2px);
    padding: 0.375rem 0.75rem;
    font-size: 1.2rem;
    line-height: 1.6;
    color: #28a745;
    background-color:#fff;
    background-clip: padding-box;
    border: 1px solid #28a745;
    border-radius: 0;
    transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
}

.input-group-text {
    display: -ms-flexbox;
    display: flex;
    -ms-flex-align: center;
    align-items: center;
    padding: 0.375rem 0.75rem;
    margin-bottom: 0;
    font-size: 1.5rem;
    font-weight: 700;
    line-height: 1.6;
    color: #495057;
    text-align: center;
    white-space: nowrap;
    background-color: #e9ecef;
    border: 1px solid #ced4da;
    border-radius: 0;
}
</style>

