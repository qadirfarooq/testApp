<template>
<div id='HSNNote'> 
<div class="row Maintitle"> 
    <div class="col-sm-8 my-0" >
        <div class="row">
       <span class="col-sm-4"><h4><small class="text-muted">
         <b>{{AppName}} </b></small></h4> 
         </span>  
        <span class="col-sm-4"><h4><small class="text-muted">
        <i class="fas fa-user-injured"></i><b>HSN: {{HSN}}</b></small></h4> 
         </span> 
         </div>   
    </div>
    <div class="col-sm-4 mt-1">
        <button v-on:click="ClosePopup" type="button" class="btn BtnClose btn-sml float-right"><i class="fas fa-times"></i> Close  </button>
    </div>
</div>

<v-client-table :columns="columns" :data="tableData" :options="options" class="mt-2"> 
</v-client-table>  

</div>
</template>
<script>
import moment from 'moment'
import { PopUpVariant } from '@/Common/Default/PopUpVariant';
import axios from 'axios'
export default {
    props:{
      PropHSN:'',
      AppName:'',
      NoteType:null
    },
     data: function(){
        return {
        Patient:null,
        //AppName: 'Dental Application',
        AppIcon: 'fas fa-tooth',
        HSN:'',
        showModal:false,
        isValid:false,
        Access:'',
       // NoteType:'1',
        AllowAdd:false,
        showEditModal:false,
        PopUpVar:PopUpVariant,
        Button:'',
        columns: ['notes','createddate','createdby',
        'updateddate', 'lastUpdatedby'],
        tableData: [],
        options: {
        texts:{
              count:"Showing {from} to {to} of {count} records|{count} records|One record",
              first:'First',
              last:'Name',
              limit:"Records:",
              page:"Page:",
              filter:"",
              filterPlaceholder:"Search Notes",
              noResults:"No matching records",
              filterBy:"Filter by {column}",
              loading:'Loading...',
              defaultOption:'Select {column}',
              columns:'Columns'
          },        
          responseAdapter({data}) {           
              return {
                data: formatData,
                count: data.length
              };             
            },         
          perPage:10,
          perPageValues:[10,15,25],
          dateColumns:['effectivedate','expirydate'],
          toMomentFormat: 'YYYY-MM-DD',         
          templates: {
            createddate(h, row){
              return moment(row.createddate, "YYYY-MM-DD").format('YYYY/MM/DD'); 
            },
            updateddate(h, row) {
              return moment(row.updateddate, "YYYY-MM-DD").format('YYYY/MM/DD'); 
            }
            },
          headings: {
            notes: 'Notes',
            createddate: 'Note Date',
            createdby: 'Created By',
            updateddate: 'Updated Date',
            lastUpdatedby: 'Update By', 
          },
          pagination: {
            edge: true,
            nav: 'scroll',
            chunk: 5
          },
        sortable: ['createdby','hsn','name','notes','createddate', 'updateddate', 'lastUpdatedby'],
        filterable: ['hsn','name','notes','createddate','createdby', 'updateddate', 'lastUpdatedby'], 
        sortIcon: {
                base : 'fas',
                is: 'fa-sort',
                up: 'fa-sort-up',
                down: 'fa-sort-down'
                },
        }
        }
     },
       
    components: {

    },
    filters: {
          moment: function (date) {
          return moment(date,"YYYY-MM-DD").format('YYYY/MM/DD');
          }
     },
    created: function(){
      this.HSN=this.PropHSN;
    },
    mounted: function () {
     this.$nextTick(function () { 
       this.loadTable();
      })
    },
    computed:{ 
    },
    methods: { 
      ClosePopup: function() {     
          this.$root.$emit('bv::hide::modal', 'modal-HSN-Cov', '#btnShow') 
      },
      loadTable(){ 
      var vm = this;
        var params = new URLSearchParams();
      params.append('HSN', this.HSN);
      params.append('Type', this.NoteType);
      params.append('Top10', true);
      axios.get('SaskHealthApi/Claims/GetPatientNotes?_='+Date.now(), { headers: { 'Authorization': 'Bearer ' + localStorage.access_token },params})
        .then(function (response) {
              vm.tableData=response.data; 
          })
          .catch(function (er) {
              console.log(er)
          });
      },  
      disableSearch(){
          this.tableData = [];
          this.isValid = false;
      }
     } 
}


</script>

<style>

</style>
