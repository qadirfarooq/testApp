<template>
<div id="PatientEligibilityRequest">
<b-modal id="modal-sm"  size="md" title="Patient Eligibility" v-model="showModal" no-close-on-esc no-close-on-backdrop hide-header-close>
<div slot="default">
    <div class='alert alert-warning' role='alert'> {{Msg}}   </div>
</div> 
<div slot="modal-footer" class="w-100">
    <p class="float-left" variant="primary"></p>
    <b-button variant="primary"  size="md"  class="float-right"  @click="PEExit"> Close </b-button>
</div>
</b-modal>

 <Subtitle  v-bind:ServiceID="this.AppServiceID">
   <template v-slot:header>
    <i class="fab fa-delicious"></i><b>Patient Eligibility:</b>
  </template> 
</Subtitle>


<!-- <h4><small class="text-muted"><i class="fas fa-user-shield"></i><b>Patient Eligibility Request:</b></small></h4>   -->
<form class="card  p-0 mb-1">
  <div class="card-header d-flex align-items-center  pl-1" style="height: 1rem; text-align:left;">
        <h5><small class="text-muted"><b><i class="fas fa-search-plus"></i>Search: HSN required (all others optional)</b></small></h5>
  </div>
  <div class="form-row p-1">
    <div class="form-group col-sm-1">
      <label for="inputEmail4" class="label-small">HSN</label>
       <input id="UserID" @input="HSNtextChanged" v-model="HSN" maxlength="9" class="form-control form-control-xs">

     <div class="row" v-show="$v.HSN.$error">           
        <div class="col-sm-12">
            <small class="sml-red" v-if="!$v.HSN.required">HSN is required.</small>
        </div>
      </div>
      <div class="row" v-show="$v.HSN.$error">           
        <div class="col-sm-12">
           <small class="sml-red" v-if="!$v.HSN.minLength">Minimum 9 digit required.</small>
        </div>
      </div>
      <div class="row" v-show="$v.HSN.$error">           
        <div class="col-sm-12">
           <small class="sml-red" v-if="!$v.HSN.numeric">HSN must be a number.</small>
        </div>
      </div>


    </div>
    <div class="form-group col-sm-1">
      <label for="inputPassword4" class="label-small">Service Date</label>
      <div> 
        <datepicker class="servdatapick" typeable :open-date="new Date()" :disabledDates="{ from: new Date(Date.now() +1) }" v-model="servicedate" 
            :format="DateFormat" id="effDate" :bootstrap-styling="true" :input-class="datapickClass" name="serviceDatepicker"></datepicker>                        
      </div>
       <div  class="row" v-show="$v.servicedate.$error">
        <div class="col-sm-12">     
            <small class="sml-red" v-if="!$v.servicedate.required">Date is required.</small> 
                       
       </div>
        <div class="col-sm-12"> 
            <small class="sml-red" v-if="!$v.servicedate.maxValue">Must not be future date.</small>
       </div>     
       </div>
    </div>
    <div class="form-group col-sm-3">
      <label for="inputPassword4" class="label-small">Service Code</label>
      <div >
        <vue-bootstrap-typeahead ref="SCRef" :inputClass="TypeHeadinptClass"  v-model="servicecode" @input="SCtextChanged" :data="ServiceCodes"  @hit="SelectedCode = $event; searched=false"
            :serializer="item => item.servicedesc"  textVariant=".text-info"   placeholder="Search Service Code"  size="sm"  backgroundVariant="bg-light" :maxMatches="20" >
            <template slot="prepend">
              <span class="input-group-text m-0 p-1 form-control-xs" style="font-size: .6rem;"><i class="fas fa-search fa-sm"></i></span>
            </template>                      
        </vue-bootstrap-typeahead>
      </div>
    </div>
    <div class="form-group col-sm-3" v-if="isAssessor">
      <label for="inputEmail4" class="label-small">{{locname}}:</label>
      <div >
        <vue-bootstrap-typeahead  :inputClass="TypeHeadinptClass"   autocomplete="off" @input="ClinictextChanged" id="clinicSel" ref="clinicRef" v-model="clinicno" :data="Clinic"
          @hit="selectedClinic = $event; searched=false" :serializer="item => item.clinicname"
          textVariant=".text-primary" :placeholder=locname size="sm" backgroundVariant="bg-light"
          :maxMatches="20" updateOn='blur' >
          <template slot="prepend">
            <span class="input-group-text m-0 p-1 form-control-xs" style="font-size: .6rem;"><i class="fas fa-search fa-sm"></i></span>
          </template>
        </vue-bootstrap-typeahead>
      </div>

      <div class="row mb-1" v-show="$v.selectedClinic.$error">
        <div class="col-sm-4"></div>
        <div class="col-sm-8">
            <small class="sml-red" v-if="!$v.selectedClinic.needValue">Clinic Info is required.</small>
        </div>
      </div>

    </div>
    <div class="form-group col-sm-3">
      <label for="inputPassword4" class="label-small">Provider Name:</label> 
      <div>
        <vue-bootstrap-typeahead id="provSel" :disabled ="DisbleProvider" :inputClass="TypeHeadinptClass"  ref="providerRef" @input="ProvidertextChanged" v-model="providernum" :data="providers"
        @hit="selectedProvider = $event; searched=false" :serializer="item => item.providername"
        textVariant=".text-primary" placeholder="Search Providers" size="sm" backgroundVariant="bg-light"
        :maxMatches="20">
        <template slot="prepend">
          <span class="input-group-text m-0 p-1 form-control-xs" style="font-size: .6rem;"><i class="fas fa-search fa-sm"></i></span>
        </template>
        </vue-bootstrap-typeahead>
      </div>
 
    </div>
    <div class="form-group col-sm-1">
      <label for="inputPassword4" class="label-small">  </label>
              <div class=" ">
              <button v-on:click="GetHsnInfo" type="button" class="btn btn-primary btn-sml mt-1"> Search </button>
            </div>
    </div>
  </div> 
  </form>

 <div  class="row no-gutters"> 
  <div class="col-4 pr-1" >
        <div class="card" v-if="Patient!=null" >
            <div class="card-header d-flex align-items-center  pl-1" style="height: 2rem; text-align:left;">
              <h5><small class="text-muted"><b><i class="fas fa-user-injured"></i>Patient: {{Patient.firstName}} {{Patient.lastName}} </b></small></h5>
            </div>
           <div  class="card-body p-2">
                    <div class="row" >
                      <span for="cname" class="col-sm-3 label-small"><b>HSN:</b></span> 
                      <span   class="col-sm-9 form-control-xs" type="text">{{Patient.hsn}}</span> 
                    </div>
                    <div class="row">
                      <span for="cname" class="col-sm-3 label-small"><b>Address:</b></span> 
                      <span class="col-sm-9 form-control-xs" type="text"> {{Patient.address1}}  {{Patient.address2}} </span> 
                    </div>
                    <div class="row">
                      <span for="cname" class="col-sm-3 label-small"><b>DOB:</b></span> 
                      <span class="col-sm-9 form-control-xs" type="text">{{Patient.birthDay |moment(Patient.birthDay) }} </span> 
                    </div> 
           </div>
        </div>
   </div> 

  <div class="col-4 pr-1" v-if="(selectedClinic != null)  && Patient!=null">
        <div class="card">
        <div class="card-header   d-flex align-items-center  pl-1" style="height: 2rem; text-align:left;">
          <h5><small class="text-muted"><b><i class="fas fa-clinic-medical"></i>Clinic: {{selectedClinic.clinicname}}</b></small></h5>
        </div>

         <div  class="card-body p-2" v-if="Clinic.length"> 
                    <div class="row">
                      <span for="cname" class="col-sm-3 label-small pr-0"><b>Clinic #:</b></span> 
                      <span class="col-sm-9 form-control-xs" type="text">{{selectedClinic.clinicno}}</span> 
                    </div>
                    <div class="row">
                      <span for="cname" class="col-sm-3 label-small pr-0"><b>Address:</b></span> 
                      <span class="col-sm-9 form-control-xs" type="text">{{selectedClinic.address}}</span> 
                    </div>
                    <div class="row">
                      <span for="cname" class="col-sm-3 label-small pr-0"><b>City:</b></span> 
                      <span class="col-sm-9 form-control-xs" type="text">{{selectedClinic.city}}</span> 
                    </div> 
          </div>
        
        </div>
    </div>       
   <div class="col-4 pr-1" v-if="(selectedProvider != '00000000' && selectedProvider !=null) && isAssessor && Patient!=null">
        <div class="card">
        <div class="card-header   d-flex align-items-center  pl-1" style="height: 2rem; text-align:left;">
          <h5><small class="text-muted"><b><i class="fas fa-clinic-medical"></i>Provider: {{selectedProvider.providername}}</b></small></h5>
        </div>

         <div  class="card-body p-2" v-if="Clinic.length"> 
                    <div class="row">
                      <span for="cname" class="col-sm-3 label-small pr-0"><b>Provider #:</b></span> 
                      <span class="col-sm-9 form-control-xs" type="text">{{selectedProvider.providerno}}</span> 
                    </div>
                    <div class="row">
                      <span for="cname" class="col-sm-3 label-small pr-0"><b>Address:</b></span> 
                      <span class="col-sm-9 form-control-xs" type="text">{{selectedProvider.address}}</span> 
                    </div>
                    <div class="row">
                      <span for="cname" class="col-sm-3 label-small pr-0"><b>City:</b></span> 
                      <span class="col-sm-9 form-control-xs" type="text">{{selectedProvider.city}}</span> 
                    </div> 
          </div>
        
        </div>
    </div>  
 </div>
 <div v-if="errorCode =='0000' ||errorCode =='0001'" class="card-header" style="padding:5px; !important"> <i class="fas fa-book-medical"></i>Supplementary Health Benefits: <b> {{SupInd}}</b></div>
 
 
  
 <!-- <h5 v-if="errorCode !='0000' ||errorCode !='0001'"><small class="Maintitle mt-1"><b><i class="fas fa-book-medical"></i>Supplementary Health Benefits:  {{SupInd}}</b></small></h5> -->
 
      <div class="mt-2" v-if="searched">            
        <v-client-table :columns="columns" :data="PatEligList" :options="options">  
          <div slot="afterFilter">
              <div class="ml-2"><br><b>Note:</b> Table Below Shows Service Date for Claims and Expiry Date for Prior Approvals.</div>
          </div>
        </v-client-table> 
      </div>  	    

</div>  <!-- PatientEligibilityRequest end --> 

</template>

<script>
import {mapGetters} from 'vuex'
import moment from 'moment'
import axios from 'axios' 
import Datepicker from 'vuejs-datepicker';
import LayoutDefault from '@/Common/Default/DefaultLayout.vue'; 
import Subtitle from '@/Common/Default/SubTitle.vue'; 
import Card from "@/Common/Card.vue";
import CardBody from "@/Common/CardBody.vue";
import TileNote from "@/Common/TileNote.vue";
import Vuelidate from 'vuelidate'
import { helpers } from 'vuelidate/lib/validators'
import { required, minLength, maxLength, between,withParams,email,numeric} from 'vuelidate/lib/validators'
import { PopUpVariant } from '@/Common/Default/PopUpVariant';
import { request } from 'http';
import { type } from 'os';
export default  {
   props:{
      Type:''
    },
  // name: 'DentalHome',
  data: function () {
    return {
        DisbleProvider: false,
        errorCode:'',
        SupInd :'',        
        locname:'Clinic Name ',
        TypeHeadinptClass:'form-control form-control-xs',
        AppServiceID:'',
        selectedProvider:null,
        HSN:'',
        servicedate: '',
        servicecode: null,
        providernum:null,
        DateFormat:'',
        datapickClass:"form-control form-control-xs my-0",
        Clinic: [],
        clinicno: null,
        Services: '',
        PatEligList: [],
        Patient: null,
        PopUpVar:PopUpVariant,
        showModal:false,
        isAssessor:false, 
        selectedClinic:null, 
        Msg:'',
        providers:[],
        ServiceCodes:[],
        SelectedCode:null,
        indicator:'',
        AppName:'',
        AppIcon:'',
        type:'',
        searched:false,
        columns: ['claimpriorapproval','servicedate','servicecode','servicecodedesc', 'clinicno','clinicname','providerno','providername'],
        options: {
        texts:{
              count:"Showing {from} to {to} of {count} records|{count} records|One record",
              first:'First',
              last:'Last',
              //filter:"Search Service Code:",
              //filterPlaceholder:"Search Service Code",
              limit:"Records:",
              page:"Page:",
              noResults:"No Patient Eligibility Records Found",
              filterBy:"Filter by {column}",
              loading:'Loading...',
              defaultOption:'Select {column}',
              columns:'Columns'
          },
          responseAdapter({data}) {
            // const formatData = data.map(o => {
            //     const dataCopy = JSON.parse(JSON.stringify(o))
            //     dataCopy.expirydate = moment(o.expirydate).format('MMMM Do YYYY')
            //     return dataCopy
            //   })
              return {
                data: formatData,
                count: data.length
              };
              // return {
              //   data,
              //   count: data.length
              // }
            },
          perPage:10,
          perPageValues:[10,15,25],
          dateColumns:['servicedate'],
          //toMomentFormat: 'YYYY/MM/DD',
          //templates: {edit: 'edit'},
          templates: {
            servicedate(h, row) {
             // moment.locale('es'); 
             if(row.claimpriorapproval == 'CL')              
              return  moment(row.servicedate,"YYYY-MM-DD").format('YYYY/MM/DD') + " (Service Date)";  
            else            
              return  moment(row.servicedate,"YYYY-MM-DD").format('YYYY/MM/DD') + " (Expiry Date)";  
            },
            description(h, row) {
                           
              return   <div style="font-size: 70%">{row.description}</div> 
            },
            claimpriorapproval(h, row){
              return row.claimpriorapproval == 'CL'?'Claim':'Prior Approval';
            }, 
          },
          headings: {
            claimpriorapproval: "Claim Type",
            status: "Status",     
             servicedate: 'Date',
            servicecode: 'Service Code',
            servicecodedesc:  'Description', 
            clinicno: 'Clinic/Supplier #',
            providerno: 'Provider #',
            clinicname : 'Clinic Name'
          },
          pagination: {
            edge: true,
            nav: 'scroll',
            chunk: 5
          },
           sortable: ['claimpriorapproval','status','servicedate','servicecode'],
          // filterable: ['username', 'fullname', 'clinicname', 'role' ,'status'],
          sortIcon: {
                  base : 'fas',
                  is: 'fa-sort',
                  up: 'fa-sort-up',
                  down: 'fa-sort-down'
                  },
          },

        }
    },
    components: { 
            Card,
            CardBody,
            TileNote ,
            Datepicker,
            Subtitle            

        },
     filters: {
          moment: function (date) {
          return moment(date,"YYYY-MM-DD").format('YYYY/MM/DD');
          },
          stringify(value) {
          return JSON.stringify(value, null, 2)
          }  
        }, 
    methods: {
     HSNtextChanged(){
        if(this.HSN == null || this.HSN.length < 9){
          this.Patient = null;
          this.searched = false;
          this.errorCode='';
        }
     },
      CheckProvider(){
         this.selectedProvider = this.providers.find(x=>x.providerno == this.providernum);
      },
      ClinictextChanged(){
        if(this.clinicno == ''){
          this.selectedClinic = null;
          this.searched = false;
        }
      },
      ProvidertextChanged(){
        if(this.providernum == ''){
          this.selectedProvider = null;
          this.searched = false;
        }
      
      },
      SCtextChanged(){
        if(this.servicecode == ''){
          this.SelectedCode = null;
          this.searched = false;
        }
  
      },
         GetHsnInfo(){
            this.$v.$touch();
          // console.log(this.selectedClinic);
          if (!this.$v.$invalid){
                var url = 'SaskHealthApi/Host/GetHsnInq';
                var params = new URLSearchParams();
                params.append('HSN', this.HSN);
                if(vm.ViewNotesCoverage)
                url ='SaskHealthApi/Host/GetHsnInqLead';
                axios.get(url, { headers: { 'Authorization': 'Bearer ' + localStorage.access_token },params})
                .then(function (response) { 
                   
                    vm.Patient =response.data;                    
                    vm.loadTable(); 
                })
            .catch(function (er) {
              console.log("hsn");
                console.log(er);
                   vm.PatEligList = [];
                   vm.Patient = null;
              if(er.status ==400)
                {
                  console.log('here')
                  vm.showModal = true;
                  vm.Msg = er.data.message; 
                }
                else if(er.status == 500)
                {
                    vm.showModal = true;                
                    if(er.data.message !=null)
                      vm.Msg = er.data.message;
                    else
                    vm.Msg = "Network Related Error !" 
                }
            })
          }
        },
        GetServiceType(){
          
           var vm = this;
           var params = new URLSearchParams();            
           params.append('ServiceID', this.AppServiceID);
            axios.get('SaskHealthApi/Codes/GetServiceType?_='+Date.now(), { headers: { 'Authorization': 'Bearer ' + localStorage.access_token }, params})
            .then(function (response) {
                vm.Services=response.data;
                })
            .catch(function (er) {

                console.log(er)
                
                })
        },
        loadTable(){
          var vm = this;
         vm.SupInd='';
         vm.errorCode = '';
          vm.PatEligList =[];
          this.$v.$touch();
          if (!this.$v.$invalid){
          var params = new URLSearchParams();
            params.append('HSN', this.HSN);
            params.append('providernum',  this.selectedProvider == null?'0000000000':this.selectedProvider.providerno);
            params.append('servicedate', moment(this.servicedate,"YYYY-MM-DD").format('YYYYMMDD'));
            params.append('servicetype', this.Services);
            params.append('servicecode', this.SelectedCode==null?'0000000000':this.SelectedCode.servicecode);
            params.append('clinicno', this.selectedClinic==null?'00000':this.selectedClinic.clinicno);
            params.append('tooth1', '00'),
            params.append('tooth2', '00')
             axios.get('SaskHealthApi/Host/GetPatientEligInq', { headers: { 'Authorization': 'Bearer ' + localStorage.access_token },params})
             .then(function (response) {
                    // console.log(response);   
                    vm.errorCode = response.data.errorCode;
                    vm.SupInd = response.data.supindicator;
                    console.log("error Code = " + vm.errorCode);  
                    if(vm.errorCode =="0000")
                    {
                       vm.searched = false;
                        vm.showModal = true;
                        //console.log('at 000 ') 
                        vm.Msg = response.data.errorDetail; 
                    }
                    if(vm.errorCode =="0001")
                    {
                       vm.searched = true;
                      console.log(' Length = ' + response.data.patientEligibilityRows.length)
                      if(response.data.patientEligibilityRows.length>0)
                       vm.PatEligList=response.data.patientEligibilityRows; 
                    }       
                    if(!vm.isAssessor)
                    { 
                        vm.columns =  ['claimpriorapproval','servicedate','servicecode','servicecodedesc'];
                    } 
                })
            .catch(function (er) {
                vm.PatEligList = [];
                vm.Patient = null;
                if(er.status ==400)
                {
                   vm.searched = false;
                  vm.showModal = true;
                  console.log('here') 
                  vm.Msg = er.data.message; 
                }
                else if(er.status == 500)
                {  
                   vm.searched = false;
                    vm.showModal = true;
                    if(er.data.message !=null)
                      vm.Msg = er.data.message;
                    else
                    vm.Msg = "Network Related Error !" 
                } 
            })
          }
        },
       
        GetUserClinics(){
           var vm = this; 
           var params = new URLSearchParams();
          params.append('ServiceID', this.AppServiceID);
            axios.get('/SaskHealthApi/Codes/GetUserClinic', { headers: { 'Authorization': 'Bearer ' + localStorage.access_token }, params})
                .then(function (response) {
                    vm.Clinic = response.data;
                    if(!vm.isAssessor){
                      vm.selectedClinic= vm.Clinic[0];
                      vm.clinicno = vm.Clinic[0].clinicno.toString();
                    }

                    console.log(vm.selectedClinic);
                })
            .catch(function (er) {
                console.log(er)
            })   
        },
        GetProviders(){
          var vm = this;
          var params = new URLSearchParams();
          params.append('ServiceID', this.AppServiceID);
          axios.get('SaskHealthApi/Codes/GetProvidersByService', { headers: { 'Authorization': 'Bearer ' + localStorage.access_token },params})
            .then(function (response) {
              vm.providers = response.data;
            })
          .catch(function (er) {
            console.log(er)
        }).then(function()
          { 
            vm.DisbleProvider = false;     
            if(vm.AppServiceID ==4)
            {
                vm.selectedProvider=  {"providerno":"9999999998","providername":"PSEUDO HEARING","address":"3475 ALBERT ST","city":"Regina","province":"SK","service":"Hearing","subtype":"Hearing AUD"};
                vm.$refs.providerRef.inputValue = vm.selectedProvider.providername;
            } 
            else if(vm.AppServiceID ==2)
            {
              
              vm.DisbleProvider = true;
               // vm.selectedProvider=  {"providerno":"9999999998","providername":"PSEUDO HEARING","address":"3475 ALBERT ST","city":"Regina","province":"SK","service":"Hearing","subtype":"Hearing AUD"};
                //vm.$refs.providerRef.inputValue = vm.selectedProvider.providername;
                vm.selectedProvider=  { "providerno": vm.providers[0].providerno, "providername": vm.providers[0].providername, "address": vm.providers[0].address, "city": vm.providers[0].city, "province": vm.providers[0].province, "service": vm.providers[0].service, "subtype": vm.providers[0].subtype , "orgid": vm.providers[0].orgid};
                vm.$refs.providerRef.inputValue = vm.selectedProvider.providername;
            } 
            else
            {
              vm.DisbleProvider = false;
            }
          })
    },
    GetServiceCodes(){ 
      var vm = this;
      var params = new URLSearchParams();
        params.append('ServiceID', this.AppServiceID);
        axios.get('SaskHealthApi/Codes/GetServiceCode', { headers: { 'Authorization': 'Bearer ' + localStorage.access_token },params})
        .then(function (response) {
              //console.log(response.data);
              vm.ServiceCodes =response.data; 
              //console.log(vm.ServiceCodes)
          })
      .catch(function (er) {
          console.log(er)
      })

      },
      ClearSearch(){
        this.HSN = '';
        this.Patient = null;
        this.servicedate=moment(new Date()).format('YYYY/MM/DD');        
        
        if(this.$refs.providerRef !=undefined)
          this.$refs.providerRef.inputValue = '';
       
       if(this.isAssessor){
          // this.clinicno = '';
           if(this.$refs.clinicRef !=undefined)
          this.$refs.clinicRef.inputValue = '';
        }
        if(this.$refs.SCRef !=undefined)
         this.$refs.SCRef.inputValue = '';
         
         this.SelectedCode = null;
         this.selectedProvider = null;
  
          this.PatEligList.splice(0, this.PatEligList.length);
        
      },
      PEExit(){
        this.showModal = false;
      },
      CheckAssessor(){
        var params = new URLSearchParams();
        var vm = this;
        axios.get('SaskHealthApi/Codes/IsAssessorOrSuper?_='+Date.now(), { headers: { 'Authorization': 'Bearer ' + localStorage.access_token },params})
        .then(function (response) {
            // console.log(response.data);
          vm.isAssessor = response.data;
            vm.GetUserClinics(); 
        }).catch(function (er) {
          console.log(er)
        });   
      },
      ValidClinic(){
       if(!this.isAssessor && this.selectedClinic == null || this.selectedClinic =='')
          return false;
       else{
          return true;
       }
      },
    },
    computed:{ 
    },
     created: function() { 
        this.AppServiceID = this.Type;
        if(this.AppServiceID==2)
        {
          this.locname = 'Supplier Name '
          this.options.headings = { 
            claimpriorapproval: "Claim Type",
            servicedate: 'Date',
            servicecode: 'Service Code',
            servicecodedesc:  'Description', 
            clinicno: 'Supplier No',
            providerno: 'Provider #',
            providername: 'Provider Name',
            clinicname : 'Supplier Name' 
          }
        }
        else{
          this.locname = 'Clinic Name '
          this.options.headings = { 
            claimpriorapproval: "Claim Type",         
             servicedate: 'Date',
            servicecode: 'Service Code',
            servicecodedesc:  'Description', 
            clinicno: 'Clinic #',
            providerno: 'Provider #',
            providername: 'Provider Name',
            clinicname : 'Clinic Name' 
          }          
        }   
        //console.log ('ServiceId:' + this.AppServiceID)     
        this.DateFormat = this.$store.getters.GetDateFormat;           
        this.servicedate=moment(new Date()).format('YYYY/MM/DD');   
        this.GetServiceCodes();
        this.GetServiceType();
        this.GetProviders();
        this.CheckAssessor();              
        
    },
    validations(){
    return {
        HSN:{//more validation required
            required,
            numeric,
            minLength:minLength(9),
        },
        servicedate:{
          required,// new Date(Date.now() +1)
          maxValue: value => (moment(this.servicedate)).toISOString() <=  moment().startOf('day').toISOString(), 
        },
        selectedClinic : {
         needValue: value=>  this.ValidClinic(), 
        }, 
      }
    }
    }
    


</script>

<style scopped>
 .row.no-gutter [class*='col-']   {
   padding-right:1px;
   
 }
 .list-group-item {
    position: relative;
    display: block;
    padding: 0px 15px;
    margin-bottom: -1px;
    border: 1px solid #ddd;
    background-color: blue;
    line-height: 1em
}
/* remove right padding from first column */
/* .row.no-gutter [class*='col-']:first-child {
  padding-right:5px;
} */
/* remove left padding from first column */
/* .row.no-gutter [class*='col-']:last-child {
  padding-left:5px;
} */


/* only for column content visible */
.col-lg-1>div {background-color:#ddd;}

#docimg {
   
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50; 
  /* margin-top: 10px; */
}
#line {
  border-top:1px solid   rgba(7, 14, 109, 0.25);
  /* border-bottom:1px solid #c00;
  border-bottom: 1px solid rgba(255,255,255,.25); */
}
 
 #PatientEligibility .form-control {
    display: block;
    width: 80%;
    height: calc(2.25rem + 2px);
    padding: 0.375rem 0.75rem;
    font-size: .3rem;
    line-height: 1.6;
    color: #28a745;
    background-color:#fff;
    background-clip: padding-box;
    border: 1px solid #28a745;
    border-radius: 0;
    transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
}
</style>