<template>
<div>
<Subtitle  v-bind:ServiceID="this.AppServiceID">
   <template v-slot:header>
    <i class="fas fa-cogs"></i><b>New Claim:</b>
  </template> 
</Subtitle>
<b-modal id="modal-sm"  size="md" title="New Claim Error!" v-model="showError" no-close-on-esc no-close-on-backdrop hide-header-close>
<div slot="default">
    <div class='alert alert-warning' role='alert'> {{MsgPopup}} </div>
</div> 
<div slot="modal-footer" class="w-100">
    <p class="float-left" variant="primary"></p>
    <b-button variant="primary"  size="md"  class="float-right"  @click="ClosePopup"> Close </b-button>
</div>
</b-modal>
<b-modal id="modal-HSN-Cov" size="lg" v-model="showNotesCov" centered   no-close-on-esc no-close-on-backdrop hide-header-close
    ok-variant cancel-variant hide-footer
      header-class="PopUpHeader" 
      :header-text-variant=PopUpVar.headerTextVariant
      :body-bg-variant=PopUpVar.bodyBgVariant
      :body-text-variant=PopUpVar.bodyTextVariant
      :footer-bg-variant=PopUpVar.footerBgVariant
      :footer-text-variant=PopUpVar.footerTextVariant> 
    <template slot="modal-header"  > 
      <div  style="margin: 0 auto;">
        <small class="PopUpTitle w-100 text-center"> {{popupTitle}}</small>
      </div> 
    </template>
     <PAShowHSNInfo v-if="GetNotes" v-bind:PropHSN="this.HSN" v-bind:NoteType="this.AppServiceID" v-bind:AppName="this.AppName"></PAShowHSNInfo>
     <PAShowCoverageInfo  v-if="!GetNotes" v-bind:PropHSN="this.HSN" v-bind:AppName="this.AppName"></PAShowCoverageInfo>
   
</b-modal> 
<b-modal id="modal-PA"  v-model="showModal" centered   no-close-on-esc no-close-on-backdrop hide-header-close
    ok-variant cancel-variant hide-footer
      header-class="PopUpHeader" 
      :header-text-variant=PopUpVar.headerTextVariant
      :body-bg-variant=PopUpVar.bodyBgVariant
      :body-text-variant=PopUpVar.bodyTextVariant
      :footer-bg-variant=PopUpVar.footerBgVariant
      :footer-text-variant=PopUpVar.footerTextVariant> 
    <template slot="modal-header" > 
      <div  style="margin: 0 auto;">
        <small class="PopUpTitle w-100 text-center"> {{PopAddEditTitle}}</small>
      </div> 
    </template>
    <PAAddEdit v-bind:ClaimInfo="this.ClaimInfo" v-bind:ServiceID="this.AppServiceID" v-bind:ServiceCodeInfo="this.ServiceCodeInfo" v-if="showModal" @ServiceCodeDone="AddEditDone"></PAAddEdit>
  
</b-modal>
<div id="ClaimRequest" v-if="ClaimRequestNo==null" class="mb-5">

 <form class="card  p-0 mb-1" id="SearchForm">
  <div class="card-header d-flex align-items-center  pl-1" style="height: 1rem; text-align:left;">
        <h5><small class="text-muted"><b><i class="fas fa-search-plus"></i>Search: HSN and Provider (Required)</b></small></h5>
  </div>
  <div class="form-row p-1">
    <div class="form-group col-sm-3">
      <label for="NewHSN" class="label-small">HSN</label>
       <input id="NewHSN" ref="NewHSN" v-model="HSN" placeholder="HSN" maxlength="9" class="form-control form-control-xs">
 
      <div class="row" v-show="$v.HSN.$error">           
        <div class="col-sm-12">
            <small class="sml-red" v-if="!$v.HSN.required">HSN is required.</small>
        </div>
      </div>
      <div class="row" v-show="$v.HSN.$error">           
        <div class="col-sm-12">
           <small class="sml-red" v-if="!$v.HSN.minLength">Minimum 9 digit required.</small>
        </div>
      </div>
      <div class="row" v-show="$v.HSN.$error">           
        <div class="col-sm-12">
           <small class="sml-red" v-if="!$v.HSN.numeric">HSN must be a number.</small>
        </div>
      </div>



    </div>
  
    <div class="form-group col-sm-4" v-if="ViewNotesCoverage==true">
      <label for="inputEmail4" class="label-small">Clinic Name:</label>
      <div>
          <vue-bootstrap-typeahead ref="SearchClinic" @input="ClinicChange" :inputClass="TypeHeadinptClass"  v-model="ClinicNo"  :data="Clinic"  @hit="SelectedClinic = $event"
          :serializer="item => item.clinicname"  textVariant=".text-primary"   placeholder="Search Clinic"  size="sm"  backgroundVariant="bg-light" :maxMatches="20" >
          <template slot="prepend">
          <span class="input-group-text form-control-xs" style="font-size: .7rem;"><i class="fas fa-search fa-sm"></i></span>
          </template>                      
          </vue-bootstrap-typeahead> 
      </div>
       <div class="row mb-1" v-show="$v.SelectedClinic.$error">  
        <div class="col-sm-12">
            <small class="sml-red " v-if="!$v.SelectedClinic.required">Clinic info is required.</small>
        </div>
      </div>
 
    </div>
    <div class="form-group col-sm-4">
      <label for="inputPassword4" class="label-small">Provider Name:</label>
       <div class="">
          <vue-bootstrap-typeahead ref="SearchProvider" :disabled ="DisbleProvider" @input="ProviderChange" :inputClass="TypeHeadinptClass"  v-model="ProviderNo"  :data="Provider"  @hit="selectedProvider = $event"
          :serializer="item => item.providername"  textVariant=".text-primary"   placeholder="Search Provider"  size="sm"  backgroundVariant="bg-light" :maxMatches="20" >
          <template slot="prepend">
          <span class="input-group-text form-control-xs" style="font-size: .7rem;"><i class="fas fa-search fa-sm"></i></span>
          </template>                      
          </vue-bootstrap-typeahead> 
        </div>
 
       <div class="row" v-show="$v.selectedProvider.$error">
        <div class="col-sm-12"></div>        
            <small class="sml-red ml-3" v-if="!$v.selectedProvider.required">Provider info is required.</small>
       </div>

    </div>
    <div class="form-group col-sm-1">
      <label for="inputPassword4" class="label-small">  </label>
      <div class=" ">
      <button v-on:click="GetHsnInfo" type="button" class="btn btn-primary btn-sml mt-1"> Search </button>
      </div>
    </div> 
  </div> 
</form> 
 <div  class="row no-gutters mt-2">
    <div class="col-4 pr-1" v-if="Showinfo" >
        <div class="card" v-if="Patient!=null && (HSN!='' || HSN!=null)" >
            <div class="card-header   d-flex align-items-center  pl-1" style="height: 2rem; text-align:left;">
            <h5><small class="text-muted"><b><i class="fas fa-user-injured"></i>Patient: {{Patient.firstName}} {{Patient.lastName}}  </b></small></h5>
            </div>
              <div  class="card-body p-2 mb-2">
                    <div class="row" >
                      <span for="cname" class="col-sm-4"><b>HSN:</b></span> 
                      <span   class="col-sm-8" type="text">{{HSN}}</span> 
                    </div>
                    <div class="row">
                      <span for="cname" class="col-sm-4"><b>Address:</b></span> 
                      <span class="col-sm-8" type="text">{{Patient.address1}} {{Patient.address2}}</span> 
                    </div>
                    <div class="row pb-1">
                      <span for="cname" class="col-sm-4"><b>DOB:</b></span> 
                      <span class="col-sm-8" type="text">{{Patient.birthDay|moment}} </span> 
                    </div> 
              </div>
        </div>
    </div>
     <div class="col-4 pr-1 " v-if="Showinfo && SelectedClinic !=null">
      <div class="card" >
          <div class="card-header   d-flex align-items-center  pl-1" style="height: 2rem; text-align:left;">
          <h5><small class="text-muted"><b><i class="fas fa-clinic-medical"></i>Clinic: {{SelectedClinic.clinicname}}</b></small></h5>
          </div>
            <div  class="card-body p-2 mb-2" v-if="Clinic.length"> 
              <div class="row">
                <span for="cname" class="col-sm-4"><b>Clinic #:</b></span> 
                <span class="col-sm-8" type="text">{{SelectedClinic.clinicno}}</span> 
              </div>
              <div class="row">
                <span for="cname" class="col-sm-4"><b>Address:</b></span> 
                <span class="col-sm-8" type="text">{{SelectedClinic.address}}</span> 
              </div>
              <div class="row pb-1">
                <span for="cname" class="col-sm-4"><b>City:</b></span> 
                <span class="col-sm-8" type="text">{{SelectedClinic.city}}</span> 
              </div> 
          </div>        
      </div>
    </div> 
    <div class="col-4 pr-1" v-if="Showinfo">
        <div class="card" v-if="selectedProvider!=null">
            <div class="card-header   d-flex align-items-center  pl-1" style="height: 2rem; text-align:left;">
            <h5><small class="text-muted"><b> <i class="fab fa-product-hunt"></i>Provider: {{selectedProvider.providername}}</b></small></h5>
            </div>
               <div  class="card-body p-2">
                    <div class="row" >
                      <span for="cname" class="col-sm-4"><b>Provider #:</b></span> 
                      <span   class="col-sm-8" type="text">{{selectedProvider.providerno}}</span> 
                    </div>
                     <div class="row mb-1" >
                      <span for="cname" class="col-sm-4"><b>Service Type:</b></span> 
                      <span   class="col-sm-8" type="text">{{selectedProvider.subtype}}</span> 
                    </div> 
                    <div class="row">
                      <div class="col-sm-6">
                       <button  type="button"   class="btn btn-primary btn-sml float-left" v-on:click="AddEditPopup">  Start New Claim  </button>
                   
                      </div>
                      <div class="col-sm-6"> 
                        <!-- <button  type="button"   class="btn btn-primary btn-sml float-right" v-on:click="AddEditPopup">  Start Prior Approval  </button> -->
                      </div>
                    </div> 
              </div>
        </div> 
    </div> 
</div> 
</div> 
<div id="PriorApprovalForm" v-if="!(ClaimRequestNo==null)" class="mb-5">
  <div class="row no-gutters"> 
    <div class="col-4 pr-1" v-if="Patient!=null">
      <div class="card">
        <div class="card-header d-flex align-items-center" style="height: 2rem; margin:0;padding:0 !important;">
          <h5>
            <small class="text-muted pl-1" style="text-align:left;"><b><i class="fas fa-user-injured"></i>Patient: {{Patient.firstName}} {{Patient.lastName}}</b>
            </small>
          </h5>  
        </div> 
        <div  class="card-body p-2 mb-0" v-if="Patient!=null">
          <div class="row" >
            <span for="cname" class="col-sm-4"><b>HSN:</b></span> 
            <span   class="col-sm-8" type="text">{{HSN}}</span> 
          </div>
          <div class="row">
            <span for="cname" class="col-sm-4"><b>Address:</b></span> 
            <span class="col-sm-8" type="text">{{Patient.address1}} {{Patient.address2}}</span> 
          </div>
          <div class="row">
            <span for="cname" class="col-sm-4"><b>DOB:</b></span> 
            <span class="col-sm-8" type="text">{{Patient.birthDay|moment}} </span> 
          </div>   
        </div>
        <div v-if="ViewNotesCoverage==true" class="row m-0 p-0 card-header d-flex align-items-center"  style="height: 2rem; margin:0;padding:0 !important;">
            <div class="col-6 float-left"  style="margin:0;padding:0 important!;">
              <h6><span class="text-muted pointer float-left" v-on:click="GetNotesCoverage(true)"><i class="fas fa-user-md" ></i><i class="fab fa-neos" style="margin:0;padding:0 important!;"></i>otes </span></h6>
            </div>
            <div class="col-6 mt-1 float-right" style="margin:0;padding:0 important!;">
              <h6 class="float-right text-muted"><span style="margin:0;padding:0 important!; text-align:right;" class="pointer d-flex align-items-center" v-on:click="GetNotesCoverage(false)"><i class="far fa-id-card pr-1" style="margin:0;padding:0 important!;"></i>
              <span class="cov">C</span>overage
              </span></h6>
            </div>              
        </div>
      </div>
    </div>
    <div class="col-4 pr-1" v-if="SelectedClinic !=null">
      <div class="card">
        <div class="card-header   d-flex align-items-center  pl-1" style="height: 2rem; text-align:left;">
          <h5><small class="text-muted"><b><i class="fas fa-clinic-medical"></i>Clinic: {{SelectedClinic.clinicname}}</b></small></h5>
        </div>
        <div  class="card-body p-2 mb-0" v-if="Clinic.length"> 
          <div class="row">
            <span for="cname" class="col-sm-4"><b>Clinic #:</b></span> 
            <span class="col-sm-8" type="text">{{SelectedClinic.clinicno}}</span> 
          </div>
          <div class="row">
            <span for="cname" class="col-sm-4"><b>Address:</b></span> 
            <span class="col-sm-8" type="text">{{SelectedClinic.address}}</span> 
          </div>
          <div class="row">
            <span for="cname" class="col-sm-4"><b>City:</b></span> 
            <span class="col-sm-8" type="text">{{SelectedClinic.city}}</span> 
          </div> 
        </div> 
        <div v-if="ViewNotesCoverage==true" class="card-header   d-flex align-items-center  pl-1" style="height: 2rem; text-align:left;">
          <h5><small class="text-muted"><b></b></small></h5>
        </div> 
      </div>
    </div> 
    <div class="col-4 pr-1" v-if="selectedProvider!=null">
        <div class="card">
          <div class="card-header   d-flex align-items-center  pl-1" style="height: 2rem; text-align:left;">
            <h5><small class="text-muted"><b> <i class="far fa-file-powerpoint"></i>Provider: {{selectedProvider.providername}}</b></small></h5>
          </div>
          <div  class="card-body p-2 " v-if="Clinic.length">
              <div class="row" >
                <span for="cname" class="col-sm-4"><b>Provider #:</b></span> 
                <span   class="col-sm-8" type="text">{{selectedProvider.providerno}}</span> 
              </div>
              <div class="row" >
                <span for="cname" class="col-sm-4"><b>Service:</b></span> 
                <span   class="col-sm-8" type="text">{{selectedProvider.service}}</span> 
              </div>
              <div class="row" >
                <span for="cname" class="col-sm-4"><b>Service Type:</b></span> 
                <span   class="col-sm-8" type="text">{{selectedProvider.subtype}}</span> 
              </div>    
          </div>
          <div v-if="ViewNotesCoverage==true" class="card-header   d-flex align-items-center  pl-1" style="height: 2rem; text-align:left;">
          <h5><small class="text-muted"><b></b></small></h5>
          </div>
        </div> 
        </div> 
  </div>
   
  <div id="ServiceCodeGrid" class="mt-2"> 
        <v-client-table :columns="columns" :data="SourceCodeData" :options="options"  ref="table">
        <div slot="beforeFilter"  class="VueTables_Adduser  mr-3">
            <label for="VueTables_Adduser" class="VueTables_user mr-3"> New Service Code: </label>
              <button type="button" :disabled="(SelectedClaimStatus.id==4 || SelectedClaimStatus.id==1) ? true : false" v-on:click="AddEditPopup('','A')" class="btn btn-primary ">ADD SERVICE CODE</button>
        </div>
        <template slot="ovdstatusid" slot-scope="props">  
          <select id="override" v-bind:value="props.row.ovdstatusid"    @change="ChangeServiceStatus($event,props.row.servicecodeid)"  class="form-control form-control-sm select-css" :style="getErrorStyle(props.row.errorcode)">  
            <option v-for="option in ServiceStatus" v-bind:value="option.id"  :key="option.id">
            <strong>{{option.text}} </strong>
            </option> 
          </select>
        </template>  
        <template slot="status" slot-scope="props">
          <span  class="bd-highlight">{{props.row.status}}</span>
        </template>
        <template slot="errorcode" slot-scope="props">
          <span class="pointer"  :class="getMsgClass(props.row.errorcode)"   v-on:click="GetMsg(props.row.errorcode)"><i class="fas fa-comment-medical"></i>{{props.row.errorcode}}</span>
        </template>
        <span class="pointer"  v-on:click="AddEditPopup(props.row,'E')" slot="edit" slot-scope="props" ><i class="far fa-edit"></i></span>
        <span class="pointer" v-on:click="showMsgBox('Are you sure you want to delete this service code?',props.row,1,null)" slot="delete" slot-scope="props" ><i class="far fa-trash-alt"></i></span>
        </v-client-table> 
    </div>  
  
  <div class="card" id="PAFormUploadStatus">
  <div class="row mt-2 no-gutters">
      <div class="col-6">
        <div class=" mr-1">
        <div class="card-header   d-flex align-items-center  pl-1" style="height: 2rem; text-align:left;">
          <h5><small class="text-muted"><b><i class="fas fa-thumbs-up"></i>Claim Form:</b></small></h5>
        </div>
        <form>
          <div class="p-2 pb-0 mb-0" > 
            <div class="form-group row my-1">               
              <label for="ClaimNotes" class="col-sm-5 label-small">Notes</label>
              <div class="col-sm-7"> 
                <textarea wrap="on" rows="2" class="my-0 form-control  text-area-xs"  id="ClaimNotes"   min="1" max="300" v-model="ClaimNotes"  placeholder="ClaimNotes" ></textarea>     
              </div>                 
            </div>
            <div class="form-group row my-1">               
                  <label for="lab" class="col-sm-5 label-small">Service Date:</label>
                  <div class="col-sm-4">      
                    <div><datepicker :open-date="new Date()"  :disabledDates="{ from: new Date(Date.now() +1) }" v-model="ServiceDate" :format="dateFormat" id="SevDate" :bootstrap-styling="true" :input-class="datapickClass" name="expirydatepicker"></datepicker> </div>
                  </div>
                  <div  class='col-sm-3 mb-0' v-show="$v.ServiceDate.$error"  >
                    <div class="row">
                      <small class="sml-red" v-if="(!$v.ServiceDate.required)">Service Date Required</small>
                    </div>
                    <div class="row">
                      <small class="sml-red" v-if="(!$v.ServiceDate.MaxValue)">Future date not allowed</small>
                    </div>
                  </div>  
            </div>
            <div class="form-group row my-1">               
                  <label for="lab" class="col-sm-5 label-small">Lab Name:</label>
                  <div class="col-sm-4">      
                    <input id="lab" type="text" min="1" max="50" v-model="LabName"  placeholder="Lab Name" class=" my-0 form-control form-control-xs">
                  </div>
                  <div  class='col-sm-3 mb-0'   >
                    <div class="row">
                      <small class="sml-red"></small>
                      </div>
                  </div>               
            </div>

            <div class="form-group row my-0">
                  <label  class="col-sm-5 label-small">1st Payer Paid Amount (if applicable):</label>
                  <div class="col-sm-4">      
                    <toggle-button :disabled="PaidYN" v-model="PaidByThirdParty" :switch-color="{checked: '#FBDD40', unchecked: 'linear-gradient(#046A38, #FBDD40)'}" :value="false" color="#41B6E6" :sync="true" :labels="{checked: 'YES', unchecked: 'NO'}"/>
                  </div>
                  <div  class='col-sm-3 mb-0'   >
                    <div class="row">
                      <small class="sml-red"></small>
                      </div>
                  </div>               
            </div>

            <div class="form-group row my-0">
                  <label  class="col-sm-5 label-small">Temporary Health Certificate (THC):</label>
                  <div class="col-sm-3">      
                    <toggle-button :disabled="THCYN" v-model="TempTHC" :switch-color="{checked: '#FBDD40', unchecked: 'linear-gradient(#046A38, #FBDD40)'}" :value="false" color="#41B6E6" :sync="true" :labels="{checked: 'YES', unchecked: 'NO'}"/>
                  </div>
                  <div  class='col-sm-4 mb-0'   >
                    <div class="form-group row" v-show="$v.HaveDoc.$error" >
                      <small class="sml-red"  v-if="(!$v.HaveDoc.DocUploaded)">THC certificate must be uploaded. </small> 
                    </div>
                  </div>               
            </div>
            <transition name="slide-fade"> 
            <div v-if="TempTHC">
              <div class="form-group row my-1" >               
                    <label for="eff" class="col-sm-5 label-small">THC Effective Date:</label>
                    <div class="col-sm-4">      
                      <datepicker  :selected="EffectiveChange()" :open-date="new Date()"  :disabledDates="{ from: new Date(Date.now() +1) }" v-model="THCEffectDate" :format="dateFormat" id="effDate" :bootstrap-styling="true" :input-class="datapickClass" name="expirydatepicker"></datepicker>
                    </div>
                    <div  class='col-sm-3 mb-0' v-show="$v.THCEffectDate.$error" >
                      <div class="row">
                        <small class="sml-red" v-if="(!$v.THCEffectDate.needValue)">  Effective Date is required.  </small>
                        </div>
                    </div>               
              </div>

              <div class="form-group row my-1">               
                    <label for="exp" class="col-sm-5 label-small">THC Expiry Date:</label>
                    <div class="col-sm-4">
                      <datepicker ref="ClearExpiryDate"  :disabled="disableExpiry"  :disabledDates="DisableToExpiry" v-model="THCExpiryDate" :format="dateFormat" id="expDate" :bootstrap-styling="true" :input-class="datapickClass" name="expirydatepicker"></datepicker>
                    </div>
                    <div  class='col-sm-3 mb-0'  v-show="$v.THCExpiryDate.$error"  >
                      <div class="row">
                        <small class="sml-red"  v-if="(!$v.THCExpiryDate.needValue)">Valid expiry date is required.</small>
                        </div>
                    </div>               
              </div> 
            </div>
             </transition> 
             <div class="form-group row my-0" v-if="ViewNotesCoverage==true">
                <label  class="col-sm-5 label-small">Reimburse to Patient:</label>
                <div class="col-sm-4">      
                  <toggle-button :disabled="ReimburseYN" v-model="ReimburseToPatient" :switch-color="{checked: '#FBDD40', unchecked: 'linear-gradient(#046A38, #FBDD40)'}" :value="false" color="#41B6E6" :sync="true" :labels="{checked: 'YES', unchecked: 'NO'}"/>
                </div>
                <div  class='col-sm-3 mb-0'   >
                  <div class="row">
                    <small class="sml-red"></small>
                  </div>
                </div>               
              </div> 
          </div>
        </form>
        </div>
      </div>
      <div class="col-6">
        <div class="">
        <div class="card-header   d-flex align-items-center  pl-1" style="height: 2rem; text-align:left;">
          <h5><small class="text-muted"><b><i class="fas fa-upload"></i> Upload Documents:</b></small></h5>
        </div>
        <div class=" p-2 pb-0 mb-0" >           
          <div class="form-group row">
                <label for="Qty" class="col-sm-10 label-small">Do you want to add documents:</label>
                <div class="col-sm-2">      
                   <toggle-button :disabled="DocYN" v-model="DocUpload" :switch-color="{checked: '#FBDD40', unchecked: 'linear-gradient(#046A38, #FBDD40)'}" :value="false" color="#41B6E6" :sync="true" :labels="{checked: 'YES', unchecked: 'NO'}"/>
                </div>                              
          </div>        
          <transition name="slide-fade">            
          <div v-if="DocUpload"  class="row mt-2" id="docimg" style="display: flex; justify-content: center;">
              <vue-upload-multiple-image :maxImage="10" :accept="ImageType" :popupText="popupText"  :primaryText="primaryText" :dragText="dragText" :browseText="browseText"
                @upload-success="uploadImageSuccess"
                @before-remove="beforeRemove"
                @edit-image="editImage"
                :data-images="images"
                idUpload="myIdUpload"
                editUpload="myIdEdit"
                ref="img"
                 ></vue-upload-multiple-image>
          </div>
           </transition>
        </div>
        </div>
      </div>    
  </div>
 <transition name="slide-fade" v-if="ViewNotesCoverage==true">     
  <div class="row mt-2 no-gutters PayeeForm" id="PatientPayeeForm"  v-if="ReimburseToPatient">
    <div class="col-12">
      <div class="card-header d-flex align-items-center  pl-1" style="height: 2rem; text-align:left;">
        <h5><small class="text-muted"><b><i class="fas fa-file-invoice-dollar" aria-hidden="true"></i>Patient Payee Form:</b></small></h5>
      </div>
      </div>
      <div class="col-6">
        <div class=" mr-1">     
       
          <div class="p-2 pb-0 mb-0" > 
            
            <div class="form-group row my-1">               
                  <label for="lab" class="col-sm-5 label-small">First Name:</label>
                  <div class="col-sm-4">      
                    <input id="lab" type="text" min="1" max="50" v-model="GivenName"  placeholder="First Name" class=" my-0 form-control form-control-xs">
                  </div>
                  <div  class='col-sm-3 mb-0'   v-show="$v.GivenName.$error" >
                    <div class="row">
                      <small class="sml-red" v-if="(!$v.GivenName.needValue)">First Name Required.</small>
                      <small class="sml-red" v-if="!$v.GivenName.alpha">Enter a valid name.</small>
                      </div>
                  </div>               
            </div>
       


             <div class="form-group row my-1">               
                  <label for="lab" class="col-sm-5 label-small">Address 1:</label>
                  <div class="col-sm-4">      
                    <input id="lab" type="text" min="1" max="50" v-model="Address1"  placeholder="Address 1" class=" my-0 form-control form-control-xs">
                  </div>
                  <div  class='col-sm-3 mb-0'   v-show="$v.Address1.$error" >
                    <div class="row">
                      <small class="sml-red" v-if="(!$v.Address1.needValue)">Address is Required.</small>
                      <small class="sml-red" v-if="(!$v.Address1.alphaNum)">Enter a valid Address.</small>
                      </div>
                  </div>              
            </div> 

            <div class="form-group row my-1">               
                  <label for="lab" class="col-sm-5 label-small">Postal Code:</label>
                  <div class="col-sm-4">      
                    <input id="lab" type="text" min="1" max="50" v-model="PostalCode"  placeholder="Postal Code" class=" my-0 form-control form-control-xs">
                  </div>
                  <div  class='col-sm-3 mb-0'   v-show="$v.PostalCode.$error" >
                    <div class="row">
                      <small class="sml-red" v-if="(!$v.PostalCode.needValue)">Postal Code is Required.</small>
                      <small class="sml-red" v-if="(!$v.PostalCode.postal)">Enter valid postal code.</small>
                      </div>
                  </div>                 
            </div>

          </div> 
        </div>
      </div>
      <div class="col-6">
          <div class="form-group row my-1">               
                  <label for="lab" class="col-sm-5 label-small">Last Name:</label>
                  <div class="col-sm-4">      
                    <input id="lab" type="text" min="1" max="50" v-model="SurName"  placeholder="Last Name" class=" my-0 form-control form-control-xs">
                  </div>
                  <div  class='col-sm-3 mb-0'   v-show="$v.SurName.$error" >
                    <div class="row">
                      <small class="sml-red" v-if="(!$v.SurName.needValue)">Last Name Required.</small>
                       <small class="sml-red" v-if="!$v.SurName.alpha">Enter a valid name.</small>
                      </div>
                  </div>                 
            </div>
             <div class="form-group row my-1">               
                  <label for="lab" class="col-sm-5 label-small">City:</label>
                  <div class="col-sm-4">      
                    <input id="lab" type="text" min="1" max="50" v-model="Address2"  placeholder="City" class=" my-0 form-control form-control-xs">
                  </div>
                  <div  class='col-sm-3 mb-0'   v-show="$v.Address2.$error" >
                    <div class="row">
                      <small class="sml-red" v-if="(!$v.Address2.needValue)">City is Required.</small>
                       <small class="sml-red" v-if="!$v.Address2.alpha">Enter a valid City.</small>
                      </div>
                  </div>                
            </div>
       

             <div class="form-group row my-1">               
                  <label for="lab" class="col-sm-5 label-small">Province:</label>
                  <div class="col-sm-4">      
                     <select  id="prov"   v-model="Province"  class="form-control form-control-sm"> 
                    <option v-for="option in Prov" v-bind:text="{text: option}" :key="option">
                    {{ option}}
                    </option> 
                    </select> 
                  </div>
                  <div  class='col-sm-3 mb-0'   v-show="$v.Prov.$error" >
                    <div class="row"> 
                      <small class="sml-red" v-if="(!$v.Prov.needValue)">Province is Required.</small> -->
                      </div>
                  </div>  

            </div>

 
      </div>    
  </div>
  </transition> 
  <div class="row  p-0  no-gutters card-header tile-note" id="ClaimStatus"> 
      <div class="col-6">         
          <div class="mr-1 p-1 pb-0 mb-0" >
            <div class="form-group row my-1"> 
              <div class="mt-1 col-1">
                <i class="fa fa-spinner fa-spin fa-fw"></i>
                <span class="sr-only">Loading...</span>              
              </div>
              <div class="col-4 float-left">                
                <h4>
                  <small class="text-muted ">
                    <i class="far fa-thumbs-up"><b> Claim Status:               
                    </b></i>                        
                  </small>
                </h4>
              </div> 
              <div class="col-sm-7 pl-3">      
                <select  id="Status"  :disabled="ClaimStatusDisable || TotalSc ==0" v-on:change="ChangeClaimStatus($event)"  v-model="SelectedClaimStatus"  class="form-control form-control-sm select-css"> 
                  <option v-for="option in ClaimStatus" v-bind:value="{id: option.id, text: option.text}" :key="option.id">
                  <strong>{{ option.text }}</strong>
                  </option> 
                </select>
              </div>                         
            </div>
          </div>         
      </div>  
      <div class="col-6">
         <!-- Current ID :{{ClaimStatusID}} / Selected Id: {{SelectedClaimStatus.id}}   -->
      </div>         
  </div>

   <transition name="slide-fade">  
    <div class="mt-1  no-gutters" v-if="SelectedClaimStatus.id==4">
    <div class="col-12 row  ">
        <div class="col-12 row no-gutter">
          <div class="col-3 mr-0" >
          <b class="pl-2">Manual Approval Notes:</b>
        </div>   
          <div class="col-sm-9 float-left no-gutters" style="padding:0rem;"> 
            <textarea wrap="on" rows="3" class="form-control  text-area-xs "  id="OverrideNotes"   min="1" max="500" v-model="OverRideNotes"  placeholder="Manual Approval Notes" ></textarea>     
          </div> 
        </div> 
      </div>
    <div class="col-12 row  ">
        <div class="col-12 row no-gutter">
          <div class="col-3 mr-0" >
          <b class="pl-2"></b>
        </div>   
          <div class="col-sm-9 float-left no-gutters" style="padding:0rem;"> 
           <small class="sml-red ml-0"  v-if="(!$v.OverRideNotes.needValue)">Approval notes are required.</small>
           </div>  
        </div> 
      </div>
    </div>
  </transition>
  
  <div class="row my-2 no-gutters">
    <div class="card-body p-1 pb-0 mb-0">  
      <div class="row mt-2">
        <div class="col-sm-4">
            <button v-on:click="SaveClaim"  type="button" class="btn btn-primary" :disabled="BtnSubmitdisabled"><i class="far fa-save"></i> Submit Claim </button>
        </div>
            
        <div class="col-sm-4">
            <button  v-on:click="ExitClaim"  type="button" class="btn btn-primary"><i class="far fa-times-circle"></i>  Exit Claim</button>
        </div>

        <div class="col-sm-4">
            <button v-on:click="GetErrDesc" type="button" class="btn btn-primary">  <i class="fas fa-print"></i> Print</button>
        </div>

      </div>
    </div> 
  </div>  
  </div>
 <!-- form upload status End -->  

  <!-- <i class="fab fa-buffer fa-2x"></i> -->    
</div><!-- Prior Approval PRocess End --> 
</div> 
</template>
<script>

import Vue from 'vue';
import {mapGetters} from 'vuex'
import moment from 'moment'
import axios from 'axios' 
import PAShowCoverageInfo from '@/components/Common/PAShowCoverageInfo.vue';
import PAShowHSNInfo from '@/components/Common/PAShowHSNInfo.vue';
import PAAddEdit from '@/components/Common/ClaimPAAddEdit.vue';
import Subtitle from '@/Common/Default/SubTitle.vue'; 
import LayoutDefault from '@/Common/Default/DefaultLayout.vue'; 
import Card from "@/Common/Card.vue";
import CardBody from "@/Common/CardBody.vue";
import TileNote from "@/Common/TileNote.vue";
import { PopUpVariant } from '@/Common/Default/PopUpVariant';
import { SKLogoString } from '@/Common/Default/SKLogo';
import { isNullOrUndefined } from 'util';
import VueUploadMultipleImage from 'vue-upload-multiple-image'; 
import Datepicker from 'vuejs-datepicker';
import Vuelidate from 'vuelidate'
import { helpers } from 'vuelidate/lib/validators'
import jsPDF from 'jspdf'   // used for GeneratePDF
import autoTable from 'jspdf-autotable'    // used for GeneratePDF
const SixvTwo = helpers.regex('SixvTwo', /^[0-9]{0,6}(\.[0-9]{1,2})?$/)
const OnevThree = helpers.regex('OnevThree',/^1{1}(\.[0]{1,3})?$|^0{0,1}(\.[0-9]{1,3})?$/)
const alpha = helpers.regex('alpha', /^[a-zA-Z]*$/)
const postal = helpers.regex('postal',  /^[A-Za-z]\d[A-Za-z][ -]?\d[A-Za-z]\d$/);
const alphaNum = helpers.regex('alphaNum', /^\d{1,5}\s\w*/)
const Panumber = helpers.regex('Panumber',  /^([0-9]{9})$/);
import { HomePaths } from '@/Common/Default/HomePaths';
Vue.use(Vuelidate)
import { required, minLength, maxLength, between,withParams,numeric} from 'vuelidate/lib/validators'
export default  {
  name: 'ServiceHome',
  props:{LeadAssessor:false,ServiceID :{required:true}},
  data: function () {
    return {
            ErrorDesc : [],  
            DisableToExpiry :{to: new Date(1900, 0, 26)},
            disableExpiry:true,
            TotalSc : 0,
            ReimburseYN :false,
            DocYN:false,
            PaidYN:false,
            THCYN:false,
            MsgPopup :'',
            showError: false,
            HomePath:'',
            HomePaths:HomePaths,
            ShowHomeBtn:false,
            ClaimStatusDisable:true,
            TypeHeadinptClass:'form-control form-control-xs',
            dis:true,
            Prov:['AB', 'BC', 'MB', 'NB', 'NL', 'NT', 'NS', 'NU', 'ON', 'PE', 'QC', 'SK', 'YT'],  
            ViewNotesCoverage:false,
            DisableStatus:false,
            DisbleProvider:true,
            LabName:'',
            PaidByThirdParty:false,
            TempTHC:false,
            THCEffectDate:'',
            THCExpiryDate:'',
            DocUpload:false,
            ServiceDate:'',
            ReimburseToPatient:false, 
            ClaimNotes:'',
            ClaimNotesAvailable:false,
            ThirdPartyPaidSign:"+",
            ThirdPartyPaidAmt:0,
            OverRideNotes:'',  
            PayeeHSN:null,
            GivenName:'',
            SurName:'',
            Address1:'',
            Address2:'',
            Province:'SK',
            PostalCode:'',        
            dateFormat : '',       
            CanOverRide:false,
            ClaimStatusID:'', 
            datapickClass:"form-control form-control-xs my-0", 
            AppName:'Medical Application:',
            GetNotes:false,
            showNotesCov:false,
            ImageType:'image/gif,image/jpeg,image/png,image/bmp,image/jpg,image/jp2,image/jpx,image/jpf',
            boxTwo: '',
            BtnSubmitdisabled:false,
            popupTitle:'Medical HSN Notes',
            PopAddEditTitle:'Add Service Code Form',
            popupText:'',        
            primaryText:'',
            PaidByThirdPArty:false,
            dragText:'Upload X-Rays and Documents',
            browseText:'Click Here',
            AppServiceID :0,
            MaxMatch:20, 
            selectedProvider: null,
            title:"Medical Supply Application",
            subtitle: "Welcome", 
            HSN:'',
            ProviderNo:'',
            Showinfo : false,
            Provider:[{'providerno': 1000, 'providername': 'test'}],
            Clinic: [],
            ClinicNo:'',
            SelectedClinic:null,
            images: [],
            SourceCodeData: [],
            fileList :'',
            Patient:null,
            PopUpVar:PopUpVariant,
            SKLogoConst:SKLogoString,             
            showModal:false,
            ClaimInfo:null,
            ServiceCodeInfo:null,
            RequestForm:true,
            ClaimRequestNo:null,        
            ClaimStatus:[{id:3,text:'In Progress'}],
            SelectedClaimStatus:'',
            ServiceStatus: [],
            NewOverrideStatus:'',       
        columns: ['status','ovdstatusid','edit','delete','errorcode','priorapproval','expirydate','description','servicecode','qty','servicefee','thirdpartyamt','paidamt','acqcost','shippingcostsub','shippingcostpaid','tax1','tax2'],
        options: {
        texts:{
              count:"Showing {from} to {to} of {count} records|{count} records|One record",
              first:'First',
              last:'Last',
              filter:"Search Service Code:",
              filterPlaceholder:"Search Service Code",
              limit:"Records:",
              page:"Page:",
              noResults:"No Service Code Found",
              filterBy:"Filter by {column}",
              loading:'Loading...',
              defaultOption:'Select {column}',
              columns:'Columns'
          },
          responseAdapter({data}) {
            // const formatData = data.map(o => {
            //     const dataCopy = JSON.parse(JSON.stringify(o))
            //     dataCopy.expirydate = moment(o.expirydate).format('MMMM Do YYYY')
            //     return dataCopy
            //   })
              return {
                data: formatData,
                count: data.length
              };
            },
         // skin:'table table-hover',
          perPage:10,
          perPageValues:[10,15,25],
          dateColumns:['servicedate'],
          //toMomentFormat: 'YYYY/MM/DD',
          //templates: {edit: 'edit'},
          templates: {
            expirydate(h, row) {
             // moment.locale('es');
             if(row.expirydate !=null)               
              return moment(row.expirydate,"YYYY-MM-DD").format('YYYY/MM/DD');
              else
              {
                return '';
              }  
            }, 
            description(h, row) {                           
              return   <div style="font-size: 70%">{row.description}</div> ;
            },
            thirdpartyamt(h, row) {   
              return <div>${Number.parseFloat(row.thirdpartyamt).toFixed(2)}</div> ; 
            }, 
            paidamt(h, row) {   
              return <div>${Number.parseFloat(row.paidamt).toFixed(2)}</div> ; 
            }, 
            shippingcostpaid(h, row) {   
              return <div>${Number.parseFloat(row.shippingcostpaid).toFixed(2)}</div> ; 
            },  
            acqcost(h, row) {   
              return <div>${Number.parseFloat(row.acqcost).toFixed(2)}</div> ; 
            },
            servicefee(h, row) {   
              return <div>${Number.parseFloat(row.servicefee).toFixed(2)}</div> ; 
            },  
            shippingcostsub(h, row) {   
              return <div>${Number.parseFloat(row.shippingcostsub).toFixed(2)}</div> ; 
            }, 
            // markup(h, row) {   
            //   return <div>{row.markup}%</div> ; 
            // },
          },
          headings: {
            ovdstatusid:'Manual Approval',
            edit: '',
            delete:'',
            status: 'Status'  , 
            errorcode: 'Msg',         
            priorapproval: 'Prior Approval #',
            expirydate: 'Expiry Date',
            servicecode: 'Service Code',
            servicedate: 'Service Date',
            description:  'Description',
            qty: 'QTY',
            servicefee:    ((this.AppServiceID == 3) ? 'Service' : 'Submitted') + ' Amount',
            thirdpartyamt:   '1st Payer Paid Amount',
            paidamt: 'Assessed Amount', 
            paymentcode: 'Pay Code',
            codecoverage: 'Coverage Code',
            plan: 'Plan',
            acqcost: 'Unit Cost',
           // markup: 'Markup %',
            shippingcostsub: 'Shipping Cost',
            shippingcostpaid: 'Shipping Paid',
            tax1: 'Tax 1',
            tax2: 'Tax 2',
            runcode: 'Run Code'
          },
          pagination: {
            edge: true,
            nav: 'scroll',
            chunk: 5
          },
           sortable: ['description', 'qty' , 'servicefee', 'status'],
          // filterable: ['username', 'fullname', 'clinicname', 'role' ,'status'],
          sortIcon: {
                  base : 'fas',
                  is: 'fa-sort',
                  up: 'fa-sort-up',
                  down: 'fa-sort-down'
                  },
          }, 
        }
    },
    watch:{
      '$route' (to,from)
      {
         if(to.params.ClaimID == isNullOrUndefined)
          {
             this.RequestForm = false;
          }
          else
          {
            this.RequestForm = true;
          }
      },
      HSN: function(){
          console.log('HSN:'+ this.HSN)
          if(this.HSN ==null || this.HSN.length <9)
          {
            this.$refs.NewHSN.focus();
            this.Showinfo = false;
          }
      },
      // SelectedClaimStatus :function(val){
      //       console.log('selected Claim  val' , val);
      //       if(val.id == 1)
      //       {
      //         this.BtnSubmitdisabled = true;
      //       }
      // },
      ReimburseToPatient:function(){
          if(this.ReimburseToPatient == false)
          {
            this.GivenName ='';
            this.SurName ='';
            this.Address1 ='';
            this.Address2='';
            this.PostalCode ='';
          }
      },
      TempTHC:function(){
          if(this.TempTHC == false)
          {
            this.THCEffectDate ='';
            this.THCExpiryDate ='';
             
          }
      }, 
    },
    components: { 
            Card,
            CardBody,
            TileNote ,
            PAAddEdit,
            VueUploadMultipleImage,
            PAShowHSNInfo,
            PAShowCoverageInfo,
            Datepicker,
            Subtitle
        },
     filters: {
          moment: function (date) {
           
          return moment(date,"YYYY-MM-DD").format('YYYY/MM/DD');
          },
          stringify(value) {
          return JSON.stringify(value, null, 2)
          }  
        }, 
    methods: {
      GetClaimStatusIDGP: function() {
        var cs_id = this.ClaimStatusID;
        var s_id = this.SelectedClaimStatus.id
        if (cs_id != s_id) cs_id = s_id;
        return cs_id;
      },     
      GetErrDesc: function() {
        // this.showMsg('Approved but DPEBB will not pay full acquisition cost requested by provider','','Service Code Message');

        var vm = this;
        vm.ErrorDesc = [];
        var params = new URLSearchParams();
            params.append('ClaimRequestNo', vm.ClaimRequestNo);
            //params.append('code', ErrorCode);
            axios.get('SaskHealthApi/Claims/GetClaimErrorDesc', { headers: { 'Authorization': 'Bearer ' + localStorage.access_token },params})
            .then(function (response) {
//                console.log(' error desc');
//                console.log(response.data)
                vm.ErrorDesc = response.data;
            }).catch(function (er) {
                console.log(er)
            }).then(function () {
                vm.GeneratePDF();     
            });
      },         
      GeneratePDF: function (event) 
      {
        var vm = this;
        console.log('csid:'+this.GetClaimStatusIDGP());
        
        //console.log('GeneratePDF')
        // generated from https://ezgif.com/image-to-datauri
        const skLogo = vm.SKLogoConst.Logo64Bit;        
        
        const pdf = new jsPDF('l', 'mm', 'letter');
        const pageHeight = pdf.internal.pageSize.height;
        const pageWidth = pdf.internal.pageSize.width;
        const fontType = 'helvetica';

        function appendLeadingZeroes(n)
        {
          if(n <= 9)
          {
            return "0" + n;
          }
          return n
        }

        // Add Header and Footer to every page in report
        const addHeaderFooter = pdf => 
        {
          // get total number of pates
          const pageCount = pdf.internal.getNumberOfPages()

          // cycle through every page to add header/footer
          for (var i = 1; i <= pageCount; i++) 
          {
            pdf.setPage(i)

            var currDate = new Date();
            var rptDate = currDate.getFullYear() + "-" 
                             + appendLeadingZeroes(currDate.getMonth() + 1) + "-" 
                             + appendLeadingZeroes(currDate.getDate()) + " " 
                             + appendLeadingZeroes(currDate.getHours()) + ":" 
                             + appendLeadingZeroes(currDate.getMinutes()) + ":" 
                             + appendLeadingZeroes(currDate.getSeconds());
                  
            pdf.setFont(fontType);

            // Header Image                    
            pdf.addImage(skLogo,'png', 5, 5);//, 45, 18); //15,10,30,10); //5,5,30,10);
          
            // Header Title
            var rptTitle = '';         
            if (vm.AppServiceID == 3) rptTitle = 'Optical';
            else if (vm.AppServiceID == 4) rptTitle = 'Hearing';
            else if (vm.AppServiceID == 5) rptTitle = 'Podiatry';
            rptTitle = rptTitle + ' - New Claim';
          
            pdf.setFontSize(14);
            pdf.text(rptTitle, (pageWidth / 2), 10, 'center', 'center');    


            // Footer
            pdf.setFontSize(9);
            pdf.line(5, pageHeight - 10, pageWidth - 5, pageHeight - 10);
            pdf.text("Run Date: " + rptDate, 5, pageHeight - 5);

            pdf.setFontSize(8);    
            var copyRight = 'Copyright or Small Confidential Info????';            
            pdf.text(copyRight, pageWidth / 2 - copyRight.length / 2, pageHeight - 5);

            pdf.setFontSize(9);
            pdf.text("Page: " + String(i) + ' of ' + String(pageCount), pageWidth - 5, pageHeight - 5, {align: 'right'});
          }
        }

        // ------------------------
        // Patient Information
        // ------------------------
        var patsupprovList =  [ { label1: '', value1: ''
                                , label2: '', value2: ''
                                , label3: '', value3: ''
                                }                                  
                                , { label1: 'Patient:'     
                                  , value1: this.Patient.firstName + ' ' + this.Patient.lastName
                                  , label2: 'Clinic:'    
                                  , value2: this.SelectedClinic.clinicname
                                  , label3: 'Provider:'    
                                  , value3: this.selectedProvider.providername 
                                  }
                                , { label1: 'HSN:'         
                                  , value1: this.Patient.hsn
                                  , label2: 'Clinic #:' 
                                  , value2: this.SelectedClinic.clinicno
                                  , label3: 'Provider #:'  
                                  , value3: this.selectedProvider.providerno 
                                  }
                                , { label1: 'Address:'     
                                  , value1: this.Patient.address1 + ' ' + this.Patient.address2
                                  , label2: 'Address:'     
                                  , value2: this.SelectedClinic.address
                                  , label3: 'Service:'     
                                  , value3: this.selectedProvider.service 
                                  }
                                , { label1: 'DOB:'         
                                  , value1: moment(this.Patient.birthDay).format('YYYY/MM/DD')
                                  , label2: 'City:'        
                                  , value2: this.SelectedClinic.city
                                  , label3: 'Service Type:'
                                  , value3: this.selectedProvider.subtype 
                                  }                                
                                 ];
                                 
        var patsupprovHead = [//[],
                              [ {"content":"Patient Information","colSpan":2,"styles":{"cellWidth":"even"}}
                              , {"content":"Clinic Information","colSpan":2,"styles":{"cellWidth":"even"}}
                              , {"content":"Provider Information","colSpan":2,"styles":{"cellWidth":"even"}}
                             ]];

        // ------------------------
        // Patient Information
        // ------------------------
        pdf.autoTable
        (
          {
            theme: 'plain', 
            //startY: pdf.lastAutoTable.finalY + 3,   
            headStyles: 
            {
              font: fontType,
              fontSize: 12,
              fontStyle: 'bold',
            }, 
            styles: 
            {
              font: fontType,
              fontSize: 9,
              cellPadding: 0, 
            }, 
            columnStyles: 
            {
              0: {cellWidth: 15}, 
              2: {cellWidth: 16},
              4: {cellWidth: 22}
            }, 
            body: patsupprovList, 
            head: patsupprovHead,
            columns: 
            [ {dataKey: 'label1'}
            , {dataKey: 'value1'}
            , {dataKey: 'label2'}
            , {dataKey: 'value2'}
            , {dataKey: 'label3'}
            , {dataKey: 'value3'}
            ],                                                     
            margin: 
            {
              top: 20,
              left: 5,
              right: 5,
              bottom: 20
            },  
            didParseCell: function (data) 
            {
              if (data.section === 'head')
              {
                if (data.row.index == 0) data.cell.styles.fillColor = [236,236,236];     // light grey  
                data.cell.styles.fontStyle = 'bold';                  
                data.cell.styles.cellPadding = 0;
              };

              // Bold for Legend column
              if (data.column.index === 0 || data.column.index === 2 || data.column.index === 4 ) 
              {
              data.cell.styles.fontStyle = 'bold';
              }
            },
//            didDrawPage: pageHeaderFooter 
          }
        );

        // ------------------------
        // Service Code Information
        // ------------------------
        {
          // set legend headers to show if true for ViewNotesCoverage or for Claim Status         
          var headerInit = [ //{code: 'scvoidaction', header: 'Void Action', show: true, assessor: false, legend: false, legendHeader:'', align:'left'}
                            //, 
                              {code: 'scstatus', header: 'Status', show: true, validID: [1,2,3,4], assessor: false, legend: false, legendHeader:'', align:'left'}
                            , {code: 'scerrorcode', header: 'Msg', show: true, validID: [1,2,4], assessor: false, legend: false, legendHeader:'', align:'left'}                             
                            , {code: 'scpriorapproval', header: 'Prior Approval #', show: true, validID: [1,2,3,4], assessor: false, legend: false, legendHeader:'', align:'left'}                             
                            , {code: 'scexpdate', header: 'Expiry Date', show: false, validID: [], assessor: false, legend: false, legendHeader:'', align:'left'}                             
                            , {code: 'scdescription', header: 'Description', show: true, validID: [1,2,3,4], assessor: false, legend: false, legendHeader:'', align:'left'}
                            , {code: 'scservicecode', header: 'Service Code', show: true, validID: [1,2,3,4], assessor: false, legend: false, legendHeader:'', align:'left'}
                            , {code: 'scqty', header: 'Qty', show: true, validID: [1,2,3,4], assessor: false, legend: false, legendHeader:'', align:'left'}                             
                            , {code: 'scpaidamt', header: 'AA ($)', show: true, validID: [1,2,4], assessor: false, legend: true, legendHeader:'(AA) Assessed Amount', align:'right'}
                            , {code: 'scservicefee', header: 'SA ($)', show: true, validID: [1], assessor: false, legend: true, legendHeader:'(SA) ' + ((vm.AppServiceID == 3) ? 'Service' : 'Submitted'), align:'right'}
                            , {code: 'scacqcost', header: 'UC ($)', show: true, validID: [1,2,3,4], assessor: false, legend: true, legendHeader:'(UC) Unit Cost', align:'right'}
                            , {code: 'scmarkup', header: 'MU %', show: false, validID: [], assessor: false, legend: true, legendHeader:'(MU) Markup', align:'right'}
                            , {code: 'scshippingcostsub', header: 'SC ($)', show: true, validID: [1,2,3,4], assessor: false, legend: true, legendHeader:'(SC) Shipping Cost', align:'right'}
                            , {code: 'scshippingcostpaid', header: 'SP ($)', show: true, validID: [1], assessor: false, legend: true, legendHeader:'(SP) Shipping Paid', align:'right'}
                            , {code: 'scthirdpartyamt', header: '1PPA ($)', show: true, validID: [1,2,3,4], assessor: false, legend: true, legendHeader:'(1PPA) 1st Payer Paid Amount', align:'right'}
                            , {code: 'sctax1', header: 'Tax 1', show: true, validID: [1,2,3,4], assessor: false, legend: false, legendHeader:'', align:'left'}
                            , {code: 'sctax2', header: 'Tax 2', show: true, validID: [1,2,3,4], assessor: false, legend: false, legendHeader:'', align:'left'}
                            , {code: 'sctooth1', header: 'Tooth 1', show: false, validID: [], assessor: false, legend: false, legendHeader:'', align:'left'}
                            , {code: 'sctooth2', header: 'Tooth 2', show: false, validID: [], assessor: false, legend: false, legendHeader:'', align:'left'}
                            , {code: 'sccomments', header: 'Comments', show: false, validID: [], assessor: false, legend: false, legendHeader:'', align:'left'}
                            , {code: 'scruncode', header: 'RC', show: true, validID: [1,2,4], assessor: false, legend: true, legendHeader:'(RC) Run Code', align:'left'}
                            , {code: 'scpaymentcode', header: 'PC', show: false, validID: [1,2,4], assessor: true, legend: true, legendHeader:'(PC) Payment Code', align:'left'}
                            , {code: 'sccovcode', header: 'CC', show: false, validID: [1,2,4], assessor: true, legend: true, legendHeader:'(CC) Coverage Code', align:'left'}
                            , {code: 'scplan', header: 'Plan', show: false, validID: [1,2,4], assessor: true, legend: false, legendHeader:'', align:'left'}
                            ];

          // need to set rules for headers
          for(var hdrIdx = 0; hdrIdx < headerInit.length; hdrIdx++)
          {
            var codeVal = headerInit[hdrIdx].code;
            var validID = headerInit[hdrIdx].validID;
            var assessorVal = headerInit[hdrIdx].assessor;

            if (validID.includes(this.GetClaimStatusIDGP()) 
            && ((assessorVal && this.ViewNotesCoverage) || !assessorVal)) headerInit.find(x => x.code == codeVal).show = true;
            else headerInit.find(x => x.code == codeVal).show = false;
          }
    
          // Filter only Headers to show
          var headerList = headerInit.filter(hdr => hdr.show);

          var serviceColumnList = [];
          var serviceColumnHeaderList = [];
          for (var hdrIdx = 0; hdrIdx < headerList.length; hdrIdx++)   
          {  
              var serviceColumnObj = {};
              var serviceColumnHeaderObj = {};
              serviceColumnObj["title"] = headerList[hdrIdx].header;
              serviceColumnObj["dataKey"] = headerList[hdrIdx].code; 
              serviceColumnHeaderObj["id"] = headerList[hdrIdx].code;  
              serviceColumnHeaderObj["content"] = headerList[hdrIdx].header;  
              serviceColumnHeaderObj["styles"] = {"halign":headerList[hdrIdx].align};
              serviceColumnList.push(serviceColumnObj);
              serviceColumnHeaderList.push(serviceColumnHeaderObj);
          }

          // create data row for Service Codes to show
          // need to set rules for data row and also for the header (data rules below)
          var serviceBodyList = [];
          var serviceDataList = [];
          for (var srcIdx = 0; srcIdx < vm.SourceCodeData.length; srcIdx++)                                                     
          {
            var dataRowList = [];
            var show = false;
            var labelVal = '';
            var valueVal = '';
            var showVal = '';

            for (var hdrIdx = 0; hdrIdx < headerList.length; hdrIdx++)   
            {
              labelVal  = headerList[hdrIdx].code;
              showVal = headerList[hdrIdx].show;
              valueVal = '';     

              var validID = headerList[hdrIdx].validID;
              var assessorVal = headerList[hdrIdx].assessor;

              if (validID.includes(this.GetClaimStatusIDGP()) 
              && ((assessorVal && this.ViewNotesCoverage) || !assessorVal)) 
              {
                switch(labelVal)
                {
                  //Previous Status
                  case 'scstatus':
                    valueVal = vm.SourceCodeData[srcIdx].status;
                    break;

                  // Message
                  case 'scerrorcode':
                    valueVal = vm.SourceCodeData[srcIdx].errorcode;
                    break;

                  // Prior Approval
                  case 'scpriorapproval':
                    valueVal = '';            
                    var pa = vm.SourceCodeData[srcIdx].priorapproval; 
                    var idx = 0;
                    if (pa != null && pa != '') 
                    {
                      pa = pa.trim();
                      idx = pa.length/2;
                      var splitChar = (pa.length >0 ? '\n': '');
                      valueVal = pa.substring(0,idx) + splitChar + pa.substring(idx);
                    }
                    break;

                  // Expiry Date              
                  case 'scexpdate':
                    var expDateVal = vm.SourceCodeData[srcIdx].expirydate
                    valueVal =  ( expDateVal != null && expDateVal != '' ) ? moment(expDateVal).format('YYYY/MM/DD') : ''
                    break;

                  // Description
                  case 'scdescription':
                    valueVal = vm.SourceCodeData[srcIdx].description;
                    break;

                  // Service Code
                  case 'scservicecode':
                    valueVal = vm.SourceCodeData[srcIdx].servicecode;
                    break;

                  // Quantity
                  case 'scqty':
                    valueVal = vm.SourceCodeData[srcIdx].qty;
                    break;

                  // Assessed Amount
                  case 'scpaidamt':
                    valueVal = vm.SourceCodeData[srcIdx].paidamt.toFixed(2).replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
                    break;

                  // Service Amount/Submitted Amount
                  case 'scservicefee':
                    valueVal = vm.SourceCodeData[srcIdx].servicefee.toFixed(2).replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
                    break;

                  // Acq Unit Cost
                  case 'scacqcost':
                    valueVal = vm.SourceCodeData[srcIdx].acqcost.toFixed(2).replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
                    break;

                  // Markup %
                  case 'scmarkup':
                    valueVal = vm.SourceCodeData[srcIdx].markup.toFixed(3); 
                    //valueVal = vm.SourceCodeData[srcIdx].markup.toFixed(1);
                    break;

                  // Shipping Cost
                  case 'scshippingcostsub':
                    valueVal = vm.SourceCodeData[srcIdx].shippingcostsub.toFixed(2).replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
                    break;

                  // Shipping Paid
                  case 'scshippingcostpaid':
                    valueVal = vm.SourceCodeData[srcIdx].shippingcostpaid.toFixed(2).replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
                    break;

                  // 1PPA
                  case 'scthirdpartyamt':
                    valueVal = vm.SourceCodeData[srcIdx].thirdpartyamt.toFixed(2).replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
                    break;

                  // Tax 1
                  case 'sctax1':
                    valueVal = vm.SourceCodeData[srcIdx].tax1;
                    break;            

                  // Tax 2
                  case 'sctax2':
                    valueVal = vm.SourceCodeData[srcIdx].tax2;
                    break;            

                  // Tooth 1
                  case 'sctooth1':
                    valueVal = vm.SourceCodeData[srcIdx].tooth1;
                    break;

                  // Tooth 2
                  case 'sctooth2':
                    valueVal = vm.SourceCodeData[srcIdx].tooth2;
                    break;

                  // Comments
                  case 'sccomments':
                    valueVal = vm.SourceCodeData[srcIdx].comments.substring(0,39);
                    break;

                  // Run Code
                  case 'scruncode':
                    valueVal = vm.SourceCodeData[srcIdx].runcode;
                    break;

                  // Payment Code
                  case 'scpaymentcode':
                    valueVal = vm.SourceCodeData[srcIdx].paymentcode;
                    break;

                  // Coverage Code
                  case 'sccovcode':
                    valueVal = vm.SourceCodeData[srcIdx].codecoverage;
                    break;

                  // Plan
                  case 'scplan':
                    valueVal = vm.SourceCodeData[srcIdx].plan;
                    break;

                  default:
                }
                dataRowList.push({ label: labelVal, value: valueVal, show: showVal });               
              }
            }

            var serviceBodyObj = {};
            var serviceDataObj = {};

            // filter only Columns to show
            var svcList = dataRowList.filter(svcCol => svcCol.show);             
            // create data elements for Service Codes information
            for (var j = 0; j < svcList.length; j++)   
            {
              serviceBodyObj[svcList[j].label] = svcList[j].value;
            }  

            serviceBodyList.push(serviceBodyObj);  
          }
        
          var serviceHeadList = [//[{id: "rowHdr0", "content":"","colSpan":22} ],
                                [ {id: "rowHdr1", "content":"Service Code Information","colSpan":serviceColumnHeaderList.length} ],
                                [ {id: "rowHdr2", "content":"","colSpan":serviceColumnHeaderList.length,"styles":{"cellPadding":0, "height":0.25}} ],
                                serviceColumnHeaderList
                                ];  

          var noServiceCodesFoundList = [];
          if (vm.SourceCodeData.length == 0)
          {
             serviceHeadList.push([{id: "rowHdr3", "content":"<< No Service Code Found >>","colSpan":serviceColumnHeaderList.length, "styles":{"cellPadding":0, "halign":"center", "fontStyle":"normal"}}]);
          }

          //************************
          // Service Code Lines Table       
          //************************
          pdf.autoTable
          (
            {
              theme: 'plain', 
              startY: pdf.lastAutoTable.finalY + 7,   
              headStyles: 
              {
                font: fontType,
                fontSize: 12,
                fontStyle: 'bold',
                cellPadding: 0.5,
              }, 
              styles: 
              {
                font: fontType,
                fontSize: 9,
                cellPadding: 0.5, 
//                lineWidth: .5,
              }, 
              body: serviceBodyList, 
              head: serviceHeadList,
              columns: serviceColumnList,                                                     
              margin: 
              {
                top: 20,
                left: 5,
                right: 5,
                bottom: 20
              },  
              didParseCell: function (data) 
              {
//                data.cell.styles.cellWidth = 'auto';
                if (data.section === 'head')                                     // header
                {
                  if (data.row.index == 0)                                  // Service Code information row in header
                  {
                    data.cell.styles.fillColor = [236,236,236];     // light grey       
                    data.cell.styles.cellPadding = 0;                               
                  }
                  else                                                           // column headers row in header
                  {
                    data.cell.styles.fontSize = 9;
//                    data.cell.styles.cellPadding = 0.5;
                  }
                }
                else                                                             // body
                {
                  data.cell.styles.halign = serviceColumnHeaderList[data.column.index].styles.halign;
//                  data.cell.styles.cellPadding = 0.5;             
                }
              },
//              didDrawPage: pageHeaderFooter 
            }
          );

          //************************
          // Legend Information
          //************************
          {
            // initialize data matrix
            var legendList =[ 
                              { datakey1: 'Legend'
                              , datakey2: '          '
                              , datakey3: '          '
                              , datakey4: '          '
                              , datakey5: '          '
                              , datakey6: '          '
                              , datakey7: '          '
                              }
                            ];
            // filter only legend records to show
            var legendInit = headerInit.filter(hdrList => hdrList.legend);
                        
            // only show values with show = true and sort by code
            var showLegendList = _.sortBy( legendInit.filter(legend => legend.show), 'legendHeader' );

            // create second row if more than 6 values in list
            if (showLegendList.length > 6) 
            {
              var legendListb = { datakey1: '          '
                                , datakey2: '          '
                                , datakey3: '          '
                                , datakey4: '          '
                                , datakey5: '          '
                                , datakey6: '          '
                                , datakey7: '          '
                                };
              legendList.push(legendListb);
            }

            // update values in data matrix
            var cntLoop = 0;
            var cntRow = 0;
            var leg = [];

            for (var i = 0; i < showLegendList.length; i++) 
            {  
              cntRow++;
              var arrval = showLegendList[i].legendHeader;
              legendList[cntLoop]["datakey" + (cntRow+1)] = arrval;

              // add new line if need to since stores datakey 1-7                
              if (cntRow == 6) 
              {
                cntLoop++;
                cntRow = 0;
              }
            }

            //************************
            // Legend table        
            //************************
            pdf.autoTable
            (
              {
                theme: 'plain', 
                startY: pdf.lastAutoTable.finalY + 3,   
                headStyles: 
                {
                  font: fontType,
                  fontSize: 8,
                  fontType: 'bold',
                  cellPadding: 0                  
                }, 
                styles: 
                {
                  font: fontType,
                  fontSize: 8,
                  cellPadding: 0
                }, 
                body: legendList,
                head: [[]],
                columns: 
                [
                  { dataKey: 'datakey1' },
                  { dataKey: 'datakey2' },
                  { dataKey: 'datakey3' },
                  { dataKey: 'datakey4' },
                  { dataKey: 'datakey5' },
                  { dataKey: 'datakey6' },
                  { dataKey: 'datakey7' },              
                ], 
                columnStyles: 
                {
                  0: { cellWidth: 14}
                },   
                margin: 
                {
                  top: 20,
                  left: 5,
                  right: 5,
                  bottom: 20
                }, 
                didParseCell: function (data) 
                {
                  // Bold for Legend column
                  if (data.column.index === 0) data.cell.styles.fontStyle = 'bold';
                } 
              }
            );            
          
          } // End Legend

          //************************
          // Message Codes
          //************************     
          if (vm.ErrorDesc != null && vm.ErrorDesc != '' && vm.ErrorDesc.length != 0 && vm.SourceCodeData.length != 0)
          {
            pdf.autoTable
            (
              {
                theme: 'plain', 
                startY: pdf.lastAutoTable.finalY + 3,   
                headStyles: 
                {
                  font: fontType,
                  fontSize: 8,
                  fontType: 'bold',
                  cellPadding: 0                  
                }, 
                styles: 
                {
                  font: fontType,
                  fontSize: 8,
                  cellPadding: 0, 
                }, 
                body: vm.ErrorDesc,
                head: [[],['Message', 'Description']],
                columns: 
                [
                  { dataKey: 'item1' },  //errorCode
                  { dataKey: 'item2' },  //errMsg
                ],
                columnStyles: 
                {
                  0: { cellWidth: 14}
                },   
                margin: 
                {
                  top: 20,
                  left: 5,
                  right: 5,
                  bottom: 20
                },  
              }
            );
          } // End Message Codes
        } // End Service Codes

        // ------------------------
        // Claim/Prior Approval Information
        // ------------------------
        function isEmpty(obj) 
        {
          for(var key in obj) 
          {
            if(obj.hasOwnProperty(key))
                return false;
          }
          return true;
        }

        var emptyRowObj = { label1: ''
                          , value1: '' 
                          };
        var payeeObj = {};
        if (this.ViewNotesCoverage && this.ReimburseToPatient) 
        {
          payeeObj = { label1: 'Payee Name:'    
                     , value1: this.GivenName + ' ' + this.SurName
                     , label2: 'Address:'
                     , value2: {"content":this.Address1.trim() + ', ' + this.Address2.trim() + ', ' + this.PostalCode.trim() + ', ' + this.Province.trim(),"colSpan":3}
                     };
        }

        var overrideObj = {};
        if (this.ViewNotesCoverage)
          overrideObj = { label1: {"content":"Manual Approval Notes:","colSpan":1}
                        , value1: {"content":this.OverRideNotes,"colSpan":5}
                        };                               

        var claimstatusObj =  { label1: 'Claim Status:'    
                              , value1: this.SelectedClaimStatus.text || this.SelectedClaimStatus.text 
                              };                               

        var claimList = [ { label1: '', value1: '' }
                        , { label1: {"content":"Notes:","colSpan":1}
                          , value1: {"content":this.ClaimNotes,"colSpan":5}  
                            }
                        , { label1: ''
                          , value1: '' 
                          }
                        , { label1: 'Service Date:'    
                          , value1: moment(this.ServiceDate).format('YYYY/MM/DD')
                          , label2: 'Lab Name:'
                          , value2: this.LabName
                          , label3: '1st Payer Paid Amount:'
                          , value3: ( this.PaidByThirdParty ) ? 'Y' : 'N'
                          }
                        , { label1: 'Temporary Health Certificate (THC):'
                          , value1: ( this.TempTHC ) ? 'Y' : 'N'
                          , label2: 'THC Effective Date:'
                          , value2: ( this.TempTHC ) ? moment(this.THCEffectDate).format('YYYY/MM/DD') : ''
                          , label3: 'THC Expiry Date:'
                          , value3: ( this.TempTHC ) ? moment(this.THCExpiryDate).format('YYYY/MM/DD') : ''   
                          }
                        , { label1: 'X-Rays and Documents:'    
                          , value1: ( this.DocUpload ) ? 'Y' : 'N'
                          , label2: 'Reimburse to Patient:'
                          , value2: ( this.ReimburseToPatient ) ? 'Y' : 'N'
                          }
                        ];

        if (!isEmpty(payeeObj)) 
        {
          claimList.push(payeeObj);
        }

        if (!isEmpty(overrideObj)) 
        {
          claimList.push(emptyRowObj);               
          claimList.push(overrideObj);         
        }

        claimList.push(emptyRowObj); 
        claimList.push(claimstatusObj);            

        var claimPA = 'Claim Information';
        var claimHead = [
             //[],
             [ {"content":claimPA,"colSpan":6,"styles":{"cellWidth":"even"}} ]];

        
        pdf.autoTable
        (
          {
            theme: 'plain', 
            startY: pdf.lastAutoTable.finalY + 7,   
            headStyles: 
            {
              font: fontType,
              fontSize: 12
            },            
            styles: 
            {
              font: fontType,
              fontSize: 9,
              cellPadding: 0, 
              cellWidth: 'wrap'
            }, 
            columnStyles: 
            {
              0: {cellWidth: 55}, 
              1: {cellWidth: 'auto'}, 
              2: {cellWidth: 34}, 
              3: {cellWidth: 50}, 
              4: {cellWidth: 37},
              5: {cellWidth: 'auto'}
            }, 
            body: claimList, 
            head: claimHead,
            columns: 
            [ {dataKey: 'label1'}
            , {dataKey: 'value1'}
            , {dataKey: 'label2'}
            , {dataKey: 'value2'}
            , {dataKey: 'label3'}
            , {dataKey: 'value3'}
            ],
                                                  
            margin: 
            {
              top: 20,
              left: 5,
              right: 5,
              bottom: 20
            },  
            didParseCell: function (data) 
            {
              if (data.section === 'head' && data.row.index == 0)
              {data.cell.styles.fontStyle = 'bold';
                data.cell.styles.fillColor = [236,236,236];     // light grey  
                data.cell.styles.cellPadding = 0;
                if (data.column.index === 0) data.cell.colspan = 2;
                if (data.column.index === 1) data.cell.colspan = 0;
              };

              // Bold for Legend column
              if (data.column.index === 0 || data.column.index === 2 || data.column.index === 4 ) data.cell.styles.fontStyle = 'bold';
            },
          }
        );

        // draw the header/footers on each page
        addHeaderFooter(pdf);
        
        // save the pdf file
        pdf.save('newClaim.pdf');

      },

      ExpiryClick (){
        console.log('i am here')
      } ,
      EffectiveChange(){ 
        if(this.THCEffectDate !='' && this.THCEffectDate !=undefined) 
        { 
          this.disableExpiry =false; 
          this.$set(this.DisableToExpiry, 'to', (this.THCEffectDate)); 
        }
       
      //this.$refs.ClearExpiryDate.removeDate();
      //this.$refs.ClearExpiryDate.clearDate();
       //this.$refs.ClearExpiryDate.clearDate();
       //this.$emit('clearDate', this.THCExpiryDate);
       // this.THCExpiryDate='';
      
      },
      ClinicChange(){
          // if(this.SelectedClinic == ''){
             
          // }
      },
      ProviderChange(){
        //console.log('provider' +this.selectedProvider  )
          if(this.ProviderNo == '' || this.ProviderNo == null){
            this.selectedProvider = null;
            this.Showinfo = false; 
          }
      },
      ExitClaim(){
          this.$router.push(this.HomePath);
      },
      ChangeClaimStatus: function($event)
      {
          if(this.SelectedClaimStatus.id==4) //Manual Approve
          {
             this.ClaimStatusDisable=true;
             if(this.ClaimStatusID ==2)   //Edit error
             {
                if(this.ViewNotesCoverage ==true)  
                {
                    this.columns= ['status','ovdstatusid','edit','delete','errorcode','priorapproval','description','servicecode','qty','acqcost','shippingcostsub','thirdpartyamt','paidamt','tax1','tax2','runcode','paymentcode','codecoverage','plan'];
                }
                else
                {
                    this.columns= ['status','ovdstatusid','edit','delete','errorcode','priorapproval','description','servicecode','qty','acqcost','shippingcostsub','thirdpartyamt','paidamt','tax1','tax2','runcode'];
                } 
                this.BtnSubmitdisabled=false; 
                this.DocYN = false;
                this.PaidYN =false;
                this.THCYN = false;
                this.ReimburseYN = false;
             }
            else if(this.ClaimStatusID ==1){ //Adjudication Completed
               if(this.ViewNotesCoverage ==true)  
                {
                    this.columns= ['status','ovdstatusid','edit','errorcode','priorapproval','description','servicecode','qty','paidamt','servicefee','acqcost','shippingcostsub','shippingcostpaid','thirdpartyamt','tax1','tax2','runcode','paymentcode','codecoverage','plan'];
                }
                else
                {
                    this.columns= ['status','ovdstatusid','errorcode','priorapproval','description','servicecode','qty','paidamt','servicefee','acqcost','shippingcostsub','shippingcostpaid','thirdpartyamt','tax1','tax2','runcode'];
                } 
              this.BtnSubmitdisabled=false; 
              this.DocYN = false;
              this.PaidYN =false;
              this.THCYN = false;
              this.ReimburseYN = false;
             }
          }
          else{
              this.ClaimStatusDisable=false;
          }
       
      }, 
      getMsgClass(value) 
        {
          return ( value>= 3000 ) ? 'text-danger' : 'text-primary';
        },
      getErrorStyle(value) 
      {
        return ('width: 7.5rem !important;  padding:3px !important;')
      },
      GetMsg: function(ErrorCode) {
        // this.showMsg('Approved but DPEBB will not pay full acquisition cost requested by provider','','Service Code Message');
         
         var vm = this; 
          var params = new URLSearchParams(); 
            params.append('program', 'HCHXA020');
            params.append('code', ErrorCode);
            axios.get('SaskHealthApi/Codes/GetMessage', { headers: { 'Authorization': 'Bearer ' + localStorage.access_token },params})
            .then(function (response) {
                vm.showMsg(response.data,'','Service Code Message')
            }).catch(function (er) {
                console.log(er)
            }).then(function () {
                  
            }); 
      }, 
      ChangeServiceStatus : function($event,serviceid){
      var NewStatusId = parseInt($event.target.value); 
         var vm = this; 
            var url = "/SaskHealthApi/Claims/PostUpdateServiceCodeStatus/"
            var params = {
                "_": Date.now(),
                "ServiceCodeID": serviceid,
                "NewStatusID": NewStatusId                
                } 
           axios({
              method: 'post',
              url: url,
              headers: { 'Authorization': 'Bearer ' + vm.$store.getters.GetAccessToken },
              data: params
            }).then(function (response) {
                  console.log(response.data)
            }).catch(function (er) {
                  console.log(er)
                }).then(function () {
                    vm.GetServiceCodes('M');
                }); 
      },
        GetNotesCoverage(GetHSN){
          //alert(GetHSN)
          if(GetHSN)
          {
            this.GetNotes = true;
            //this.popupTitle="Medical HSN Notes";         
          }
          else
          {
            this.GetNotes = false;  
            this.popupTitle="Patient Coverage";  
          }
          this.showNotesCov = true;
        },
        AddEditPopup(data,action){
         // console.log( this.selectedProvider.providerno)
         // console.log(this.SelectedClaimStatus.id)
          var slectedid = this.SelectedClaimStatus.id;
          //console.log('selected id =' +slectedid)
           this.ClaimInfo = {HSN:this.HSN, ClinicNo: this.SelectedClinic.clinicno,ProviderNo: this.selectedProvider.providerno,ClaimRequestNo: this.ClaimRequestNo, StatusID: this.ClaimStatusID, SelectedID: slectedid, ClaimTypeID: 1,CanOverride: this.CanOverRide}
          this.ServiceCodeInfo =  {description:data.description,qty:data.qty,servicecode:data.servicecode,
           servicedate:data.servicedate,acqcost:data.acqcost, shippingcost:data.shippingcostsub,
           thirdpartyamt:data.thirdpartyamt,markup:data.markup,tax1:data.tax1, tax2:data.tax2, servicecodeid : data.servicecodeid, expirydate: data.expirydate, PriorApprovalNo: data.priorapproval, AssessedAmt : data.paidamt};
          if(action=="E")
          this.PopAddEditTitle= "Edit Service Code Form"
          else if(action=="A")
          this.PopAddEditTitle= "Add Service Code Form"
          this.showModal = true;
        },
        AddEditDone(ClaimNo) {
            this.ClaimRequestNo= ClaimNo;
            //alert(this.ClaimRequestNo)
            if(this.ClaimRequestNo != null)
            {
              this.GetServiceCodes('U');
              this.showModal = false;
              //this.RequestForm = true; 
            }
            else
            { 
              //this.GetServiceCodes();
              this.showModal = false;
              //this.RequestForm = false;
            }
         },
        Go(){
            this.$router.push('/DPEBB/MainHome')
        },
         Show(){
             this.Showinfo =true;
        }, 
        GetClaimOverride(){
            var vm = this;
              axios.get('SaskHealthApi/Codes/CanOverRideClaim', { headers: { 'Authorization': 'Bearer ' + localStorage.access_token }})
             .then(function (response) {
                   vm.CanOverRide = response.data;
                   //this.SelectedClaimStatus = this.ClaimStatus.find(x=>x.statusid === 3);
                   //console.log(this.SelectedClaimStatus)
                })
            .catch(function (er) {
                console.log(er)
            }).then(function()
            {

            })
        },
        GetAssessor(){
            var vm = this;
              axios.get('SaskHealthApi/Codes/IsAssessorOrSuper', { headers: { 'Authorization': 'Bearer ' + localStorage.access_token }})
             .then(function (response) {
                   vm.ViewNotesCoverage = response.data; 
                })
            .catch(function (er) {
                console.log(er)
            }).then(function()
            {
              vm.GetClinics();
              console.log (vm.ViewNotesCoverage)
                if(vm.ViewNotesCoverage == true)
                {
                  vm.dis=false;
                }
            })
        },

        CanAccessAllApp(){
            var vm = this;
              axios.get('SaskHealthApi/Codes/AccessAllApp', { headers: { 'Authorization': 'Bearer ' + localStorage.access_token }})
             .then(function (response) {
                   vm.ShowHomeBtn = response.data; 
                })
            .catch(function (er) {
                console.log(er)
            }).then(function()
            {  
            })
        },
        ClosePopup(){
          this.showError =false;
        },
        GetHsnInfo(){  
           var vm = this;
              vm.$v.$touch();
              if (!vm.$v.$invalid){   
                              
                var vm = this;
                var url = 'SaskHealthApi/Host/GetHsnInq';
                var params = new URLSearchParams();
                params.append('HSN', this.HSN);
                if(vm.ViewNotesCoverage)
                url ='SaskHealthApi/Host/GetHsnInqLead';
                axios.get(url, { headers: { 'Authorization': 'Bearer ' + localStorage.access_token },params})
                .then(function (response) { 
                        vm.Patient =response.data;
                        vm.Showinfo= true;  
                    })
                .catch(function (er) {
                    console.log(er)
                  if(er.status ==400)
                  {
                      vm.showError = true;
                      vm.MsgPopup = er.data.message;
                      //console.log("Error: " + er.data.message);  
                  }
                  else if(er.status == 500)
                    {
                        vm.showError = true;
                        
                        if(er.data.message !=null)
                          vm.MsgPopup = er.data.message;
                        else
                        vm.MsgPopup = "Network Related Error !"
                        
                    }
                })
              }  
        },
        GetClaimStatus(){
           var vm = this;          
         
           //console.log('ClaimStatus');
          if(this.ClaimRequestNo !=null)
          {     
             vm.ClaimStatus =[];
            //var vm = this;
            var params = new URLSearchParams();
             params.append('_', Date.now());
              params.append('ClaimID', this.ClaimRequestNo);
              axios.get('SaskHealthApi/Claims/GetClaimStatus', { headers: { 'Authorization': 'Bearer ' + localStorage.access_token },params})
              .then(function (response) {
                  if(response.data !== null)
                  {
                    //console.log('response:'+response.data.claimstatus)
                      vm.ClaimStatus = response.data.claimstatus;
                      vm.CanOverRide = response.data.canoverride;
                      vm.ClaimStatusID =response.data.selectid; 
                      vm.SelectedClaimStatus =vm.ClaimStatus.find(x=>x.id === response.data.selectid);
                       vm.TotalSc =  response.data.totalsc;
                      if(vm.ClaimStatusID ==1 && vm.TotalSc ==0) // adj complete
                      {
                          vm.BtnSubmitdisabled = true;
                          vm.DocYN = true;
                          vm.PaidYN =true;
                          vm.THCYN = true;
                          vm.ReimburseYN = true;
                      }
                      else if(vm.ClaimStatusID ==1 && vm.TotalSc >0)
                      {
                          vm.BtnSubmitdisabled = true;
                          vm.DocYN = true;
                          vm.PaidYN =true;
                          vm.THCYN = true;
                          vm.ReimburseYN = true;
                      }
                      else if(vm.ClaimStatusID ==2 && vm.TotalSc >0) //Edit
                      {
                          vm.BtnSubmitdisabled = false;
                          vm.DocYN = false;
                          vm.PaidYN =false;
                          vm.THCYN = false;
                          vm.ReimburseYN = false;
                      }
                      else if(vm.ClaimStatusID ==2 && vm.TotalSc==0)
                      {
                          vm.BtnSubmitdisabled = true;
                          vm.DocYN = true;
                          vm.PaidYN =true;
                          vm.THCYN = true;
                          vm.ReimburseYN = true;
                      }
                      else if(vm.ClaimStatusID ==3 && vm.TotalSc >0) // pending
                      {
                          vm.BtnSubmitdisabled = false;
                          vm.DocYN = false;
                          vm.PaidYN =false;
                          vm.THCYN = false;
                          vm.ReimburseYN = false;
                      }
                      else if(vm.ClaimStatusID ==3 && vm.TotalSc==0)
                      {
                          vm.BtnSubmitdisabled = true;
                          vm.DocYN = true;
                          vm.PaidYN =true;
                          vm.THCYN = true;
                          vm.ReimburseYN = true;
                      }
                      else if(vm.ClaimStatusID ==4 && vm.TotalSc >0) // Manual Approval
                      {
                          vm.BtnSubmitdisabled = false;
                          vm.DocYN = true;
                          vm.PaidYN =true;
                          vm.THCYN = true;
                          vm.ReimburseYN = true;
                      }
                      else if(vm.ClaimStatusID ==4 && vm.TotalSc==0)
                      {
                          vm.BtnSubmitdisabled = true;
                          vm.DocYN = true;
                          vm.PaidYN =true;
                          vm.THCYN = true;
                          vm.ReimburseYN = true;
                      } 
                }           
                })
              .catch(function (er) {
                  console.log(er)
              }).then(function(response)
              { 
                //console.log('Claim Status Length: '+vm.ClaimStatus)
                if(vm.ClaimStatus.length ==1)
                {
                    vm.ClaimStatusDisable =true;
                }
                else
                {
                  vm.ClaimStatusDisable =false;
                }
                //in Progress
                if( vm.ClaimStatusID == 3)
                //if(vm.SelectedClaimStatus.id == 3)
                {
                    vm.columns= ['status','edit','delete','priorapproval','description','servicecode','qty','acqcost','shippingcostsub','thirdpartyamt','tax1','tax2'];
                }
                else if( vm.ClaimStatusID == 1)
                //else if(vm.SelectedClaimStatus.id == 1) //adj compelted               
                {
                    //vm.BtnSubmitdisabled=true;
                     //console.log('submit btn'+ vm.BtnSubmitdisabled)
                    if(vm.ViewNotesCoverage ==true)
                    {                       
                       vm.columns= ['status','errorcode','priorapproval','description','servicecode','qty','paidamt','servicefee','acqcost','shippingcostsub','shippingcostpaid','thirdpartyamt','tax1','tax2','runcode','paymentcode','codecoverage','plan'];
                    }
                    else{
                          vm.columns= ['status','errorcode','priorapproval','description','servicecode','qty','paidamt','servicefee','acqcost','shippingcostsub','shippingcostpaid','thirdpartyamt','tax1','tax2','runcode'];
                    } 
                }
                else if( vm.ClaimStatusID == 2)
                //else if(vm.SelectedClaimStatus.id == 2)  // edit
                {
                    if(vm.ViewNotesCoverage ==true)
                    {
                      vm.columns= ['status','edit','delete','errorcode','priorapproval','description','servicecode','qty','paidamt','acqcost','shippingcostsub','thirdpartyamt','tax1','tax2','runcode','paymentcode','codecoverage','plan'];
                    }
                    else
                    {
                        vm.columns= ['status','edit','delete','errorcode','priorapproval','description','servicecode','qty','paidamt','acqcost','shippingcostsub','thirdpartyamt','tax1','tax2','runcode'];
                    } 
                }
              })
          }
          else
          {
              vm.SelectedClaimStatus =vm.ClaimStatus.find(x=>x.id == 3);
              vm.ClaimStatusID=3;
              vm.columns= ['status','edit','delete','priorapproval','description','servicecode','qty','acqcost','shippingcostsub','thirdpartyamt','tax1','tax2'];
          }        
        }, 
        GetServiceCodesStatus(){ 
          var vm = this;
          axios.get('SaskHealthApi/Claims/GetOverrideStatus', { headers: { 'Authorization': 'Bearer ' + localStorage.access_token }})
          .then(function (response) {
                vm.ServiceStatus = response.data; 
            })
        .catch(function (er) {
            console.log(er)
            }).then(function()
            {
                
            })
        },

        GetServiceCodes(callstatus){ 
           var vm = this;
           vm.SourceCodeData = [];
           //console.log('Services:Code: '+this.AppServiceID);
            var params = new URLSearchParams();
             params.append('_', Date.now());
            params.append('ServiceID', this.AppServiceID);
            params.append('ClaimRequestNo', this.ClaimRequestNo);
             axios.get('SaskHealthApi/Claims/GetServiceCodePerReq', { headers: { 'Authorization': 'Bearer ' + localStorage.access_token },params})
             .then(function (response) {
                    //console.log(response.data);
                    vm.SourceCodeData = response.data;
                    //console.log(vm.SourceCodeData.length)
                })
            .catch(function (er) {
                console.log(er)              
            }).then(function()
            {
              if(callstatus=='S') // call from submit
              {
                vm.GetClaimStatus(); 
              }
              else if(callstatus=='D') //call from delete
              {
                  if(vm.SelectedClaimStatus.id != 4)
                  {
                     vm.GetClaimStatus();
                  } 
                  else if (vm.SelectedClaimStatus.id == 4 && vm.SourceCodeData.length ==0)
                  {
                     vm.GetClaimStatus();
                  }
              }
              else if(callstatus=='M') // call from Manual approval
              {
                 
              }
              else if(callstatus=='U') // call from update
              {
                  if(vm.SelectedClaimStatus.id != 4)
                  {
                    vm.GetClaimStatus();
                  } 
              }
            })
        },
         GetProvider(){

           var vm = this;
            var params = new URLSearchParams();
             params.append('ServiceID', this.AppServiceID);
             axios.get('SaskHealthApi/Codes/GetProvidersByService', { headers: { 'Authorization': 'Bearer ' + localStorage.access_token },params})
             .then(function (response) { 
                    vm.Provider = response.data; 
                })
            .catch(function (er) {
                console.log(er)
            }).then(function()
              {
                
                console.log('provider length='+ vm.Provider.length)
                if(vm.AppServiceID == 3)
                {
                    
                    // vm.selectedProvider=  {"providerno":"0000099995","providername":"OPT Provider","address":"Albert St","city":"Regina","province":"SK","service":"Optical","subtype":"Optical"};
                    // vm.$refs.SearchProvider.inputValue = vm.selectedProvider.providername;
                     vm.DisbleProvider =false;
                }
                else if(vm.AppServiceID ==4)
                {
                    vm.selectedProvider=  {"providerno":"9999999998","providername":"PSEUDO HEARING","address":"3475 ALBERT ST","city":"Regina","province":"SK","service":"Hearing","subtype":"Hearing AUD"};
                    vm.DisbleProvider =false;
                    vm.$refs.SearchProvider.inputValue = vm.selectedProvider.providername;
                }
                else if(vm.AppServiceID ==5 )
                {
                    // vm.selectedProvider=  {"providerno":"0000099994","providername":"POD Provider","address":"Albert St","city":"Regina","province":"SK","service":"Podiatry","subtype":"Podiatry"};
                      vm.DisbleProvider =false;
                    // vm.$refs.SearchProvider.inputValue = vm.selectedProvider.providername;
                }
                console.log('at provider=' + vm.DisbleProvider)
                // if(vm.Provider.length ==1 || vm.Provider.length>1)
                // {                  

                  //}
            
              })
        },
        GetClinics(){

           var vm = this; 
          var params = new URLSearchParams();
          params.append('ServiceID', this.AppServiceID);
            axios.get('/SaskHealthApi/Codes/GetUserClinic', { headers: { 'Authorization': 'Bearer ' + localStorage.access_token }, params})
            .then(function (response) {
                    //vm.Clinic.push(response.data);
                    vm.Clinic = response.data;
                     console.log(response.data);
                    // console.log(vm.Clinic)
                })
            .catch(function (er) {
                console.log(er)
              //{clinicno: 99999, clinicname: "99999 CLINIC", address: "99999 ", city: " Regina", province: "SK"}   
            }).then(function()
                  {
                    if(vm.ViewNotesCoverage != true)
                    {
                      vm.SelectedClinic = {clinicno:  vm.Clinic[0].clinicno, clinicname: vm.Clinic[0].clinicname, address:  vm.Clinic[0].address, city:  vm.Clinic[0].city, province:  vm.Clinic[0].province}   
                      console.log(vm.SelectedClinic) 
                    } 
                  }) 
       },
        uploadImageSuccess(formData, index, filelist) {
           this.fileList = filelist;
          // var array = [1];
          // var other = _.concat(array, 2, [3], [[4]]); 
          // console.log(other);     
          //console.log('data', formData, index, filelist)
          // _.forEach(filelist, function(value, key) { 
          //   console.log(value.path.split(',')[1]); 
          // }); 
          // Upload image api
          // axios.post('http://your-url-upload', formData).then(response => {
          //   console.log(response)
          // })
          console.log('file List', this.fileList)
        
        },
        beforeRemove (index, done, fileList) {
            this.showMsgBox('Are you sure you want to delete the file ? ','',2,done);  
        },
        editImage (formData, index, fileList) {
          //console.log('edit data', formData, index, fileList)
        }, 
      showMsgBox(msg,data,MethodNo,done) {
           var vm  = this;
          this.boxTwo = ''
          this.$bvModal.msgBoxConfirm(msg, {
          title: 'Please Confirm',
          size: 'md',
          buttonSize: 'md',
          okVariant: 'danger',
          cancelVariant: 'default',
          okTitle: 'YES',
          cancelTitle: 'NO',
          footerClass: 'p-2',
          hideHeaderClose: true,
          centered: true, 
        })
          .then(value => {
            this.boxTwo = value
            //console.log(value)
            if(value)
            {
              if(MethodNo ==2)
               {
                 done()
                 //vm.DelConfirm = this.boxTwo;
               }
               if(MethodNo ==1)
                this.DeleteServiceCode(data);
            }
          })
          .catch(err => {
            // An error occurred
          })
      },
      showMsg(msg,data,Title) {
          this.boxTwo = ''
          this.$bvModal.msgBoxOk(msg, {
          title: Title,
          size: 'md',
          buttonSize: 'md',
          okVariant: 'danger',          
          okTitle: 'Close', 
          footerClass: 'p-2',
          hideHeaderClose: true,
          hideHeaderCancel: true,
          centered: true, 
        })
          .then(value => {
            console.log('at value ' + value)
            this.boxTwo = value
            if(value)
            {
             
            }
          })
          .catch(err => {
            // An error occurred
          })
      },
      SaveClaim(){ 
          console.log('here')
        this.$v.$touch();      
         if (!this.$v.$invalid){ 
            var vm = this; 
            //vm.DocUpload = true;
            var url = "/SaskHealthApi/Claims/SubmitClaimRequest/"
            var bodyFormData = new FormData(); 
            var im =[]; 
                _.forEach(vm.fileList, function(value, key) {
                im.push({'DocName' : value.name,'DocType' : value.path.split(',')[0].split(';')[0].split(':')[1], 'DocImage': value.path.split(',')[1]});
              });
              console.log(im.length)
              if(im.length==0)
              {
                vm.DocUpload=false;
              }          
            var im2 = {
                      'ClaimID':vm.ClaimRequestNo,                   
                      'ClaimStatusID': vm.ClaimStatusID,
                      'ClaimOverrieID': vm.SelectedClaimStatus.id,
                      'LabName':vm.LabName,
                      'DocAttached':vm.DocUpload,
                      'ThirdPartyPaid':vm.PaidByThirdParty,
                      'THC':vm.TempTHC,
                      'THC_EffectiveDate':vm.THCEffectDate,
                      'THC_ExpiryDate':vm.THCExpiryDate,
                      'ServiceID':vm.AppServiceID,
                      'ServiceDate':vm.ServiceDate,
                      'ReimburseToPatient':vm.ReimburseToPatient, 
                      'ClaimNotes':vm.ClaimNotes,
                      'ClaimNotesAvailable':vm.ClaimNotesAvailable,
                      'ThirdPartyPaidSign':vm.ThirdPartyPaidSign,
                      'ThirdPartyPaidAmt':vm.ThirdPartyPaidAmt,
                      'OverRideNotes':vm.OverRideNotes,
                      'PayeeHSN':vm.PayeeHSN,
                      'GivenName':vm.GivenName,
                      'SurName':vm.SurName,
                      'Address1':vm.Address1,
                      'Address2':vm.Address2,
                      'Province':vm.Province,
                      'PostalCode':vm.PostalCode};   
              bodyFormData.append('PAData',JSON.stringify(im2)); 
              bodyFormData.append('imgdata',JSON.stringify(im));          
            axios({
              method: 'post',
              url: url,
            headers: { 'Content-Type': 'multipart/form-data', 'Authorization': 'Bearer ' + vm.$store.getters.GetAccessToken },
              data: bodyFormData   
            }).then(function (response) {
                 //console.log(response)
                  if(response.status ==200)
                  {
                    vm.showMsg(response.data.message,'','Claim Request Processed');
                  }
                })
                .catch(function (er) {
                    if(er.status == 500)
                    {
                       if(er.data.message !=null)
                       vm.showMsg(er.data.message,'','Claim Request Error');
                       else
                       vm.showMsg('Network Error, please contact system admin for more detail.','','Claim Request Error');
                    }
                    console.log(er)
                }).then(function () {  
                    vm.GetServiceCodes('S');
                }); 
          }
         }, 
      DeleteServiceCode(data)
      {
          var vm = this;
            var url = "/SaskHealthApi/Claims/delete/ServiceCode/"
            var params = {
                "_": Date.now(),
                "ServiceCodeID": data.servicecodeid,"ServiceID": vm.AppServiceID,"ClaimRequestNo":vm.ClaimRequestNo 
                } 
                axios({
                    method: 'delete',
                    url: url,
                    headers: { 'Authorization': 'Bearer ' + vm.$store.getters.GetAccessToken },
                    data: params
                    }).then(function (response) {
                        if(response.status ==200)
                            {    
                                vm.GetServiceCodes('D');
                            }
                    })
                .catch(function (error) {
                    if (error.response) {
                      if(error.response.status ==500)
                      {                   
                          vm.succeeded = false;
                          vm.Msg="System Error; service code is not successfully saved."; 
                          vm.showModal=true; 
                      }
                    }
                    console.log(error)
                });
      },
      ValidateOverRideNotes(){   
         
        if(this.SelectedClaimStatus.id == 4)
        {
            console.log('list:'+this.OverRideNotes)
            if(this.OverRideNotes =='' || this.OverRideNotes ==null ){
              return false;
            }
            else  
            {
              return true;
            }
        }
        else
        {
          return true;
        }
      },
      ValidateDoc(){   
        console.log('list:'+this.fileList)
        if(this.TempTHC == true)
        {
           console.log('list:'+this.fileList)
            if(this.fileList =='' || this.fileList ==null ){
              return false;
            }
            else if (this.fileList !=null && this.fileList.length>0)
            {
              return true;
            }
        }
        else
        {
          return true;
        }
      },
      ValidateEffectDate(){   
        if(this.TempTHC == true)
        {
           if(this.THCEffectDate ===null || this.THCEffectDate ==='' || this.THCEffectDate==='undefined')
            {
              return false;
            }             
            else
            {
              return true;
            }
        }
        else
        {
          return true;
        }
      },
      ValidateExpDate(){
   
        if(this.TempTHC == true)
        {
                
            if(this.THCExpiryDate ==null ||  this.THCExpiryDate =='' || this.THCExpiryDate=='undefined')
            {
              return false;
            }
            else
            {
              if( !(this.THCExpiryDate >= this.THCEffectDate))
              {
                return false;
              }
              else
              return true;
            }
        }
        else
        {
          return true;
        }
      },
      ValidateFname(){ 
        if(this.ReimburseToPatient == true)
        {
            if(this.GivenName ===null ||  this.GivenName ==='' || this.GivenName==='undefined')
            {
              return false;
            }
            else
            {
              return true;
            }
        }
        else
        {
          return true;
        }
      },
      ValidateLname(){ 
        if(this.ReimburseToPatient == true)
        {
            if(this.SurName ===null ||  this.SurName ==='' || this.SurName==='undefined')
            {
              return false;
            }
            else
            {
              return true;
            }
        }
        else
        {
          return true;
        }
      },
      ValidateAddress(){ 
        if(this.ReimburseToPatient == true)
        {
            if(this.Address1 ===null ||  this.Address1 ==='' || this.Address1==='undefined')
            {
              return false;
            }
            else
            {
              return true;
            }
        }
        else
        {
          return true;
        }
      },
      ValidateCity(){ 
        if(this.ReimburseToPatient == true)
        {
            if(this.Address2 ===null ||  this.Address2 ==='' || this.Address2==='undefined')
            {
              return false;
            }
            else
            {
              return true;
            }
        }
       else
        {
          return true;
        }
      },
      ValidatePostalCode(){ 
        if(this.ReimburseToPatient == true)
        {
            if(this.PostalCode ===null ||  this.PostalCode ==='' || this.PostalCode==='undefined')
            {
              return false;
            }
            else
            {
              return true;
            }
        }
        else
        {
          return true;
        }
      }, 
      ValidateProv(){ 
        if(this.ReimburseToPatient == true)
        {
            if(this.Province ===null ||  this.Province ==='' || this.Province==='undefined')
            {
              return false;
            }
            else
            {
              return true;
            }
        }
        else
        {
          return true;
        }
      },
    },
    computed:{ 
    },
     created: function() {  
        this.AppServiceID = this.ServiceID;
        if(this.AppServiceID == 3)
        {
          this.popupTitle = "Optical HSN Notes";
          this.AppName = "Optical Application:";
          this.title= "Optical Application";
          this.HomePath=this.HomePaths.Optical;
        }
        else if(this.AppServiceID == 4)
        {
          this.popupTitle = "Hearing HSN Notes";
          this.AppName = "Hearing Application:";
          this.title= "Hearing Application";
          this.HomePath = this.HomePaths.Hearing;
        }
        else if(this.AppServiceID == 5)
        {
          this.popupTitle = "Podiatry HSN Notes";
          this.AppName = "Podiatry Application:";
          this.title= "Podiatry Application";
          this.HomePath = this.HomePaths.Podiatry;
        }
        this.dateFormat = this.$store.getters.GetDateFormat; 
        this.ServiceDate=moment(new Date()).format('YYYY/MM/DD');   
        //this.GetClinics();
        this.GetProvider();
        this.GetClaimStatus();
        this.GetServiceCodesStatus();
        this.GetAssessor();
        this.CanAccessAllApp(); 
    },
    beforeCreate: function() {  
        //console.log(this.AppServiceID)
        // this.$store.dispatch('AddServiceID',this.$store.getters.GetMedicalID);
       // this.$store.dispatch('GetMenuItems',this.$store.getters.GetMedicalID); 
    },
     mounted: function () {
       
       //this.$refs.SearchClinic.inputValue = 'Some value'
     this.$nextTick(function () { 
      
        // if(this.$router.params == isNullOrUndefined)
        // {
        //     this.RequestForm = false;  
        // } 
      })
    },

    validations(){
      return { 
            SelectedClinic : {
              required, 
            },
            selectedProvider : {
              required, 
            },
            HSN : {
              required,
              numeric,
             minLength:minLength(9),
            },
            ServiceDate:{
              required,
              //MaxValue: value => (moment(this.ServiceDate)).toISOString() <=  moment().startOf('day').toISOString(),
              MaxValue: value => (moment(this.ServiceDate)).toISOString() <=  moment().startOf('day').endOf('day').toISOString(),  
            }, 
            THCEffectDate:{
            needValue: value=>  this.ValidateEffectDate(),             
            },
            THCExpiryDate:{
            needValue: value=>  this.ValidateExpDate(),             
            },
            HaveDoc :{
              DocUploaded: value=> this.ValidateDoc()
            },
            OverRideNotes:{
              needValue:value=>  this.ValidateOverRideNotes()
            },
            GivenName:{
              alpha,
              needValue:value=>  this.ValidateFname()
            },
            SurName:{
              alpha,
              needValue:value=>  this.ValidateLname()
            },
            Address1:{
              alphaNum,
              needValue:value=>  this.ValidateAddress()
            },
            Address2:{
              alpha,
              needValue:value=>  this.ValidateCity()
            },
            PostalCode:{
              postal,
              needValue:value=>  this.ValidatePostalCode()
            },
            Prov:{
              needValue:value=>  this.ValidateProv()
            },
   
        }   
     },

}
</script>
<style scopped>
 
 .row.no-gutter [class*='col-']   {
   padding-right:1px;
   
 }
 .list-group-item {
    position: relative;
    display: block;
    padding: 0px 15px;
    margin-bottom: -1px;
    border: 1px solid #ddd;
    background-color: blue;
    line-height: 1em
}
/* remove right padding from first column */
/* .row.no-gutter [class*='col-']:first-child {
  padding-right:5px;
} */
/* remove left padding from first column */
/* .row.no-gutter [class*='col-']:last-child {
  padding-left:5px;
} */


/* only for column content visible */
.col-lg-1>div {background-color:#ddd;}

#docimg {
   
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50; 
  /* margin-top: 10px; */
}
#line {
  border-top:1px solid   rgba(7, 14, 109, 0.25);
  /* border-bottom:1px solid #c00;
  border-bottom: 1px solid rgba(255,255,255,.25); */
} 
 .select-css {
    display: block;
    font-size: 14px;
    /* font-family: sans-serif; */
    font-weight: 600;
    color: #444;
    line-height: 1.3;
    padding: .6em 1.4em .5em .8em;
    width: 100%;
    max-width: 100%; 
    box-sizing: border-box;
    margin: 0;
    border: 1px solid #aaa;
    box-shadow: 0 1px 0 1px rgba(0,0,0,.04);
    border-radius: .5em;
    -moz-appearance: none;
    -webkit-appearance: none;
    /* appearance: none; */
    background-color: #fff;
    background-image: url('data:image/svg+xml;charset=US-ASCII,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22292.4%22%20height%3D%22292.4%22%3E%3Cpath%20fill%3D%22%23007CB2%22%20d%3D%22M287%2069.4a17.6%2017.6%200%200%200-13-5.4H18.4c-5%200-9.3%201.8-12.9%205.4A17.6%2017.6%200%200%200%200%2082.2c0%205%201.8%209.3%205.4%2012.9l128%20127.9c3.6%203.6%207.8%205.4%2012.8%205.4s9.2-1.8%2012.8-5.4L287%2095c3.5-3.5%205.4-7.8%205.4-12.8%200-5-1.9-9.2-5.5-12.8z%22%2F%3E%3C%2Fsvg%3E'),
    linear-gradient(to bottom, #ffffff 0%,#e5e5e5 100%);
    background-repeat: no-repeat, repeat;
    background-position: right .7em top 50%, 0 0;
    background-size: .65em auto, 100%;
}
.select-css::-ms-expand {
    display: none;
}
.select-css:hover {
    border-color: #888;
}
.select-css:focus {
    border-color: #aaa;
    box-shadow: 0 0 1px 3px rgba(59, 153, 252, .7);
    box-shadow: 0 0 0 3px -moz-mac-focusring;
    color: #222; 
    outline: none;
}
.select-css option {
    font-weight:normal;
}
#ServiceCodeGrid .VuePagination__count{
  visibility: hidden;
  height:0px;
}
#ServiceCodeGrid .pagination{
  height:0px
}
/* #ServiceCodeGrid tr td:nth-child(2) {
    width: 9.5rem !important;
    padding:3px !important;
    /* margin:0rem !important;
}  */ 

.highlight {
    background-color: #fff2ac;
    background-image: linear-gradient(to right, #ffe359 0%, #fff2ac 100%);
}
.bd-highlight {
    /* background-color: rgba(86,61,124,0.15); */
    /* border: 1px solid rgba(86,61,124,0.15); */
    background-image: linear-gradient(to right, #ffe359 0%, #fff2ac 100%);
    /* background-image: linear-gradient(to right, #ac9732ad 0%, #cebc5985 100%); */
    /* text-decoration-line: underline; */
    font-weight: bold;
    padding: .4rem;
    margin: 0rem !important;
    
}

.cov {
 
    font-size: 1.3rem;
    font-weight: bolder;
    /* padding: .2rem; */
    margin: 0rem !important;
    
}
</style>