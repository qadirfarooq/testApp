<template>
<div >  
<div class="row no-gutters Hometitle pl-2 mt-0 pt-0"> 
    <div class="col-sm-8">            
    <h4><small class="text-muted">  <strong> {{AppName}} Void {{ClaimType}}:</strong> </small></h4> 
    </div> 
    <div class="col-sm-4">
     <button  v-on:click="Exit"  type="button" class="ml-1 btn btn-primary btn-sml float-right"><i class="far fa-times-circle"></i>Close</button>
      <button v-on:click="GetErrDesc" type="button" class="btn btn-outline-primary btn-sml float-right">  <i class="fas fa-print"></i> Print</button>
    </div>  
</div>

<div id="PriorApprovalForm" v-if="!(ClaimRequestNo==null)" class="mb-2 mt-1">
  <div class="row no-gutters"> 
    <div class="col-4 pr-1" v-if="selectedPatient!=null">
      <div class="card">
        <div class="card-header d-flex align-items-center" style="height: 2rem; margin:0;padding:0 !important;">
          <h5>
            <small class="text-muted pl-1" style="text-align:left;"><b><i class="fas fa-user-injured"></i>Patient: {{selectedPatient.firstName}} {{selectedPatient.lastName}}</b>
            </small>
          </h5>  
        </div> 
        <div  class="card-body p-2 mb-0" v-if="selectedPatient!=null">
          <div class="row" >
            <span for="cname" class="col-sm-4"><b>HSN:</b></span> 
            <span   class="col-sm-8" type="text">{{selectedPatient.hsn}}</span> 
          </div>
          <div class="row">
            <span for="cname" class="col-sm-4"><b>Address:</b></span> 
            <span class="col-sm-8" type="text">{{selectedPatient.address1}} {{selectedPatient.address2}}</span> 
          </div>
          <div class="row">
            <span for="cname" class="col-sm-4"><b>DOB:</b></span> 
            <span class="col-sm-8" type="text">{{selectedPatient.birthDay|moment}} </span> 
          </div>   
        </div> 
      </div>
    </div>
  
    <div class="col-4 pr-1" v-if="selectedClinic!=null">
      <div class="card">
        <div class="card-header   d-flex align-items-center  pl-1" style="height: 2rem; text-align:left;">
          <h5><small class="text-muted"><b><i class="fas fa-clinic-medical"></i>Clinic: {{selectedClinic.clinicname}}</b></small></h5>
        </div>
        <div  class="card-body p-2 mb-0"> 
          <div class="row">
            <span for="cname" class="col-sm-4"><b>Clinic #:</b></span> 
            <span class="col-sm-8" type="text">{{selectedClinic.clinicno}}</span> 
          </div>
          <div class="row">
            <span for="cname" class="col-sm-4"><b>Address:</b></span> 
            <span class="col-sm-8" type="text">{{selectedClinic.address}}</span> 
          </div>
          <div class="row">
            <span for="cname" class="col-sm-4"><b>City:</b></span> 
            <span class="col-sm-8" type="text">{{selectedClinic.city}}</span> 
          </div> 
        </div>  
      </div>
    </div> 
    <div class="col-4 pr-1" v-if="selectedProvider!=null">
        <div class="card">
          <div class="card-header   d-flex align-items-center  pl-1" style="height: 2rem; text-align:left;">
            <h5><small class="text-muted"><b> <i class="far fa-file-powerpoint"></i>Provider: {{selectedProvider.providername}}</b></small></h5>
          </div>
          <div  class="card-body p-2 ">
              <div class="row" >
                <span for="cname" class="col-sm-4"><b>Provider #:</b></span> 
                <span   class="col-sm-8" type="text">{{selectedProvider.providerno}}</span> 
              </div>
              <div class="row" >
                <span for="cname" class="col-sm-4"><b>Service:</b></span> 
                <span   class="col-sm-8" type="text">{{selectedProvider.service}}</span> 
              </div>
              <div class="row" >
                <span for="cname" class="col-sm-4"><b>Service Type:</b></span> 
                <span   class="col-sm-8" type="text">{{selectedProvider.subtype}}</span> 
              </div>    
          </div> 
        </div> 
        </div> 
  </div>
     
  <div id="ServiceCodeGrid" class="mt-2"> 
        <v-client-table :columns="columns" :data="SourceCodeData" :options="options"  ref="table">
        <template slot="ovid" slot-scope="props">  
          <!-- <select id="override" v-bind:value="props.row.ovdstatusid"    @change="ChangeServiceStatus($event,props.row.servicecodeid)"  class="form-control form-control-sm select-css" :style="getErrorStyle(props.row.errorcode)">  
            <option v-for="option in ServiceStatus" v-bind:value="option.id"  :key="option.id"> 
            <strong>{{option.text}} </strong>
            </option> 
          </select> -->
          <div v-if="props.row.ovdstatusid ==7" class="bd-highlight no-gutters" >
             <!-- <span  class="bd-highlight mr-1 row"><i class="fas fa-check" fa-2x style="color:red"></i>VOIDED</span> -->
          <div class="row no-gutters mr-2">
             
             <div class="col-4"><i class="fas fa-check" fa-2x style="color:red"></i></div>
             <div class="col-8"><b>VOIDED</b></div>
            
           </div>
          </div> 
          <div v-else> 
          <select id="override"  v-bind:value="props.row.ovdstatusid"    @change="ChangeServiceStatus($event,props.row.servicecodeid)"  class="form-control form-control-sm select-css" :style="getErrorStyle(props.row.errorcode)">  
            <option v-for="option in ServiceStatus" v-bind:value="option.id" :disabled="option.disabled"  :key="option.id">            
            <strong>{{option.text}} </strong>
            </option> 
          </select>
          </div>
        </template>  
        <template slot="status" slot-scope="props">
          <span  class="bd-highlight">{{props.row.status}}</span>
        </template>
        <template slot="errorcode" slot-scope="props">
          <span class="pointer"  :class="getMsgClass(props.row.errorcode)"   v-on:click="GetMsg(props.row)"><i class="fas fa-comment-medical"></i>{{props.row.errorcode}}</span>
        </template>
        
        </v-client-table> 
    </div> 
  <div class="card" id="PAFormUploadStatus">
  <div class="row mt-2 no-gutters">
      <div class="col-6">
        <div class=" mr-1">
        <div class="card-header   d-flex align-items-center  pl-1" style="height: 2rem; text-align:left;">
          <h5><small class="text-muted"><b><i class="fas fa-thumbs-up"></i>Claim Data:</b></small></h5>
        </div>
        <form>
          <div class="p-2 pb-0 mb-0" > 
            <div class="form-group row my-1">               
              <label for="ClaimNotes" class="col-sm-5 label-small">Notes</label>
              <div class="col-sm-7"> 
                   {{this.vcdDetails.claimNotes}}
                <!-- <textarea wrap="on" rows="2" class="my-0 form-control  text-area-xs"  id="ClaimNotes"   min="1" max="300" v-model="ClaimNotes"  placeholder="ClaimNotes" ></textarea>      -->
              </div>                 
            </div>
            <div class="form-group row my-1">               
                  <label for="lab" class="col-sm-5 label-small">Service Date:</label>
                  <div class="col-sm-4">      
                   {{this.vcdDetails.serviceDate | moment}}   
                  </div> 
            </div>
            <div class="form-group row my-1">               
                  <label for="lab" class="col-sm-5 label-small">Lab Name:</label>
                  <div class="col-sm-4">
                      {{this.vcdDetails.labname}}	  
                   </div> 
            </div>

            <div class="form-group row my-0">
                  <label  class="col-sm-5 label-small">1st Payer Paid Amount (if applicable):</label>
                  <div class="col-sm-4">      
                      {{this.vcdDetails.thirdPartyPaid}}   
                  </div> 
            </div>

            <div class="form-group row my-0">
                  <label  class="col-sm-5 label-small">Temporary Health Certificate (THC):</label>
                  <div class="col-sm-3">      
                      {{this.vcdDetails.thc}}   
                  </div> 
            </div>
            <transition name="slide-fade"> 
            <div v-if="this.vcdDetails.thc=='Y'">
              <div class="form-group row my-1" >               
                    <label for="eff" class="col-sm-5 label-small">THC Effective Date:</label>
                    <div class="col-sm-4">      
                      {{this.vcdDetails.thcEffect | moment}}
                    </div> 
              </div> 
              <div class="form-group row my-1">               
                <label for="exp" class="col-sm-5 label-small">THC Expiry Date:</label>
                <div class="col-sm-4">      
                    {{this.vcdDetails.thcExpiry | moment}}
                </div> 
              </div> 
            </div>
             </transition> 
             <div class="form-group row my-0" v-if="ViewNotesCoverage">
                <label  class="col-sm-5 label-small">Reimburse to Patient:</label>
                <div class="col-sm-4">      
                    {{this.vcdDetails.reimbursementind}}	
                </div> 
              </div> 
          </div>
        </form>
        </div>
      </div>
      <div class="col-6">
        <div class="">
        <div class="card-header   d-flex align-items-center  pl-1" style="height: 2rem; text-align:left;">
          <h5><small class="text-muted"><b><i class="fas fa-upload"></i>Documents:</b></small></h5>
        </div>
        <div class=" p-2 pb-0 mb-0" >           
          <div class="form-group row">
                <label for="Qty" class="col-sm-10 label-small">X-Rays and documents:</label>
                <div class="col-sm-2">      
                    {{this.vcdDetails.attachmentind}}
                </div>                              
          </div>        
          <transition name="slide-fade">            
          <div v-if="this.vcdDetails.attachmentind=='Y'"  class="row mt-2" id="docimg" style="display: flex; justify-content: center;">
            <v-client-table id="docGrid" :columns="docColumns" :data="docList" :options="docOptions">
            <span class="pointer" v-on:click="OpenClaimDoc(props.row)" slot="docname" 
              slot-scope="props">
                <a  v-b-tooltip title="Click to View"> {{props.row.docname}} </a>
            </span>       
            </v-client-table>
          </div>
           </transition>
        </div>
        </div>
      </div>    
  </div>
 <transition name="slide-fade" v-if="ViewNotesCoverage">        
  <div class="row mt-2 no-gutters PayeeForm" id="PatientPayeeForm"  v-if="this.vcdDetails.reimbursementind=='Y' && this.vcdDetails.payeegivenname!='' && this.vcdDetails.payeepostalcode!=''">
  <!-- <div class="row mt-2 no-gutters PayeeForm" id="PatientPayeeForm"> -->
    <div class="col-12">
      <div class="card-header d-flex align-items-center  pl-1" style="height: 2rem; text-align:left;">
        <h5><small class="text-muted"><b><i class="fas fa-file-invoice-dollar" aria-hidden="true"></i>Patient Payee:</b></small></h5>
      </div>
      </div>
      <div class="col-6">
        <div class=" mr-1">   
          <div class="p-2 pb-0 mb-0" >  
            <div class="form-group row my-1">               
                  <label for="lab" class="col-sm-5 label-small">Payee Name:</label>
                  <div class="col-sm-4">      
                     {{this.vcdDetails.payeegivenname}}
                  </div> 
            </div> 
             <!-- <div class="form-group row my-1">               
                  <label for="lab" class="col-sm-5 label-small">Address 1:</label>
                  <div class="col-sm-4">      
                     {{this.vcdDetails.payeeaddress1}}
                  </div> 
            </div> 

            <div class="form-group row my-1">               
                  <label for="lab" class="col-sm-5 label-small">Postal Code:</label>
                  <div class="col-sm-4">      
                      {{this.vcdDetails.payeepostalcode}}
                  </div> 
            </div> -->

          </div> 
        </div>
      </div>
      <div class="col-6">
          <!-- <div class="form-group row my-1">               
                  <label for="lab" class="col-sm-5 label-small">Last Name:</label>
                  <div class="col-sm-4">      
                    <input id="lab" type="text" min="1" max="50" v-model="SurName"  placeholder="Last Name" class=" my-0 form-control form-control-xs">
                  </div> 
            </div> -->
             <div class="form-group row my-1">               
                  <label for="lab" class="col-sm-5 label-small">Address:</label>
                  <div class="col-sm-4">      
                     {{this.vcdDetails.payeeaddress1}}, {{this.vcdDetails.payeecity}} ,  {{this.vcdDetails.payeepostalcode}} , {{this.vcdDetails.payeeprov}}
                  </div> 
            </div> 
             <!-- <div class="form-group row my-1">               
                  <label for="lab" class="col-sm-5 label-small">Province:</label>
                  <div class="col-sm-4">      
                      {{this.vcdDetails.payeeprov}}
                  </div> 
            </div>  -->
      </div>    
  </div>
  <div class="no-gutters ml-1" v-if="this.vcdDetails.overridenotes!=''">
  <div class="col-12 row">
    <div class="col-sm-2">
      <b class="">Manual Approval Notes:</b>
    </div>   
    <div class="col-sm-10 float-left"> 
      {{this.vcdDetails.overridenotes}}
    </div>  
  </div>
</div> 
  </transition>


  <div class="row  p-0 pb-2 no-gutters card-header tile-note  d-flex align-items-center" id="ClaimStatus" style="height: 2rem;"> 
      <div class="col-6">         
          <div class="mr-0 p-0 pb-0 mb-0" >
            <div class="form-group row my-1"> 
              <div class="mt-1 col-1">
                <i class="fa fa-spinner fa-spin fa-fw"></i>
                <span class="sr-only">Loading...</span>              
              </div>
              <div class="col-4 float-left">                
                <h4>
                  <small class="text-muted">
                    <i class="far fa-thumbs-up"><b> Claim Status:               
                    </b></i>                        
                  </small>
                </h4>
              </div> 
              <div class="col-sm-7 pl-2">      
                 <span  class="bd-highlight">{{ClaimStatus || ClaimStatusID}}</span>  
              </div>                         
            </div>
          </div>         
      </div>  
  </div>

 
  <div class="row my-2 no-gutters">
    <div class="card-body p-1 pb-0 mb-0">  
      <div class="row mt-2">
        <div class="col-sm-4">
            <button v-on:click="VoidMsg('Are you sure you want to Void ' + ClaimType)"  type="button" class="btn BtnSave" :disabled="BtnSubmitdisabled"><i class="far fa-save"></i> Void {{ClaimType}} </button>
        </div>
            
        <div class="col-sm-4">
            <button  v-on:click="Exit"  type="button" class="btn BtnClose"><i class="far fa-times-circle"></i>  Exit Void</button>
        </div>

        <div class="col-sm-4">
            <button v-on:click="GetErrDesc" type="button" class="btn BtnClose">  <i class="fas fa-print"></i> Print</button>
        </div>

      </div>
    </div> 
  </div>  
  </div>
 <!-- form upload status End -->  

  <!-- <i class="fab fa-buffer fa-2x"></i> -->    
</div><!-- Prior Approval PRocess End --> 
</div> 
</template>
<script>

import Vue from 'vue';
import {mapGetters} from 'vuex'
import moment from 'moment'
import axios from 'axios' 
import PAShowCoverageInfo from '@/components/Common/PAShowCoverageInfo.vue';
import PAShowHSNInfo from '@/components/Common/PAShowHSNInfo.vue';
import PAAddEdit from '@/components/Dental/ClaimPAAddEdit.vue';
import LayoutDefault from '@/Common/Default/DefaultLayout.vue';
import Subtitle from '@/Common/Default/SubTitle.vue';  
import Card from "@/Common/Card.vue";
import CardBody from "@/Common/CardBody.vue";
import TileNote from "@/Common/TileNote.vue";
import { PopUpVariant } from '@/Common/Default/PopUpVariant';
import { SKLogoString } from '@/Common/Default/SKLogo';
import { isNullOrUndefined } from 'util';
import VueUploadMultipleImage from 'vue-upload-multiple-image'; 
import Datepicker from 'vuejs-datepicker';
import Vuelidate from 'vuelidate'
import { helpers } from 'vuelidate/lib/validators'
import jsPDF from 'jspdf'   // used for GeneratePDF
import autoTable from 'jspdf-autotable'    // used for GeneratePDF
const SixvTwo = helpers.regex('SixvTwo', /^[0-9]{0,6}(\.[0-9]{1,2})?$/)
const OnevThree = helpers.regex('OnevThree',/^1{1}(\.[0]{1,3})?$|^0{0,1}(\.[0-9]{1,3})?$/)
const alpha = helpers.regex('alpha', /^[a-zA-Z]*$/)
const postal = helpers.regex('postal',  /^[A-Za-z]\d[A-Za-z][ -]?\d[A-Za-z]\d$/);
const alphaNum = helpers.regex('alphaNum', /^\d{1,5}\s\w*/)
const Panumber = helpers.regex('Panumber',  /^([0-9]{9})$/);
Vue.use(Vuelidate)
import { required, minLength, maxLength, between,withParams,numeric} from 'vuelidate/lib/validators'
export default  {
  name: 'DentalHome',
  props: {
      vcdDetails: { required: true },
      claimRequestNumber: { required: true },
      selectedProvider: { required: true },
      selectedClinic: { required: true },
      selectedPatient: { required: true },    
      hHSN: {required: true}, 
      hType: {required: true},
      ServiceID: {required: true}, 
      AppName: {required: true},      
  },
  data: function () {
    return {
        ErrorDesc: [],        
        ProgrameName:'',
        ClaimType:'',
        ServiceCodeError: false,
        ClaimStatusDisable:true,
        TypeHeadinptClass:'form-control form-control-xs',
        dis:true,
        Prov:['AB', 'BC', 'MB', 'NB', 'NL', 'NT', 'NS', 'NU', 'ON', 'PE', 'QC', 'SK', 'YT'],  
        ViewNotesCoverage:false,
        DisableStatus:false,
        LabName:'',
        PaidByThirdParty:false,
        TempTHC:false,
        THCEffectDate:'',
        THCExpiryDate:'',
        DocUpload:false,
        ServiceDate:'',
        ReimburseToPatient:false, 
        ClaimNotes:'',
        ClaimNotesAvailable:false,
        ThirdPartyPaidSign:"+",
        ThirdPartyPaidAmt:0,
        OverRideNotes:'',  
        PayeeHSN:null,
        GivenName:'',
        SurName:'',
        Address1:'',
        Address2:'',
        Province:'SK',
        PostalCode:'',        
        dateFormat : '',       
        CanOverRide:false,
        ClaimStatusID:'', 
        datapickClass:"form-control form-control-xs my-0", 
        //AppName:'',
        GetNotes:false,
        showNotesCov:false,
        ImageType:'image/gif,image/jpeg,image/png,image/bmp,image/jpg,image/jp2,image/jpx,image/jpf',
        boxTwo: '',
        BtnSubmitdisabled:true,
        popupTitle:'Dental HSN Notes',
        PopAddEditTitle:'Add Service Code Form',
        popupText:'',        
        primaryText:'',
        PaidByThirdPArty:false,
        dragText:'Upload X-Rays and Documents',
        browseText:'Click Here',
        AppServiceID :0,
        MaxMatch:20,  
        title:"Dental Application",
        subtitle: "Welcome", 
        HSN:'',
        ProviderNo:'',
        Showinfo : false,
        Provider:[{'providerno': 1000, 'providername': 'test'}],
        Clinic: [],
        ClinicNo:'',
        SelectedClinic:null,
        images: [],
        SourceCodeData: [],
        fileList :'',
        Patient:null,
        PopUpVar:PopUpVariant,
        SKLogoConst:SKLogoString,           
        showModal:false,
        ClaimInfo:null,
        ServiceCodeInfo:null,
        RequestForm:true,
        ClaimRequestNo:null,        
        ClaimStatus:'',
        SelectedClaimStatus:'',
        ServiceStatus: [],
        docList: [],
        NewOverrideStatus:'',    
        columns: ['ovid','status','errorcode','priorapproval','expirydate','description','servicecode','qty','paidamt','servicefee','acqcost','markup','shippingcostsub','shippingcostpaid','thirdpartyamt','tax1','tax2','runcode','paymentcode','codecoverage','plan'],
        docColumns: ['docname', 'doctypeicon', 'createddate'],
        options: {
        texts:{
              count:"Showing {from} to {to} of {count} records|{count} records|One record",
              first:'First',
              last:'Last',
              filter:"Search Service Code:",
              filterPlaceholder:"Search Service Code",
              limit:"Records:",
              page:"Page:",
              noResults:"No Service Code Found",
              filterBy:"Filter by {column}",
              loading:'Loading...',
              defaultOption:'Select {column}',
              columns:'Columns'
          },
          responseAdapter({data}) { 
              return {
                data: formatData,
                count: data.length
              };
            },
         // skin:'table table-hover',
          perPage:10,
          perPageValues:[10,15,25],
          dateColumns:['servicedate'],
          //toMomentFormat: 'YYYY/MM/DD',
          //templates: {edit: 'edit'},
          templates: {
            expirydate(h, row) {
             // moment.locale('es');               
              return moment(row.expirydate,"YYYY-MM-DD").format('YYYY/MM/DD');  
            }, 
            description(h, row) {                           
              return   <div style="font-size: 70%">{row.description}</div> ;
            }, 
            thirdpartyamt(h, row) {   
              return <div>${Number.parseFloat(row.thirdpartyamt).toFixed(2)}</div> ; 
            }, 
            paidamt(h, row) {   
              return <div>${Number.parseFloat(row.paidamt).toFixed(2)}</div> ; 
            },  
            servicefee(h, row) {   
              return <div>${Number.parseFloat(row.servicefee).toFixed(2)}</div> ; 
            },   
          },
          headings: {
            status: 'Previous Status'  , 
            errorcode: 'Msg',         
            priorapproval: 'Prior Approval #',
            expirydate: 'Expiry Date',
            servicecode: 'Service Code',
            servicedate: 'Service Date',
            description:  'Description',
            qty: 'QTY',
            servicefee:    ((this.ServiceID == 3) ? 'Service' : 'Submitted') + ' Amount',
            thirdpartyamt:   '1st Payer Paid Amount',
            paidamt: 'Assessed Amount', 
            paymentcode: 'Pay Code',
            codecoverage: 'Coverage Code',
            plan: 'Plan',
            acqcost: 'Unit Cost',
            markup: 'Markup %',
            shippingcostsub: 'Shipping Cost',
            shippingcostpaid: 'Shipping Paid',
            tax1: 'Tax 1',
            tax2: 'Tax 2',
            runcode: 'Run Code',
           ovid: 'Void Action'
          },
          pagination: {
            edge: true,
            nav: 'scroll',
            chunk: 5
          },
           sortable: ['description', 'qty' , 'servicefee', 'status'],
          // filterable: ['username', 'fullname', 'clinicname', 'role' ,'status'],
          sortIcon: {
                  base : 'fas',
                  is: 'fa-sort',
                  up: 'fa-sort-up',
                  down: 'fa-sort-down'
                  },
          },
          
           docOptions: {
          texts:{
              count:"{from} to {to} of {count} documents|{count} documents|One document",
              first:'First',
              last:'Last',
              limit:"Records:",
              page:"Page:",
              noResults:"No Claim Documents Found",
              filterBy:"Filter by {column}",
              loading:'Loading...',
              defaultOption:'Select {column}',
              columns:'Columns'
          },
          responseAdapter({data}) 
          {          
              return {
              data: formatData,
              count: data.length
              }
          },
          perPage:5,
          perPageValues:[5],
          dateColumns:['createddate'],
          templates: {
           
          },
          headings: {
            docname: 'Document', 
            doctypeicon: 'Type',
            createddate: 'Added',         
          },
          pagination: {
            edge: true,
            nav: 'scroll',
            chunk: 5
          },
          sortable: ['DocName', 'DocType', 'CreatedDate'],
          sortIcon: {
                  base : 'fas',
                  is: 'fa-sort',
                  up: 'fa-sort-up',
                  down: 'fa-sort-down'
          },
          filterable: false,
          // eslint-disable-next-line no-dupe-keys
          templates: {    
            createddate(h, row) {         
              return moment(row.createddate,"YYYY-MM-DD").format('YYYY/MM/DD');  
            }, 
            doctypeicon(h, row) {
              if (row.doctype.includes("pdf"))
              {
                return <span style="color:black" v-b-tooltip title="PDF"><i class="fa fa-file-pdf-o"></i></span>
              }
              else if (row.doctype.includes("word"))
              {
                return <span style="color:black" v-b-tooltip title="Document"><i class="fa fa-file-word-o"></i></span>                
              }
              else if (row.doctype.includes("text"))
              {
                return <span style="color:black" v-b-tooltip title="Text"><i class="fa fa-file-text-o"></i></span>                
              }
              else if (row.doctype.includes("image"))
              {
                return <span style="color:black" v-b-tooltip title="Image"><i class="fa fa-file-photo-o"></i></span>                
              }
              else
              {
                return <span style="color:black" v-b-tooltip title='Other'><i class="fa fa-file-o" ></i></span>
              }
            }
          }
        },

        }
    },
    watch:{ 
      // BtnSubmitdisabled:function(val){
      //   this.BtnSubmitdisabled=val;
      // }, 
    },
    components: { 
            Card,
            CardBody,
            TileNote ,
            PAAddEdit,
            VueUploadMultipleImage,
            PAShowHSNInfo,
            PAShowCoverageInfo,
            Datepicker,
            Subtitle
        },
     filters: {
          moment: function (date) { 
          return moment(date,"YYYY-MM-DD").format('YYYY/MM/DD');
          },
          stringify(value) {
          return JSON.stringify(value, null, 2)
          }  
        }, 
    methods: {
      GetVoidStatusGP: function (id) {
        var voidStatusDesc = '';
        if (this.ServiceStatus.find(x => x.id == id) != undefined)
        {
          voidStatusDesc = (this.ServiceStatus.find(x => x.id == id)).text; 
        }
        else if (id == 7)
        {
          voidStatusDesc = 'VOIDED';
        }

        return voidStatusDesc;
      },

      GetErrDesc: function() {
        // this.showMsg('Approved but DPEBB will not pay full acquisition cost requested by provider','','Service Code Message');
        
        var vm = this;
        vm.ErrorDesc = [];
        var params = new URLSearchParams();
            params.append('ClaimRequestNo', vm.ClaimRequestNo);
            //params.append('code', ErrorCode);
            axios.get('SaskHealthApi/Claims/GetClaimErrorDesc', { headers: { 'Authorization': 'Bearer ' + localStorage.access_token },params})
            .then(function (response) {
//                console.log(' error desc');
//                console.log(response.data)
                vm.ErrorDesc = response.data;
            }).catch(function (er) {
                console.log(er)
            }).then(function () {
                vm.GeneratePDF();     
            });
      },        

      GeneratePDF: function (event) 
      {
        var vm = this;
        console.log('csid:'+this.ClaimStatusID);

        //console.log('GeneratePDF')
        // generated from https://ezgif.com/image-to-datauri
        const skLogo = vm.SKLogoConst.Logo64Bit;
        
        const pdf = new jsPDF('l', 'mm', 'letter');
        const pageHeight = pdf.internal.pageSize.height;
        const pageWidth = pdf.internal.pageSize.width;
        const fontType = 'helvetica';

        function appendLeadingZeroes(n)
        {
          if(n <= 9)
          {
            return "0" + n;
          }
          return n
        }

        // Add Header and Footer to every page in report
        const addHeaderFooter = pdf => 
        {
          // get total number of pates
          const pageCount = pdf.internal.getNumberOfPages()

          // cycle through every page to add header/footer
          for (var i = 1; i <= pageCount; i++) 
          {
            pdf.setPage(i)

            var currDate = new Date();
            var rptDate = currDate.getFullYear() + "-" 
                             + appendLeadingZeroes(currDate.getMonth() + 1) + "-" 
                             + appendLeadingZeroes(currDate.getDate()) + " " 
                             + appendLeadingZeroes(currDate.getHours()) + ":" 
                             + appendLeadingZeroes(currDate.getMinutes()) + ":" 
                             + appendLeadingZeroes(currDate.getSeconds());
                  
            pdf.setFont(fontType);

            // Header Image                    
            pdf.addImage(skLogo,'png', 5, 5);//, 45, 18); //15,10,30,10); //5,5,30,10);
          
            // Header Title
            var rptTitle = vm.AppName;         
            if (vm.AppServiceID == 3) rptTitle = 'Optical';
            else if (vm.AppServiceID == 4) rptTitle = 'Hearing';
            else if (vm.AppServiceID == 5) rptTitle = 'Podiatry';
            rptTitle = rptTitle + ' - Void ' + vm.ClaimType;
          
            pdf.setFontSize(14);
            pdf.text(rptTitle, (pageWidth / 2), 10, 'center', 'center');    


            // Footer
            pdf.setFontSize(9);
            pdf.line(5, pageHeight - 10, pageWidth - 5, pageHeight - 10);
            pdf.text("Run Date: " + rptDate, 5, pageHeight - 5);

            pdf.setFontSize(8);    
            var copyRight = 'Copyright or Small Confidential Info????';            
            pdf.text(copyRight, pageWidth / 2 - copyRight.length / 2, pageHeight - 5);

            pdf.setFontSize(9);
            pdf.text("Page: " + String(i) + ' of ' + String(pageCount), pageWidth - 5, pageHeight - 5, {align: 'right'});
          }
        }

        // ------------------------
        // Patient Information
        // ------------------------
        var patsupprovList = [ { label1: '', value1: ''
                               , label2: '', value2: ''
                               , label3: '', value3: ''
                               }
                             , { label1: 'Patient:'     
                               , value1: this.selectedPatient.firstName + ' ' + this.selectedPatient.lastName
                               , label2: 'Clinic:'    
                               , value2: this.selectedClinic.clinicname
                               , label3: 'Provider:'    
                               , value3: this.selectedProvider.providername 
                               }
                             , { label1: 'HSN:'         
                               , value1: this.selectedPatient.hsn
                               , label2: 'Clinic #:' 
                               , value2: this.selectedClinic.clinicno
                               , label3: 'Provider #:'  
                               , value3: this.selectedProvider.providerno
                               }
                             , { label1: 'Address:'     
                               , value1: this.selectedPatient.address1 + ' ' + this.selectedPatient.address2
                               , label2: 'Address:'     
                               , value2: this.selectedClinic.address
                               , label3: 'Service:'     
                               , value3: this.selectedProvider.service 
                               }
                             , { label1: 'DOB:'         
                               , value1: moment(this.selectedPatient.birthDay).format('YYYY/MM/DD')
                               , label2: 'City:'        
                               , value2: this.selectedClinic.city
                               , label3: 'Service Type:'
                               , value3: this.selectedProvider.subtype 
                               }
                             ];

        var patsupprovHead = [//[],
                              [ {"content":"Patient Information","colSpan":2,"styles":{"cellWidth":"even"}}
                              , {"content":"Clinic Information","colSpan":2,"styles":{"cellWidth":"even"}}
                              , {"content":"Provider Information","colSpan":2,"styles":{"cellWidth":"even"}}
                              ]];

        // ------------------------
        // Patient Information
        // ------------------------
        pdf.autoTable
        (
          {
            theme: 'plain', 
            //startY: 15, //pdf.lastAutoTable.finalY + 3,   
            headStyles: 
            {
              font: fontType,
              fontSize: 12,
              fontStyle: 'bold',
            }, 
            styles: 
            {
              font: fontType,
              fontSize: 9,
              cellPadding: 0, 
              padding: 0, 
//                  cellspacing: 0, 
              border: 0
            }, 
            columnStyles: 
            {
              0: {cellWidth: 15}, 
              2: {cellWidth: 16},
              4: {cellWidth: 22}
            }, 
            body: patsupprovList, 
            head: patsupprovHead,
            columns: 
            [ {dataKey: 'label1'}
            , {dataKey: 'value1'}
            , {dataKey: 'label2'}
            , {dataKey: 'value2'}
            , {dataKey: 'label3'}
            , {dataKey: 'value3'}
            ],                                                     
            margin: 
            {
              top: 20,
              left: 5,
              right: 5,
              bottom: 20
            },  
            didParseCell: function (data) 
            {
              if (data.section === 'head')
              {
                if (data.row.index == 0) data.cell.styles.fillColor = [236,236,236];     // light grey  
                data.cell.styles.fontStyle = 'bold';                  
                data.cell.styles.cellPadding = 0;
              };

              // Bold for Legend column
              if (data.column.index === 0 || data.column.index === 2 || data.column.index === 4 ) 
              {
                data.cell.styles.fontStyle = 'bold';
              }
            },
//            didDrawPage: pageHeaderFooter 
          }
        );

        // ------------------------
        // Service Code Information
        // ------------------------
        {
          // set legend headers to show if true for ViewNotesCoverage or for Claim Status
          var headerInit = [ {code: 'scvoidaction', header: 'Void Action', show: true, assessor: false, legend: false, legendHeader:'', align:'left'}
                            , {code: 'scstatus', header: 'Previous Status', show: true, assessor: false, legend: false, legendHeader:'', align:'left'}
                            , {code: 'scerrorcode', header: 'Msg', show: true, assessor: false, legend: false, legendHeader:'', align:'left'}                             
                            , {code: 'scpriorapproval', header: 'Prior Approval #', show: true, assessor: false, legend: false, legendHeader:'', align:'left'}                             
                            , {code: 'scexpdate', header: 'Expiry Date', show: false, assessor: false, legend: false, legendHeader:'', align:'left'}                             
                            , {code: 'scdescription', header: 'Description', show: true, assessor: false, legend: false, legendHeader:'', align:'left'}
                            , {code: 'scservicecode', header: 'Service Code', show: true, assessor: false, legend: false, legendHeader:'', align:'left'}
                            , {code: 'scqty', header: 'Qty', show: true, assessor: false, legend: false, legendHeader:'', align:'left'}                             
                            , {code: 'scpaidamt', header: 'AA ($)', show: true, assessor: false, legend: true, legendHeader:'(AA) Assessed Amount', align:'right'}
                            , {code: 'scservicefee', header: 'SA ($)', show: true, assessor: false, legend: true, legendHeader:'(SA) ' + ((vm.AppServiceID == 3) ? 'Service' : 'Submitted') +' Amount', align:'right'}
                            , {code: 'scacqcost', header: 'UC ($)', show: true, assessor: false, legend: true, legendHeader:'(UC) Unit Cost', align:'right'}
                            , {code: 'scmarkup', header: 'MU (%)', show: true, assessor: false, legend: true, legendHeader:'(MU) Markup', align:'right'}
                            , {code: 'scshippingcostsub', header: 'SC ($)', show: false, assessor: false, legend: false, legendHeader:'(SC) Shipping Cost', align:'right'}
                            , {code: 'scshippingcostpaid', header: 'SP ($)', show: false, assessor: false, legend: false, legendHeader:'(SP) Shipping Paid', align:'right'}
                            , {code: 'scthirdpartyamt', header: '1PPA ($)', show: true, assessor: false, legend: true, legendHeader:'(1PPA) 1st Payer Paid Amount', align:'right'}
                            , {code: 'sctax1', header: 'Tax 1', show: false, assessor: false, legend: false, legendHeader:'', align:'left'}
                            , {code: 'sctax2', header: 'Tax 2', show: false, assessor: false, legend: false, legendHeader:'', align:'left'}
                            , {code: 'sctooth1', header: 'Tooth 1', show: false, assessor: false, legend: false, legendHeader:'(T1) Tooth 1', align:'left'}
                            , {code: 'sctooth2', header: 'Tooth 2', show: false, assessor: false, legend: false, legendHeader:'(T2) Tooth 2', align:'left'}
                            , {code: 'sccomments', header: 'Comments', show: false, assessor: false, legend: false, legendHeader:'', align:'left'}
                            , {code: 'scruncode', header: 'RC', show: true, assessor: false, legend: true, legendHeader:'(RC) Run Code', align:'left'}
                            , {code: 'scpaymentcode', header: 'PC', show: false, assessor: true, legend: true, legendHeader:'(PC) Payment Code', align:'left'}
                            , {code: 'sccovcode', header: 'CC', show: false, assessor: true, legend: true, legendHeader:'(CC) Coverage Code', align:'left'}
                            , {code: 'scplan', header: 'Plan', show: false, assessor: true, legend: false, legendHeader:'', align:'left'}
                            ];

          // If Prior Approval then show Expiry Date
          if (vm.ClaimType == 'Prior Approval') 
          {
            headerInit.find(tbl => tbl.code == 'scexpdate').show = true;
          }

          // If View Notes Coverage then show Payment Code, Coverage Code, Plan
          if (vm.ViewNotesCoverage)
          {
            headerInit.find(x => x.code == 'scpaymentcode' ).show = true;
            headerInit.find(x => x.code == 'sccovcode' ).show = true;
            headerInit.find(x => x.code == 'scplan' ).show = true;
          }
                        
          // Filter only Headers to show
          var headerList = headerInit.filter(hdr => hdr.show);
          var serviceColumnList = [];
          var serviceColumnHeaderList = [];
          for (var hdrIdx = 0; hdrIdx < headerList.length; hdrIdx++)   
          {    
            var serviceColumnObj = {};
            var serviceColumnHeaderObj = {};
            serviceColumnObj["title"] = headerList[hdrIdx].header;
            serviceColumnObj["dataKey"] = headerList[hdrIdx].code; 
            serviceColumnHeaderObj["id"] = headerList[hdrIdx].code;  
            serviceColumnHeaderObj["content"] = headerList[hdrIdx].header;  
            serviceColumnHeaderObj["styles"] = {"halign":headerList[hdrIdx].align};
            serviceColumnList.push(serviceColumnObj);
            serviceColumnHeaderList.push(serviceColumnHeaderObj);
          }

          // create data row for Service Codes to show
          var serviceBodyList = [];
          var serviceDataList = [];
          for (var srcIdx = 0; srcIdx < vm.SourceCodeData.length; srcIdx++)                                                     
          {
            var dataRowList = [];
            var labelVal = '';
            var valueVal = '';
            var showVal = '';
            var show = false;

            for (var hdrIdx = 0; hdrIdx < headerList.length; hdrIdx++)   
            {
              labelVal  = headerList[hdrIdx].code;
              showVal = headerList[hdrIdx].show;
              valueVal = '';     

              var validID = headerList[hdrIdx].validID;
              var assessorVal = headerList[hdrIdx].assessor;

              if ((assessorVal && this.ViewNotesCoverage) || !assessorVal)
              {
                switch(labelVal)
                {
                  // Void Action
                  case 'scvoidaction':
                    valueVal = vm.GetVoidStatusGP(vm.SourceCodeData[srcIdx].ovdstatusid);
                    break;

                  //Previous Status
                  case 'scstatus':
                    valueVal = vm.SourceCodeData[srcIdx].status;
                    break;

                  // Message
                  case 'scerrorcode':
                    valueVal = vm.SourceCodeData[srcIdx].errorcode;
                    break;

                  // Prior Approval
                  case 'scpriorapproval':
                    valueVal = '';            
                    var pa = vm.SourceCodeData[srcIdx].priorapproval; 
                    var idx = 0;
                    if (pa != null && pa != '') 
                    {
                      pa = pa.trim();
                      idx = pa.length/2;
                      var splitChar = (pa.length >0 ? '\n': '');
                      valueVal = pa.substring(0,idx) + splitChar + pa.substring(idx);
                    }
                    break;

                  // Expiry Date              
                  case 'scexpdate':
                    var expDateVal = vm.SourceCodeData[srcIdx].expirydate
                    valueVal =  ( expDateVal != null && expDateVal != '' ) ? moment(expDateVal).format('YYYY/MM/DD') : ''
                    break;

                  // Description
                  case 'scdescription':
                    valueVal = vm.SourceCodeData[srcIdx].description;
                    break;

                  // Service Code
                  case 'scservicecode':
                    valueVal = vm.SourceCodeData[srcIdx].servicecode;
                    break;

                  // Quantity
                  case 'scqty':
                    valueVal = vm.SourceCodeData[srcIdx].qty;
                    break;

                  // Assessed Amount
                  case 'scpaidamt':
                    valueVal = vm.SourceCodeData[srcIdx].paidamt.toFixed(2).replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
                    break;

                  // Service Amount/Submitted Amount
                  case 'scservicefee':
                    valueVal = vm.SourceCodeData[srcIdx].servicefee.toFixed(2).replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
                    break;

                  // Acq Unit Cost
                  case 'scacqcost':
                    valueVal = vm.SourceCodeData[srcIdx].acqcost.toFixed(2).replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
                    break;

                  // Markup %
                  case 'scmarkup':
                    valueVal = vm.SourceCodeData[srcIdx].markup.toFixed(3); 
                    //valueVal = (vm.SourceCodeData[srcIdx].markup * 100).toFixed(1);
                    break;

                  // Shipping Cost
                  case 'scshippingcostsub':
                    valueVal = vm.SourceCodeData[srcIdx].shippingcostsub.toFixed(2).replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
                    break;

                  // Shipping Paid
                  case 'scshippingcostpaid':
                    valueVal = vm.SourceCodeData[srcIdx].shippingcostpaid.toFixed(2).replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
                    break;

                  // 1PPA
                  case 'scthirdpartyamt':
                    valueVal = vm.SourceCodeData[srcIdx].thirdpartyamt.toFixed(2).replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
                    break;

                  // Tax 1
                  case 'sctax1':
                    valueVal = vm.SourceCodeData[srcIdx].tax1;
                    break;            

                  // Tax 2
                  case 'sctax2':
                    valueVal = vm.SourceCodeData[srcIdx].tax2;
                    break;            

                  // Tooth 1
                  case 'sctooth1':
                    valueVal = vm.SourceCodeData[srcIdx].tooth1;
                    break;

                  // Tooth 2
                  case 'sctooth2':
                    valueVal = vm.SourceCodeData[srcIdx].tooth2;
                    break;

                  // Comments
                  case 'sccomments':
                    valueVal = vm.SourceCodeData[srcIdx].comments.substring(0,39);
                    break;

                  // Run Code
                  case 'scruncode':
                    valueVal = vm.SourceCodeData[srcIdx].runcode;
                    break;

                  // Payment Code
                  case 'scpaymentcode':
                    valueVal = vm.SourceCodeData[srcIdx].paymentcode;
                    break;

                  // Coverage Code
                  case 'sccovcode':
                    valueVal = vm.SourceCodeData[srcIdx].codecoverage;
                    break;

                  // Plan
                  case 'scplan':
                    valueVal = vm.SourceCodeData[srcIdx].plan;
                    break;

                  default:
                }
                dataRowList.push({ label: labelVal, value: valueVal, show: showVal });               
              }
            }

            var serviceBodyObj = {};
            var serviceDataObj = {};

            // filter only Columns to show
            var svcList = dataRowList.filter(svcCol => svcCol.show);             
            // create data elements for Service Codes information
            for (var j = 0; j < svcList.length; j++)   
            {
              serviceBodyObj[svcList[j].label] = svcList[j].value;
            }  

            serviceBodyList.push(serviceBodyObj);    
          }
          
          var serviceHeadList = [//[],
                                [ {id: "rowHdr1", "content":"Service Code Information","colSpan":serviceColumnHeaderList.length} ],
                                [ {id: "rowHdr2", "content":"","colSpan":serviceColumnHeaderList.length,"styles":{"cellPadding":0, "border":0, "height":0.25}} ],
                                serviceColumnHeaderList
                                ];  

          var noServiceCodesFoundList = [];
          if (vm.SourceCodeData.length == 0)
          {
             serviceHeadList.push([{id: "rowHdr3", "content":"<< No Service Code Found >>","colSpan":serviceColumnHeaderList.length, "styles":{"cellPadding":0, "halign":"center", "fontStyle":"normal"}}]);
          }
                         

          //************************
          // Service Code Lines Table       
          //************************
          pdf.autoTable
          (
            {
              theme: 'plain', 
              startY: pdf.lastAutoTable.finalY + 7,   
              headStyles: 
              {
                font: fontType,
                fontSize: 12,
                fontStyle: 'bold',
                cellPadding: 0.5,
              }, 
              styles: 
              {
                font: fontType,
                fontSize: 9,
                cellPadding: 0.5, 
//                lineWidth: .5,
              }, 
              body: serviceBodyList, 
              head: serviceHeadList,
              columns: serviceColumnList,                                                     
              margin: 
              {
                top: 20,
                left: 5,
                right: 5,
                bottom: 20
              },  
              didParseCell: function (data) 
              {
                data.cell.styles.cellWidth = 'auto';
                if (data.section === 'head')
                {
                  if (data.row.index == 0) 
                  {
                    data.cell.styles.fillColor = [236,236,236];     // light grey                                      
                    data.cell.styles.cellPadding = 0;
                  }
                  else 
                  {
                    data.cell.styles.fontSize = 9;
//                    data.cell.styles.cellPadding = 0.5;
                  }
                }
                else
                {
                  data.cell.styles.halign = serviceColumnHeaderList[data.column.index].styles.halign;
//                  data.cell.styles.cellPadding = 0.5;
                }
              },
//              didDrawPage: pageHeaderFooter 
            }
          );

          //************************
          // Legend Information
          //************************
          {
            // initialize data matrix
            var legendList =[ 
                              { datakey1: 'Legend'
                              , datakey2: '          '
                              , datakey3: '          '
                              , datakey4: '          '
                              , datakey5: '          '
                              , datakey6: '          '
                              , datakey7: '          '
                              }
                            ];
            // filter only legend records to show
            var legendInit = headerInit.filter(hdrList => hdrList.legend);
                        
            // only show values with show = true and sort by code
            var showLegendList = _.sortBy( legendInit.filter(legend => legend.show), 'legendHeader' );

            // create second row if more than 6 values in list
            if (showLegendList.length > 6) 
            {
              var legendListb = { datakey1: '          '
                                , datakey2: '          '
                                , datakey3: '          '
                                , datakey4: '          '
                                , datakey5: '          '
                                , datakey6: '          '
                                , datakey7: '          '
                                };
              legendList.push(legendListb);
            }

            // update values in data matrix
            var cntLoop = 0;
            var cntRow = 0;
            for (var i = 0; i < showLegendList.length; i++) 
            {  
              cntRow++;
              var arrval = showLegendList[i].legendHeader;
              legendList[cntLoop]["datakey" + (cntRow+1)] = arrval;

              // add new line if need to since stores datakey 1-7                
              if (cntRow == 6) 
              {
                cntLoop++;
                cntRow = 0;
              }
            }

            //************************
            // Legend table        
            //************************
            pdf.autoTable
            (
              {
                theme: 'plain', 
                startY: pdf.lastAutoTable.finalY + 3,   
                headStyles: 
                {
                  font: fontType,
                  fontSize: 8,
                  fontType: 'bold',
                  cellPadding: 0                  
                }, 
                styles: 
                {
                  font: fontType,
                  fontSize: 8,
                  cellPadding: 0
                }, 
                body: legendList,
                head: [[]],
                columns: 
                [
                  { dataKey: 'datakey1' },
                  { dataKey: 'datakey2' },
                  { dataKey: 'datakey3' },
                  { dataKey: 'datakey4' },
                  { dataKey: 'datakey5' },
                  { dataKey: 'datakey6' },
                  { dataKey: 'datakey7' },              
                ], 
                columnStyles: 
                {
                  0: { cellWidth: 14}
                },   
                margin: 
                {
                  top: 20,
                  left: 5,
                  right: 5,
                  bottom: 20
                }, 
                didParseCell: function (data) 
                {
                  // Bold for Legend column
                  if (data.column.index === 0) data.cell.styles.fontStyle = 'bold';
                } 
              }
            );                    
          } // End Legend

          //************************
          // Message Codes
          //************************
          if (vm.ErrorDesc != null && vm.ErrorDesc != '' && vm.ErrorDesc.length != 0 && vm.SourceCodeData.length != 0)
          {
            pdf.autoTable
            (
              {
                theme: 'plain', 
                startY: pdf.lastAutoTable.finalY + 3,   
                headStyles: 
                {
                  font: fontType,
                  fontSize: 8,
                  fontType: 'bold',
                }, 
                styles: 
                {
                  font: fontType,
                  fontSize: 8,
                  cellPadding: 0, 
                }, 
                body: vm.ErrorDesc,
                head: [[],['Message', 'Description']],
                columns: 
                [
                  { dataKey: 'item1' },  //errorCode
                  { dataKey: 'item2' },  //errMsg
                ],
                columnStyles: 
                {
                  0: { cellWidth: 14}
                },   
                margin: 
                {
                  top: 20,
                  left: 5,
                  right: 5,
                  bottom: 20
                },  
              }
            );
          } // End Message Codes
        } // End Service Codes

        // ------------------------
        // Claim/Prior Approval Information
        // ------------------------
        function isEmpty(obj) 
        {
          for(var key in obj) 
          {
            if(obj.hasOwnProperty(key))
                return false;
          }
          return true;
        }

        var emptyRowObj = { label1: ''
                          , value1: '' 
                          };
        var payeeObj = {};
        if (this.vcdDetails.claimtype != 'PA' && this.ViewNotesCoverage && this.vcdDetails.reimbursementind == 'Y') 
        {
          payeeObj = { label1: 'Payee Name:'    
                     , value1: this.vcdDetails.payeegivenname
                     , label2: 'Address:'
                     , value2: {"content":this.vcdDetails.payeeaddress1.trim() + ', ' + this.vcdDetails.payeecity.trim() + ', ' + this.vcdDetails.payeepostalcode.trim() + ', ' + this.vcdDetails.payeeprov.trim(),"colSpan":3}                     
                     };
        }

        var overrideObj = {};
        if (this.ViewNotesCoverage)
          overrideObj = { label1: {"content":"Manual Approval Notes:","colSpan":1}
                        , value1: {"content":this.vcdDetails.overridenotes,"colSpan":5}
                        };                               

        var claimstatusObj =  { label1: this.ClaimType + ' Status:'    
                              , value1: this.ClaimStatus || this.ClaimStatusID 
                              };                               

        var claimList = [ { label1: '', value1: '' }
                        , { label1: {"content":"Notes:","colSpan":1}
                          , value1: {"content":this.vcdDetails.claimNotes,"colSpan":5}  
                            }
                        , { label1: ''
                          , value1: '' 
                          }
                        , { label1: 'Service Date:'    
                          , value1: moment(this.vcdDetails.serviceDate).format('YYYY/MM/DD')
                          , label2: 'Lab Name:'
                          , value2: this.vcdDetails.labname
                          , label3: '1st Payer Paid Amount:'
                          , value3: this.vcdDetails.thirdPartyPaid  
                          }
                        , { label1: 'Temporary Health Certificate (THC):'
                          , value1: this.vcdDetails.thc
                          , label2: 'THC Effective Date:'
                          , value2: ( this.vcdDetails.thc == 'Y' ) ? moment(this.vcdDetails.thcEffect).format('YYYY/MM/DD') : ''
                          , label3: 'THC Expiry Date:'
                          , value3: ( this.vcdDetails.thc == 'Y' ) ? moment(this.vcdDetails.thcExpiry).format('YYYY/MM/DD') : ''                            
                          }
                        , { label1: 'X-Rays and Documents:'    
                          , value1: this.vcdDetails.attachmentind
                          , label2: 'Reimburse to Patient:'
                          , value2: this.vcdDetails.reimbursementind}
                        ];

        if (!isEmpty(payeeObj)) 
        {
          claimList.push(payeeObj);
        }

        if (!isEmpty(overrideObj)) 
        {
          claimList.push(emptyRowObj);               
          claimList.push(overrideObj);         
        }

        claimList.push(emptyRowObj); 
        claimList.push(claimstatusObj);            

        var claimPA = this.ClaimType + ' Information';
        var claimHead = [
             //[],
             [ {"content":claimPA,"colSpan":6,"styles":{"cellWidth":"even"}} ]];

        
        pdf.autoTable
        (
          {
            theme: 'plain', 
            startY: pdf.lastAutoTable.finalY + 7,   
            headStyles: 
            {
              font: fontType,
              fontSize: 12
            },            
            styles: 
            {
              font: fontType,
              fontSize: 9,
              cellPadding: 0, 
              padding: 0, 
              cellWidth: 'wrap'
            }, 
            columnStyles: 
            {
              0: {cellWidth: 55}, 
              1: {cellWidth: 'auto'}, 
              2: {cellWidth: 34}, 
              3: {cellWidth: 50}, 
              4: {cellWidth: 37},
              5: {cellWidth: 'auto'}
            }, 
            body: claimList, 
            head: claimHead,
            columns: 
            [ {dataKey: 'label1'}
            , {dataKey: 'value1'}
            , {dataKey: 'label2'}
            , {dataKey: 'value2'}
            , {dataKey: 'label3'}
            , {dataKey: 'value3'}
            ],
                                                  
            margin: 
            {
              top: 20,
              left: 5,
              right: 5,
              bottom: 20
            },  
            didParseCell: function (data) 
            {
              if (data.section === 'head' && data.row.index == 0)
              {data.cell.styles.fontStyle = 'bold';
                data.cell.styles.fillColor = [236,236,236];     // light grey  
                data.cell.styles.cellPadding = 0;
                if (data.column.index === 0) data.cell.colspan = 2;
                if (data.column.index === 1) data.cell.colspan = 0;
              };

              // Bold for Legend column
              if (data.column.index === 0 || data.column.index === 2 || data.column.index === 4 ) data.cell.styles.fontStyle = 'bold';
            },
          }
        );

        // draw the header/footers on each page
        addHeaderFooter(pdf);

        // save the pdf file
        if (this.vcdDetails.claimtype === 'PA')
          pdf.save('voidPriorApproval.pdf');
        else
          pdf.save('voidClaim.pdf');

      },

      VoidMsg(msg,data) {
          this.boxTwo = ''
          this.$bvModal.msgBoxConfirm(msg, {
          title: 'Please Confirm',
          size: 'md',
          buttonSize: 'md',
          okVariant: 'danger',
          cancelVariant: 'default',
          okTitle: 'YES',
          cancelTitle: 'NO',
          footerClass: 'p-2',
          hideHeaderClose: true,
          centered: true, 
          })
            .then(value => {
              this.boxTwo = value
              if(value)
              {
                  this.SaveClaim();
              }
            })
            .catch(err => {
              // An error occurred
            })
      },
      Exit: function (event) {
        //this.$root.$emit('bv::hide::modal', 'phModal', '#btnShow'); 
        this.$emit('finished');
      }, 
      LoadClaimDocs(claimRequestNumber) {
        var vm = this;
        var params = new URLSearchParams();
//        params.append("claimRequestNo", claimRequestNo);
        params.append("claimRequestNo", this.claimRequestNumber);        
        axios.get('SaskHealthApi/Claims/GetClaimDocumentsByClaimRequestNo', {
        headers: {
          'Authorization': 'Bearer ' + localStorage.access_token}, params})
        .then(function (response) {
          vm.docList = response.data;
         })
       .catch(function (er) {
            vm.docList = [];
            console.log(er)
            this.$bvModal.msgBoxOk(er);
         })
      }, 
      OpenClaimDoc(row) {
        var dl = document.createElement('a');
        dl.target = '_blank';
        dl.download = row.docname;
        //The atob function will decode a base64-encoded string into a new string with a character for each byte of the binary data.
        const byteChar = atob(row.doc);
        //Each character's code point (charCode) will be the value of the byte. 
        //We can create an array of byte values by applying this using the .charCodeAt method for each 
        //character in the string.
        const byteNumbers = new Array(byteChar.length);
        for (let i = 0; i < byteChar.length; i++) {
            byteNumbers[i] = byteChar.charCodeAt(i);
        }
        //You can convert this array of byte values into a real typed byte array by passing it to the Uint8Array constructor.
        const byteArray = new Uint8Array(byteNumbers);
        //This in turn can be converted to a Blob by wrapping it in an array and passing it to the Blob constructor.
        var blob = new Blob([byteArray], {type: row.doctype});
        //create the URL for the blob, then open it
        var URL = window.URL || window.webkitURL;
        if (window.navigator && window.navigator.msSaveOrOpenBlob) {
            window.navigator.msSaveOrOpenBlob(blob);  
        }
        else {
            var dlURL = URL.createObjectURL(blob);
            window.open(dlURL);
        }
      }, 
      getMsgClass(value) 
        {
          return ( value>= 3000 ) ? 'text-danger' : 'text-primary';
        },
      getErrorStyle(value) 
      {
        return ('width: 7.5rem !important;  padding:3px !important;')
      },
      GetMsg: function(row) {
         var vm = this; 
          var params = new URLSearchParams(); 
      
          if(row.overrideind == 'D' || row.overrideind == 'F') 
            params.append('program','HCHXA040');
          else if(row.overrideind == 'N' && row.errorcode == '6000') 
            params.append('program','HCHXA040');
          else
          {
            params.append('program', vm.ProgrameName);
          }            
          params.append('code', row.errorcode);
           //console.log('program = ' + params)
          axios.get('SaskHealthApi/Codes/GetMessage', { headers: { 'Authorization': 'Bearer ' + localStorage.access_token },params})
          .then(function (response) {
              vm.showMsg(response.data,'','Service Code Message')
          }).catch(function (er) {
              console.log(er)
          }).then(function () {
                
          }); 
      }, 
      ChangeServiceStatus : function($event,serviceid){
      var NewStatusId = parseInt($event.target.value); 
         var vm = this; 
            var url = "/SaskHealthApi/Claims/PostUpdateVoidStatus/"
            var params = {
                "_": Date.now(),
                "ServiceCodeID": serviceid,
                "NewStatusID": NewStatusId                
                } 
           axios({
              method: 'post',
              url: url,
              headers: { 'Authorization': 'Bearer ' + vm.$store.getters.GetAccessToken },
              data: params
            }).then(function (response) {
                  console.log(response.data)
                  if(response.data ==true)
                  {
                      vm.BtnSubmitdisabled=false;
                  }
            }).catch(function (er) {
                    console.log(er)
                }).then(function () {
                    vm.GetServiceCodes();
                }); 
      },


        Go(){
            this.$router.push('/DPEBB/MainHome')
        },
         Show(){
             this.Showinfo =true;
        }, 
        GetClaimOverride(){
            var vm = this;
              axios.get('SaskHealthApi/Codes/CanOverRideClaim', { headers: { 'Authorization': 'Bearer ' + localStorage.access_token }})
             .then(function (response) {
                   vm.CanOverRide = response.data;
                   //this.SelectedClaimStatus = this.ClaimStatus.find(x=>x.statusid === 3);
                   //console.log(this.SelectedClaimStatus)
                })
            .catch(function (er) {
                console.log(er)
            }).then(function()
            {

            })
        },
        GetAssessor(){
            var vm = this;
              axios.get('SaskHealthApi/Codes/IsAssessorOrSuper', { headers: { 'Authorization': 'Bearer ' + localStorage.access_token }})
             .then(function (response) {
                   vm.ViewNotesCoverage = response.data; 
                })
            .catch(function (er) {
                console.log(er)
            }).then(function()
            {
              //console.log (vm.ViewNotesCoverage)
                if(vm.ViewNotesCoverage == true)
                {
                  vm.dis=false;
                  if(vm.vcdDetails.claimtype =="CL")
                    {
                       vm.columns=['ovid','status','errorcode','priorapproval','description','servicecode','qty','paidamt','servicefee','acqcost','markup','shippingcostsub','shippingcostpaid','thirdpartyamt','tax1','tax2','runcode','paymentcode','codecoverage','plan'];
                    }
                   else if(vm.vcdDetails.claimtype =="PA")
                    {
                       //vm.columns= ['ovid','status','errorcode','priorapproval','expirydate','description','servicecode','qty','paidamt','servicefee','acqcost','markup','shippingcostsub','shippingcostpaid','thirdpartyamt','tax1','tax2','runcode','paymentcode','codecoverage','plan'];
                       vm.columns= ['ovid','status','errorcode','priorapproval','expirydate','description','servicecode','qty','paidamt','servicefee','acqcost','markup','thirdpartyamt','runcode','paymentcode','codecoverage','plan'];
                    }
                }
                else if(vm.ViewNotesCoverage ==false)
                {
                    if(vm.vcdDetails.claimtype =="CL")
                    {
                       vm.columns=['ovid','status','errorcode','priorapproval','description','servicecode','qty','paidamt','servicefee','acqcost','markup','shippingcostsub','shippingcostpaid','thirdpartyamt','tax1','tax2','runcode'];
                    }
                   else if(vm.vcdDetails.claimtype =="PA")
                    {
                       //vm.columns= ['ovid','status','errorcode','priorapproval','expirydate','description','servicecode','qty','paidamt','servicefee','acqcost','markup','shippingcostsub','shippingcostpaid','thirdpartyamt','tax1','tax2','runcode'];
                       vm.columns= ['ovid','status','errorcode','priorapproval','expirydate','description','servicecode','qty','paidamt','servicefee','acqcost','markup','thirdpartyamt','runcode'];                       
                    }
                }
            })
        },

        GetVoidStatus(){ 
          var vm = this;
           var params = new URLSearchParams(); 
          params.append('ClaimRequestNo', this.ClaimRequestNo);
          axios.get('SaskHealthApi/Claims/GetVoidStatus', { headers: { 'Authorization': 'Bearer ' + localStorage.access_token },params}) 
          .then(function (response) {
                vm.ServiceStatus = response.data;
                //this.SelectedClaimStatus = this.ClaimStatus.find(x=>x.statusid === 3);
                //console.log(this.SelectedClaimStatus)
            })
        .catch(function (er) {
            console.log(er)
            }).then(function()
            {
                
            })
        },
        GetClaimStatus(){ 
          var vm = this;
          var params = new URLSearchParams();
          params.append('ClaimID', this.ClaimRequestNo);
          axios.get('SaskHealthApi/Claims/GetClaimStatus', { headers: { 'Authorization': 'Bearer ' + localStorage.access_token },params})
          .then(function (response) {
              if(response.data !== null)
              {
                 
                  vm.ClaimStatus = response.data.claimstatus[0].text; 
                  vm.ClaimStatusID =response.data.claimstatus[0].id; 
                 // vm.SelectedClaimStatus =vm.ClaimStatus.find(x=>x.id === response.data.selectid);
                  
              }           
            })
            .catch(function (er) {
                console.log(er)
            }).then(function()
          {
              
          })
        },
        GetServiceCodes(){ 
           var vm = this;
            var params = new URLSearchParams();
            params.append('ServiceID', this.AppServiceID);
            params.append('ClaimRequestNo', this.ClaimRequestNo);
             axios.get('SaskHealthApi/Claims/GetServiceCodePerReq', { headers: { 'Authorization': 'Bearer ' + localStorage.access_token },params})
             .then(function (response) { 
                    vm.SourceCodeData = response.data; 
                })
            .catch(function (er) {
                console.log(er)
            }).then(function()
            {
              // if(vm.SourceCodeData.length ==0)
              //   {
              //         vm.BtnSubmitdisabled=true;
              //   }
              //   else
              //   {
              //       vm.BtnSubmitdisabled=false;
              //   } 

               var r =  _.find(vm.SourceCodeData, function(o) { return o.ovdstatusid ==3; });
               //console.log('result=   '+r);
               if(r !=undefined)
               {
                 vm.ServiceCodeError =true;
                 console.log(r.priorapproval);
               }
               else
               {
                  vm.ServiceCodeError =false;
               }
            })
        },
         GetProvider(){

           var vm = this;
            var params = new URLSearchParams();
             params.append('ServiceID', this.AppServiceID);
             axios.get('SaskHealthApi/Codes/GetProvidersByService', { headers: { 'Authorization': 'Bearer ' + localStorage.access_token },params})
             .then(function (response) { 
                    vm.Provider = response.data; 
                })
            .catch(function (er) {
                console.log(er)
            })
        },
        GetClinics(){
          var vm = this; 
          var params = new URLSearchParams();
          params.append('ServiceID', this.AppServiceID);
          axios.get('/SaskHealthApi/Codes/GetUserClinic', { headers: { 'Authorization': 'Bearer ' + localStorage.access_token }, params}) 
          .then(function (response) {
                    //vm.Clinic.push(response.data);
                    vm.Clinic = response.data;
                   console.log(response.data);
                    // console.log(vm.Clinic)
                })
            .catch(function (er) {
                console.log(er)
              //{clinicno: 99999, clinicname: "99999 CLINIC", address: "99999 ", city: " Regina", province: "SK"}   
            }).then(function()
                  {
                      vm.SelectedClinic = {clinicno:  vm.Clinic[0].clinicno, clinicname: vm.Clinic[0].clinicname, address:  vm.Clinic[0].address, city:  vm.Clinic[0].city, province:  vm.Clinic[0].province}   
                      console.log(vm.SelectedClinic)
                  })
       
       },
        showMsgBox(msg,data) {
          this.boxTwo = ''
          this.$bvModal.msgBoxConfirm(msg, {
          title: 'Please Confirm',
          size: 'md',
          buttonSize: 'md',
          okVariant: 'danger',
          cancelVariant: 'default',
          okTitle: 'YES',
          cancelTitle: 'NO',
          footerClass: 'p-2',
          hideHeaderClose: true,
          centered: true, 
          })
            .then(value => {
              this.boxTwo = value
              if(value)
              {
                //console.log(data);
                  this.DeleteServiceCode(data);
                  //console.log(data)
              }
            })
            .catch(err => {
              // An error occurred
            })
      },
      showMsg(msg,data,Title) {
          this.boxTwo = ''
          this.$bvModal.msgBoxOk(msg, {
          title: Title,
          size: 'md',
          buttonSize: 'md',
          okVariant: 'danger',          
          okTitle: 'Close', 
          footerClass: 'p-2',
          hideHeaderClose: true,
          hideHeaderCancel: true,
          centered: true, 
        })
          .then(value => {
            this.boxTwo = value
            if(value)
            {
             
            }
          })
          .catch(err => {
            // An error occurred
          })
      },
      SaveClaim(){ 
        if(this.ServiceCodeError)
        {
            this.showMsg("There is an ERROR at Service Code, to re submit please change it to PENDING.",'','Service Code Error');
        }
        else
        {
        var vm = this;  
        var title = vm.ClaimType.concat(" Message !");
        //console.log (msg)
        var params = new URLSearchParams();
        params.append('ClaimRequestNo', this.ClaimRequestNo);
        params.append('ServiceID', this.AppServiceID);
        axios.get('/SaskHealthApi/Claims/GetVoidClaimResult/', { headers: { 'Authorization': 'Bearer ' + localStorage.access_token },params})
          .then(function (response) { 
            vm.showMsg(response.data,'',title); 
        }).catch(function (er) {
                console.log(er)
            }).then(function () {   
                vm.GetVoidStatus();              
                vm.GetServiceCodes(); 
                vm.GetClaimStatus()
            });
        }  
        }

    },
    computed:{
    },
    created: function() { 
        this.AppServiceID = this.ServiceID
        console.log('Service ID= '+ this.AppServiceID)      
        this.dateFormat = this.$store.getters.GetDateFormat; 
        this.ServiceDate=moment(new Date()).format('YYYY/MM/DD');
        this.ClaimRequestNo =  this.claimRequestNumber; 
        console.log("Claim Type: "+this.vcdDetails.claimtype);
        if(this.vcdDetails.claimtype =="CL")
        {
          this.ProgrameName = 'HCHXA020';
          this.ClaimType ="Claim";
        }
        if(this.vcdDetails.claimtype =="PA")
        {
          this.ProgrameName = 'HCHXA010';
          this.ClaimType ="Prior Approval";
        }
        
       // this.GetClinics();
       // this.GetProvider();
        //this.GetClaimStatus();
       
        this.GetAssessor(); 
        this.GetServiceCodes(); 
        this.GetVoidStatus();
        this.GetClaimStatus();
        this.LoadClaimDocs(parseInt(this.ClaimRequestNo));
    
    },
    beforeCreate: function() {  
    },
     mounted: function () {
     this.$nextTick(function () { 
      })
    },
}
</script>
<style scopped> 
 .row.no-gutter [class*='col-']   {
   padding-right:1px; 
 }
 .list-group-item {
    position: relative;
    display: block;
    padding: 0px 15px;
    margin-bottom: -1px;
    border: 1px solid #ddd;
    background-color: blue;
    line-height: 1em
} 
.col-lg-1>div {background-color:#ddd;} 
#docimg { 
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50; 
  /* margin-top: 10px; */
}
#line {
  border-top:1px solid   rgba(7, 14, 109, 0.25);
 
} 
 .select-css {
    display: block;
    font-size: 14px;
    /* font-family: sans-serif; */
    font-weight: 600;
    color: #444;
    line-height: 1.3;
    padding: .6em 1.4em .5em .8em;
    width: 100%;
    max-width: 100%; 
    box-sizing: border-box;
    margin: 0;
    border: 1px solid #aaa;
    box-shadow: 0 1px 0 1px rgba(0,0,0,.04);
    border-radius: .5em;
    -moz-appearance: none;
    -webkit-appearance: none;
    /* appearance: none; */
    background-color: #fff;
    background-image: url('data:image/svg+xml;charset=US-ASCII,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22292.4%22%20height%3D%22292.4%22%3E%3Cpath%20fill%3D%22%23007CB2%22%20d%3D%22M287%2069.4a17.6%2017.6%200%200%200-13-5.4H18.4c-5%200-9.3%201.8-12.9%205.4A17.6%2017.6%200%200%200%200%2082.2c0%205%201.8%209.3%205.4%2012.9l128%20127.9c3.6%203.6%207.8%205.4%2012.8%205.4s9.2-1.8%2012.8-5.4L287%2095c3.5-3.5%205.4-7.8%205.4-12.8%200-5-1.9-9.2-5.5-12.8z%22%2F%3E%3C%2Fsvg%3E'),
    linear-gradient(to bottom, #ffffff 0%,#e5e5e5 100%);
    background-repeat: no-repeat, repeat;
    background-position: right .7em top 50%, 0 0;
    background-size: .65em auto, 100%;
}
.select-css::-ms-expand {
    display: none;
}
.select-css:hover {
    border-color: #888;
}
.select-css:focus {
    border-color: #aaa;
    box-shadow: 0 0 1px 3px rgba(59, 153, 252, .7);
    box-shadow: 0 0 0 3px -moz-mac-focusring;
    color: #222; 
    outline: none;
}
.select-css option {
    font-weight:normal;
}
#ServiceCodeGrid .VuePagination__count{
  visibility: hidden;
  height:0px;
}
#ServiceCodeGrid .pagination{
  height:0px
} 
.highlight {
    background-color: #fff2ac;
    background-image: linear-gradient(to right, #ffe359 0%, #fff2ac 100%);
}
.bd-highlight {
    /* background-color: rgba(86,61,124,0.15); */
    /* border: 1px solid rgba(86,61,124,0.15); */
    background-image: linear-gradient(to right, #ffe359 0%, #fff2ac 100%);
    /* background-image: linear-gradient(to right, #ac9732ad 0%, #cebc5985 100%); */
    /* text-decoration-line: underline; */
    font-weight: bold;
    padding: .4rem;
    margin: 0rem !important;
    
} 
.cov { 
    font-size: 1.3rem;
    font-weight: bolder;
    /* padding: .2rem; */
    margin: 0rem !important; 
}
</style>