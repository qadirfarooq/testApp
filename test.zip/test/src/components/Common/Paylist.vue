<template>
<div>
<Subtitle  v-bind:ServiceID="this.AppServiceID">
   <template v-slot:header>
    <i class="fas fa-file-invoice-dollar "></i><b>Paylist View:</b>
  </template> 
</Subtitle>
 <div class="row mt-2 no-gutters">
      <div class="col-6 pr-1">    
        <div class="card">
        <div class="card-header   d-flex align-items-center  pl-1" style="height: 2rem; text-align:left;">
          <h5><small class="text-muted"><b><i class="fas fa-upload"></i> Run Code Information</b></small></h5>
        </div>    
        <div class="mb-2">    
          <transition name="slide-fade">            
            <v-client-table :columns="columns" :data="runcodes" :options="options">
            <template slot="view" slot-scope="props">
                <span class="pointer"   v-on:click="GetPaylistInfo(props.row.runcode)"><i class="fas fa-eye"></i></span>
            </template>
            </v-client-table>   
           </transition>
        </div>
        </div>
     </div>

    <div class="col-6 pr-1 " v-if="Clinic.length">
        <div class="card">
        <div class="card-header   d-flex align-items-center  pl-1" style="height: 2rem; text-align:left;">
          <h5><small class="text-muted"><b><i class="fas fa-clinic-medical"></i>Clinic: {{Clinic[0].clinicname}}</b></small></h5>
        </div>
         <div  class="card-body p-2 mb-1" v-if="Clinic.length"> 
            <div class="row">
            <span for="cname" class="col-sm-4"><b>Clinic #:</b></span> 
            <span class="col-sm-8" type="text">{{Clinic[0].clinicno}}</span> 
            </div>
            <div class="row">
            <span for="cname" class="col-sm-4"><b>Address:</b></span> 
            <span class="col-sm-8" type="text">{{Clinic[0].address}}</span> 
            </div>
            <div class="row">
            <span for="cname" class="col-sm-4"><b>City:</b></span> 
            <span class="col-sm-8" type="text">{{Clinic[0].city}}</span> 
            </div> 
        </div>
        </div>
      </div>

  </div>
<div class="row mt-2 no-gutters" v-if="ShowPaylist">
    <div class="card-header  col-sm-7   d-flex align-items-center  pl-1" style="height: 2rem; text-align:left;" >
        <h5><small class="text-muted pr-2"><b> Paylist Detail Information for run code : {{SelectedCode}}</b></small></h5>
    </div> 
    <div class="col-sm-5 card-header d-flex align-items-center " style="height: 2rem; text-align:right; padding-left:23rem;">
        
        <download-excel class="pointer"
            :data   = "PaylistData"    type    = "csv"           
            name    = "PaylistInformation.csv"
            :labels="{ patientname: 'Patient Name',hsn:'HSN',providername:'Provider Name',providerno:'Provider No', claimno:'Claim No',
            servicedate:'Service Date', servicecode:'Service Code', amtcharged:'Amt Charged', amtpaid:'Amt Paid'}"
            >
            <span class="text-muted pointer fas fa-file-download text-muted  fa-lg mt-2" ></span><b class="text-muted ml-2">Download</b>
        </download-excel> 
        <!-- <download-csv
            class = "fas fa-file-download text-muted pointer fa-lg mt-2"
            :data   = "PaylistData"
            name    = "PaylistInformation.csv"
            :labels="{ patientname: 'Patient Name',hsn:'HSN',providername:'Provider Name',providerno:'Provider No', claimno:'Claim No',
            servicedate:'Service Date', servicecode:'Service Code', amtcharged:'Amt Charged', amtpaid:'Amt Paid'}"
            >  
            &nbsp;
        </download-csv> <small class="text-muted pointer" ><b>Download  &nbsp;</b></small></h5> -->
    </div>
</div>

  <div id="PalistDetailsGrid" class="mt-2" v-if="ShowPaylist">
        <v-client-table :columns="Paycolumns" :data="PaylistData" :options="Payoptions">
            <span class="float-right" slot="__group_meta" slot-scope="{ data }">
            <b>Amt Paid Total: ${{data}}</b>
            </span>
            <div slot="afterFilter"  class="ml-3 "> 
                <button type="button"  v-if="ShowPaylist" class="btn BtnClose mt-4" v-on:click="PrintPaylist">Print Paylist</button>
            </div>
        </v-client-table>   
  </div>
 
</div>
</template>
<script>
import {mapGetters} from 'vuex'
import axios from 'axios'
import Vue from 'vue';
import moment from 'moment'
import Card from "@/Common/Card.vue";
import CardBody from "@/Common/CardBody.vue";
import LayoutDefault from '@/Common/Default/DefaultLayout.vue'; 
import Subtitle from '@/Common/Default/SubTitle.vue'; 
import { PopUpVariant } from '@/Common/Default/PopUpVariant';
import TileNote from "@/Common/TileNote.vue";
 
//import { scrypt } from 'crypto';
// import JsonCSV from 'vue-json-csv'
// Vue.component('downloadCsv', JsonCSV)
import JsonExcel from 'vue-json-excel'; 
Vue.component('downloadExcel', JsonExcel)

export default {
    props:{
      Mode:'',
      Type:''
    },
    data: function(){
        return {
            doc64String:'',
            Clinic: [],
            ShowPaylist:false,
            decimal:'',
            ClinicNo: '',
            //RunCode: '',
            runcodes: [],
            SelectedCode:'',
            paymentrundate:'',
            AppName:'', 
            AppIcon:'',
            type:'',
            showEdit:true,
            showPDF:false,
            size:'',
            id:'',
            showEditModal:false,
            showModal:false,
            succeeded:false,
            Msg:'',
            Button:'',
            PopUpVar:PopUpVariant,
            columns: ['view','paymentrundate','runcode'],
            Paycolumns: ['providerno','providername','patientname','hsn','claimno','servicedate','servicecode','amtcharged','amtpaid'],
            PaylistData: [],
            groupTot:[],
            paylistLabels:[],
            options: {
                texts:{
                    count:"",
                    first:'First',
                    last:'Name',
                    filter:"Search Paylist Data:",
                    filterPlaceholder:"Search in table",
                    limit:"Records:",
                    page:"Page:",
                    noResults:"No matching records",
                    filterBy:"Filter by {column}",
                    loading:'Loading...',
                    defaultOption:'Select {column}',
                    columns:'Columns'                                       
                },             
       
                responseAdapter({data}) {                
                    return {
                    data: formatData,
                    count: data.length
                    };                    
                },
                footerHeadings :false,
                perPage:10,
                perPageValues:[10,15,25],
                dateColumns:['paymentrundate'],
                toMomentFormat: 'YYYY-MM-DD',                   
                templates: {
                    paymentrundate(h, row) {
                        return moment(row.paymentrundate, "YYYY-MM-DD").format('YYYY/MM/DD'); 
                    },                                    
                },
                    
                headings: {
                    paymentrundate: 'Payment Run Date',
                    runcode: 'Runcode',
                    view: 'View Detail',
                    download: 'Download'                   
                }, 
                sortable: ['paymentrundate','runcode'],
                filterable: [], 
                sortIcon: {
                    base : 'fas',
                    is: 'fa-sort',
                    up: 'fa-sort-up',
                    down: 'fa-sort-down'
                },
            },

            Payoptions: {
                texts:{
                    count:"Showing {from} to {to} of {count} records|{count} records|One record",
                    first:'First',
                    last:'Name',
                    filter:"Search Paylist Data:",
                    filterPlaceholder:"Search in table",
                    limit:"Records:",
                    page:"Page:",
                    noResults:"No matching records",
                    filterBy:"Filter by {column}",
                    loading:'Loading...',
                    defaultOption:'Select {column}',
                    columns:'Columns',
                
                },        
                    groupBy:'providerno',
                    groupMeta:[],     
                 responseAdapter({data}) {                
                    return {
                    data: formatData,
                    count: data.length
                    };                    
                },                
                perPage:10,
                perPageValues:[10],
                toMomentFormat: 'YYYY-MM-DD',                   
                templates: {
                    servicedate(h, row) {
                        return moment(row.servicedate, "YYYY-MM-DD").format('YYYY/MM/DD'); 
                    },
                    amtcharged(h,row){
                        return <div>${Number.parseFloat(row.amtcharged).toFixed(2)}</div> ;  
                    },
                    amtpaid(h,row){
                       return <div>${Number.parseFloat(row.amtpaid).toFixed(2)}</div> ;  
                    },                   
                },                    
                headings: {
                    patientname: 'Patient Name',
                    hsn: 'HSN',
                    providername: 'Provider Name',
                    providerno: 'Provider No',
                    claimno: 'Claim No',
                    servicedate: 'Service Date',
                    servicecode: 'Service Code',
                    amtcharged: 'Amt Charged', 
                    amtpaid: 'Amt Paid'                  
                },
         
                sortable: ['patientname','hsn','providername','providerno','claimno','servicedate','servicecode','amtcharged','amtpaid'],
                 filterable: [], 
                sortIcon: {
                    base : 'fas',
                    is: 'fa-sort',
                    up: 'fa-sort-up',
                    down: 'fa-sort-down'
                },
            }



        }
    },
    components: {

        //Modal:Modal,
        Card,
        CardBody,
        TileNote,
        Subtitle,
        
    },   
    created:function(){
      this.AppServiceID = this.Type;  
       this.paylistLabels = [{value:'patientnName', key:"dfasdf"}]
       var distintProviders = [ new Set(this.PaylistData.map(x=>x.providerno))];
       this.GetClinics(); 


    },
    beforeCreate: function() {  
 
    },
     mounted:function (){
        this.$nextTick(function () {      
        //this.GetClinics();
      })
    },
    computed:{
        UserName(){
           return !this.$store.getters.GetCurrentUser ? false : this.$store.getters.GetCurrentUser;
        },
    }, 
    methods:{
     PrintPaylist(){
        const b64toBlob = (b64Data, contentType='', sliceSize=512) => {
        const byteCharacters = atob(b64Data);
        const byteArrays = []; 
        for (let offset = 0; offset < byteCharacters.length; offset += sliceSize) {
            const slice = byteCharacters.slice(offset, offset + sliceSize);

            const byteNumbers = new Array(slice.length);
            for (let i = 0; i < slice.length; i++) {
            byteNumbers[i] = slice.charCodeAt(i);
            }

            const byteArray = new Uint8Array(byteNumbers);
            byteArrays.push(byteArray);
        } 
        const blob = new Blob(byteArrays, {type: contentType});
        return blob;
        }   

        var vm = this;
        //this.SelectedCode = runcode;
        this.ShowPaylist = true;
        var url = '/SaskHealthApi/FileGenerater/GetPaylistPdf?_='         
        var params = new URLSearchParams();
        params.append('clinicno', vm.ClinicNo);
        params.append('runcode', this.SelectedCode);
        axios.get(url+Date.now(), { responseType: 'blob',headers: { 'Authorization': 'Bearer ' + localStorage.access_token },params})
        .then(function (response) { 
        //const url = window.URL.createObjectURL(new Blob([response.data]));
        const byteArray = new Uint8Array(response.data);  
        let blob = new Blob([response.data], {
            "type": "application/pdf"
        });
        const fileName = vm.ClinicNo+".pdf";
        //This in turn can be converted to a Blob by wrapping it in an array and passing it to the Blob constructor.
        if (navigator.msSaveBlob) {    
        navigator.msSaveBlob(blob, fileName);
        }
        else {
       // let blob = new Blob(['\ufeff' + data], { type: 'text/csv;charset=utf-8;' });
        //let $link = document.createElement("a");
        let url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;        
        link.setAttribute('download', fileName);
        document.body.appendChild(link);
        link.click();
        }        


  

     })
    .catch(function (er) {
    console.log(er)
    });
        
        },
  
        GetPaylistInfo(runcode){
            var vm = this;
            this.SelectedCode = runcode;
            this.ShowPaylist = true;
            var url = '/SaskHealthApi/Codes/GetPaylistDetails?_='         
             var params = new URLSearchParams();
             params.append('ClinicNo', vm.ClinicNo);
             params.append('RunCode', runcode);
              axios.get(url+Date.now(), { headers: { 'Authorization': 'Bearer ' + localStorage.access_token },params})
                 .then(function (response) {  
                     vm.PaylistData=response.data; 
                     vm.groupTot = [];
                       var distintProviders = [ new Set(vm.PaylistData.map(x=>x.providerno))];
                        //  console.log(distintProviders);
                         distintProviders[0].forEach(element => {
                            //  console.log(element);
                            var subset = vm.PaylistData.filter(x=>x.providerno == element);
                            var tot = 0
                            subset.forEach(element => {
                                //  console.log(element.am);
                               tot+= element.amtpaid;
                            });
                                const options = { 
                                    minimumFractionDigits: 2,
                                    maximumFractionDigits: 2 
                                };
                                tot = Number.parseFloat(tot).toFixed(2)
                                var subTot = [{value:element, data:Number.parseFloat(tot).toLocaleString('en',options)}]
                               vm.groupTot.push(subTot[0]);
                         });
                        
                         vm.Payoptions.groupMeta = vm.groupTot;
                         //console.log( vm.Payoptions);
                     })
                     .catch(function (er) {
                         console.log(er)
               });
        },
        closeModal() { 
            this.showEditModal = false;
            this.loadTable();
        },
        ClosePopUp(){
            this.showModal = false;        
        }, 

        loadTable(){        
        var vm = this;
        var url = '/SaskHealthApi/Codes/GetPaylistRuncodes?_='         
         var params = new URLSearchParams();
          params.append('ClinicNo', vm.ClinicNo);
         
         axios.get(url+Date.now(), { headers: { 'Authorization': 'Bearer ' + localStorage.access_token },params})
            .then(function (response) {  
                vm.runcodes=response.data; 
                })
                .catch(function (er) {
                    console.log(er)
                });
        }, 
        GetClinics(){
        var vm = this; 
        var params = new URLSearchParams();
         params.append('ServiceID', this.AppServiceID);
         axios.get('/SaskHealthApi/Codes/GetUserClinic', { headers: { 'Authorization': 'Bearer ' + localStorage.access_token }, params})
            .then(function (response) {
                //console.log(response.data);                    
                vm.Clinic = response.data;
                vm.ClinicNo = vm.Clinic[0].clinicno.toString();
                })
                 .catch(function (er) {
                      console.log(er)
                }).then(function () {                    
                    vm.loadTable();
                })   
        },       
    }
}
</script>

<style>

</style>