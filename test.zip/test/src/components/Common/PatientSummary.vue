<template>
<div id='PatientSummary'> 
  <Subtitle  v-bind:ServiceID="this.AppServiceID">
   <template v-slot:header>
  <i class="fas fa-book"></i><b>Patient Summary Request:</b>
  </template> 
</Subtitle> 
 <b-modal id="modal-sm"  size="md" title="Patient Summary" v-model="showModal" no-close-on-esc no-close-on-backdrop hide-header-close>
<div slot="default">
    <div class='alert alert-warning' role='alert'> {{msg}}   
    </div>
</div> 
<div slot="modal-footer" class="w-100">
    <p class="float-left" variant="primary"></p>
    <b-button variant="primary"  size="md"  class="float-right"  @click="PSExit"> Close </b-button>
</div>
</b-modal>

<!-- <h4><small class="text-muted"><i class="fas fa-user-shield"></i><b>Patient Summary Request:</b></small></h4>   -->
        <!-- <template slot="modal-header"> 
            <div>
            <small class="modal-title w-100 text-left">Messag</small>
          </div> 
          <div><small class="modal-title w-100 text-right"></small></div>
        </template> 
        <div slot="modal-footer" class="w-100"> 
        </div>  -->

 <form class="card  p-0 mb-1" id="SearchForm">
  <div class="card-header d-flex align-items-center  pl-1" style="height: 1rem; text-align:left;">
        <h5><small class="text-muted"><b><i class="fas fa-search-plus"></i>Search: HSN required (all others optional)</b></small></h5>
  </div>
  <div class="form-row p-1">
    <div class="form-group col-sm-2">
      <label for="inputEmail4" class="label-small">HSN:</label>
      <input id="HSN" @input="HSNtextChanged" v-model="HSN" maxlength="9" class="form-control form-control-xs" typeable>
       <div class="row" v-show="$v.HSN.$error">           
     <div class="col-sm-12">
          <small class="sml-red" v-if="!$v.HSN.required">HSN is required.</small>
          <small class="sml-red" v-if="!$v.HSN.numeric">HSN must be a number.</small>
          <small class="sml-red" v-if="!$v.HSN.maxLength">HSN must be 9 digits.</small>          
      </div> 
      </div>
    </div>
    <div class="form-group col-sm-2">
      <label for="inputPassword4" class="label-small">Effective Date:</label>
          <div>                                                                        
            <datepicker class="servdatapick"  typeable :open-date="new Date()" v-model="effectivedate" 
                :format="DateFormat" id="effDate" :bootstrap-styling="true" :input-class="datapickClass"
                 name="effectiveDatepicker"></datepicker>                        
          </div>
           <div class="row" v-show="$v.effectivedate.$error">            
            <div class="col-sm-12">
                <small class="sml-red" v-if="!$v.effectivedate.ValidValue">Effective Date must not be greater then Expiry date or blank.</small>
            </div> 
          </div>
    </div>
    <div class="form-group col-sm-2">
      <label for="inputPassword4" class="label-small">Expiry Date:</label>
      <div>
          <datepicker class="servdatapick"  typeable :open-date="new Date()" v-model="expirydate" 
              :format="DateFormat" id="expDate" :bootstrap-styling="true" :input-class="datapickClass" name="expiryDatepicker"></datepicker>
      </div>
        <div class="row" v-show="$v.expirydate.$error">            
        <div class="col-sm-12">
            <small class="sml-red" v-if="!$v.expirydate.ValidValue">Expiry date required.</small>
        </div> 
      </div>
    </div>
    <div class="form-group col-sm-5" v-show="isAssessor==true">
      <label for="inputEmail4" class="label-small">Clinic Name:</label>
     
        <vue-bootstrap-typeahead  :inputClass="TypeHeadinptClass"   autocomplete="off" @input="ClinictextChanged" id="clinicSel" ref="clinicRef" v-model="clinicno" :data="Clinic"
          @hit="selectedClinic = $event; searched=false" :serializer="item => item.clinicname"
          textVariant=".text-primary" placeholder="Search Clinics" size="sm" backgroundVariant="bg-light"
          :maxMatches="20" updateOn='blur' >
          <template slot="prepend">
            <span class="input-group-text m-0 p-1 form-control-xs" style="font-size: .6rem;"><i class="fas fa-search fa-sm"></i></span>
          </template>
        </vue-bootstrap-typeahead>
    </div>
    <div class="form-group col-sm-1">
      <label for="inputPassword4" class="label-small">  </label>
      <div class="mt-1">
          <button  v-on:click="GetHsnInfo"  type="button" class="btn btn-primary btn-sml">  Search  </button>
      </div>
    </div> 
  </div> 
</form> 
<div id="PatientSummaryRequest" class="mb-5">
 <div  class="row no-gutters">  
  <div class="col-4 pr-1" >
      <div class="card" v-if="Patient!=null" >
          <div class="card-header d-flex align-items-center  pl-1" style="height: 1rem; text-align:left;">
            <h5><small class="text-muted"><b><i class="fas fa-user-injured"></i>Patient: {{Patient.firstName}} {{Patient.lastName}} </b></small></h5>
          </div>
          <div  class="card-body p-2" >
                <!-- v-if="Patient!=null" -->
                  <div class="row" >
                    <span for="cname" class="col-sm-4"><b>HSN:</b></span> 
                    <span   class="col-sm-8" type="text">{{HSN}}</span> 
                  </div>
                  <div class="row">
                    <span for="cname" class="col-sm-4"><b>Address:</b></span> 
                    <span class="col-sm-8" type="text"> {{Patient.address1}}  {{Patient.address2}} </span> 
                    <!-- <span class="col-sm-8" type="text">12 Ave Albert ST</span>  -->
                  </div>
                  <div class="row mb-3">
                    <span for="cname" class="col-sm-4"><b>DOB:</b></span> 
                    <!-- <span class="col-sm-8" type="text">{{Patient.birthday}}</span>  -->
                    <span class="col-sm-8" type="text">{{Patient.birthDay |moment(Patient.birthDay) }} </span> 
                  </div> 
          </div>
      </div>
  </div>   
  <div class="col-4 pr-1" v-if="selectedClinic != null && Patient!=null">
      <div class="card">
      <div class="card-header   d-flex align-items-center  pl-1" style="height: 1rem; text-align:left;">
        <h5><small class="text-muted"><b><i class="fas fa-clinic-medical"></i>Clinic: {{selectedClinic.clinicname}}</b></small></h5>
      </div>

        <div  class="card-body p-2"> 
                  <div class="row">
                    <span for="cname" class="col-sm-4"><b>Clinic #:</b></span> 
                    <span class="col-sm-8" type="text">{{selectedClinic.clinicno}}</span> 
                  </div>
                  <div class="row">
                    <span for="cname" class="col-sm-4"><b>Address:</b></span> 
                    <span class="col-sm-8" type="text">{{selectedClinic.address}}</span> 
                  </div>
                  <div class="row mb-3">
                    <span for="cname" class="col-sm-4"><b>City:</b></span> 
                    <span class="col-sm-8" type="text">{{selectedClinic.city}}</span> 
                  </div> 
        </div>
      
      </div>
  </div>  
  
 </div>  

<div class="mt-2" v-if="searched">
      <!-- <v-client-table :columns="columns" :data="tableData" :options="options">         -->
        <v-client-table :columns="columns" :data="PatSumList" :options="options">
          <div slot="afterFilter"  class="ml-3 mt-4 "> 
              <button v-on:click="GeneratePDF" type="button"  v-if="searched" class="btn BtnClose">Print Summary</button>
          </div>
          <span class="pointer" v-on:click="getMessage(props.row.messagecode,'','Message')" slot="message" slot-scope="props" ><u>{{props.row.messagecode}}</u></span>        
      </v-client-table> 
</div>  	    

</div>  <!-- PatientSummaryRequest end --> 

</div>
</template>

<script>
import Vue from 'vue'; 
import {mapGetters} from 'vuex'
import moment from 'moment'
import axios from 'axios' 
import Datepicker from 'vuejs-datepicker';
import LayoutDefault from '../../Common/Default/DefaultLayout.vue'; 
import Subtitle from '@/Common/Default/SubTitle.vue';  
import Card from "../../Common/Card.vue";
import CardBody from "../../Common/CardBody.vue";
import TileNote from "../../Common/TileNote.vue";
import { PopUpVariant } from '@/Common/Default/PopUpVariant';
import { SKLogoString } from '@/Common/Default/SKLogo';
import { request } from 'http';
import { type } from 'os';
import Vuelidate from 'vuelidate'
import {helpers, required, minLength, sameAs, not, maxLength, numeric, integer, between} from 'vuelidate/lib/validators'
Vue.use(Vuelidate);
import jsPDF from 'jspdf'   // used for GeneratePDF
import autoTable from 'jspdf-autotable'    // used for GeneratePDF
export default  {
  name: 'HearingHome',
    props:{
      Mode:'',
      ServiceID:''
    },  
  data: function () {    
    return {
        ErrorDesc : [], 
        ErrorAndDesc:[],         
        TypeHeadinptClass:'form-control form-control-xs',
        msg:'',
         boxTwo: '',
         BtnSubmitdisabled:0,
        primaryText:'',
        PaidByThirdPArty:false,
        browseText:'Click Here',
        AppServiceID:0,
        MaxMatch:20,
        selectedProvider:null,
        AppName: 'Hearing Application',
        AppIcon: 'fas  fa-glasses',        
        subtitle: "Welcome", 
        HSN:'',
        effectivedate: '',
        expirydate: '',
        servicedate: '',
        ProviderNo:'',
        DateFormat:'',
        datapickClass:"form-control form-control-xs my-0",
        Showinfo : false,
        Provider:[],
        Clinic: [],
        clinicno: '00000',
        servicetype: '',
        Services: '',
        PatSumList: [],
        SourceCodeData: [],
        Patient:null,
        PopUpVar:PopUpVariant,
        SKLogoConst:SKLogoString, 
        showModal:false,
        ClaimInfo:null,
        ServiceCodeInfo:null,
        RequestForm:true,
        ClaimRequestNo:null,     
        isAssessor:false,
        selectedClinic:null,  
        searched:false,   
        //ClaimStatus:'Adjudication Completed',
        columns: ['servicecodestatusind','providername','clinicname','servicedate','servicecode','description','providersubmittedamount','dpebbpaidamount','thirdpartypaidamount','message'],
        options: {
        texts:{
              count:"Showing {from} to {to} of {count} records|{count} records|One record",
              first:'First',
              last:'Last',
              //filter:"Search Service Code:",
              //filterPlaceholder:"Search Service Code",
              limit:"Records:",
              page:"Page:",
              noResults:"",
              noResults:"No Patient Summary records Found",
              filterBy:"Filter by {column}",
              loading:'Loading...',
              defaultOption:'Select {column}',
              columns:'Columns'
          },
          responseAdapter({data}) {
            // const formatData = data.map(o => {
            //     const dataCopy = JSON.parse(JSON.stringify(o))
            //     dataCopy.expirydate = moment(o.expirydate).format('MMMM Do YYYY')
            //     return dataCopy
            //   })
              return {
                data: formatData,
                count: data.length
              };
              // return {
              //   data,
              //   count: data.length
              // }
            },
          perPage:10,
          perPageValues:[10,15,25],
          dateColumns:['servicedate'],
          //toMomentFormat: 'YYYY/MM/DD',
          //templates: {edit: 'edit'},
          templates: {
            servicedate(h, row) {
             // moment.locale('es');               
              return moment(row.servicedate,"YYYY-MM-DD").format('YYYY/MM/DD');  
            },
            // expirydate(h, row) {
            //  // moment.locale('es');               
            //   return moment(row.expirydate,"YYYY-MM-DD").format('YYYY/MM/DD');  
            // },
            description(h, row) { 
              return   <div style="font-size: 70%">{row.description}</div> 
            },  
            providersubmittedamount(h, row) {   
              return <div>${Number.parseFloat(row.providersubmittedamount).toFixed(2)}</div> ; 
            }, 
            dpebbpaidamount(h, row) {   
              return <div>${Number.parseFloat(row.dpebbpaidamount).toFixed(2)}</div> ; 
            },
            thirdpartypaidamount(h, row) {   
              return <div>${Number.parseFloat(row.thirdpartypaidamount).toFixed(2)}</div> ;
            } 
          },
          headings: {
            servicecodestatusind: "Status",
            providername: 'Provider Name',            
            servicedate: 'Service Date',
            servicecode: 'Service Code',
            description:  'Description',
            providersubmittedamount: ((this.ServiceID == 3) ? 'Service' : 'Submitted') + ' Amount',
            dpebbpaidamount:    'DPEBB Paid',
            thirdpartypaidamount: '1st Payer Paid Amount',
            messagecode: 'Messages Code',
            clinicname: 'Clinic Name'
          },
          pagination: {
            edge: true,
            nav: 'scroll',
            chunk: 5
          },
           sortable: ['servicecodestatusind','providername','servicedate','servicecode','description','providersubmittedamount','dpebbpaidamount','message'],
          // filterable: ['username', 'fullname', 'clinicname', 'role' ,'status'],
          sortIcon: {
                  base : 'fas',
                  is: 'fa-sort',
                  up: 'fa-sort-up',
                  down: 'fa-sort-down'
                  },
          },

        }
    },
    watch:{
      '$route' (to,from)
      {
         if(to.params.ClaimID == isNullOrUndefined)
          {
             this.RequestForm = false;
          }
          else
          {
            this.RequestForm = true;
          }
      },
      // RequestForm: function(){

      // }
    },
    components: { 
            Card,
            CardBody,
            TileNote ,
            Datepicker,
	    Subtitle
            //PatientSummary
            //VueUploadMultipleImage
        },
    validations(){
      return { 
        HSN :{
              required,
              numeric,
              minLength:minLength(9)
        },
       effectivedate:{
            ValidValue : value => this.ValEffDate(),//(moment(this.effectivedate).toISOString() < moment(this.expirydate).toISOString()),

       },  
       expirydate:{
         ValidValue : value => this.ValExpDate(),
       },           
      }
    },        
     filters: {
          moment: function (date) {
          return moment(date,"YYYY-MM-DD").format('YYYY/MM/DD');
          },
          stringify(value) {
          return JSON.stringify(value, null, 2)
          }  
        }, 
    methods: {
      GeneratePDF: function (event) {
        var vm = this;        

        //console.log('GeneratePDF')
        // generated from https://ezgif.com/image-to-datauri
        const skLogo = vm.SKLogoConst.Logo64Bit;
        
        const pdf = new jsPDF('l', 'mm', 'letter');
        const pageHeight = pdf.internal.pageSize.height;
        const pageWidth = pdf.internal.pageSize.width;
        const fontType = 'helvetica';

        function appendLeadingZeroes(n)
        {
          if(n <= 9)
          {
            return "0" + n;
          }
          return n
        }

        // Add Header and Footer to every page in report
        const addHeaderFooter = pdf => 
        {
          // get total number of pates
          const pageCount = pdf.internal.getNumberOfPages()

          // cycle through every page to add header/footer
          for (var i = 1; i <= pageCount; i++) 
          {
            pdf.setPage(i)

            var currDate = new Date();
            var rptDate = currDate.getFullYear() + "-" 
                             + appendLeadingZeroes(currDate.getMonth() + 1) + "-" 
                             + appendLeadingZeroes(currDate.getDate()) + " " 
                             + appendLeadingZeroes(currDate.getHours()) + ":" 
                             + appendLeadingZeroes(currDate.getMinutes()) + ":" 
                             + appendLeadingZeroes(currDate.getSeconds());
                  
            pdf.setFont(fontType);

            // Header Image                    
            pdf.addImage(skLogo,'png', 5, 5);//, 45, 18); //15,10,30,10); //5,5,30,10);
          
            // Header Title
            var rptTitle = vm.AppName;   

            if (vm.AppServiceID == 3) rptTitle = 'Optical';
            else if (vm.AppServiceID == 4) rptTitle = 'Hearing';
            else if (vm.AppServiceID == 5) rptTitle = 'Podiatry';
            rptTitle = rptTitle + ' - Patient Summary Request';
          
            pdf.setFontSize(14);
            pdf.text(rptTitle, (pageWidth / 2), 10, 'center', 'center');    


            // Footer
            pdf.setFontSize(9);
            pdf.line(5, pageHeight - 10, pageWidth - 5, pageHeight - 10);
            pdf.text("Run Date: " + rptDate, 5, pageHeight - 5);

            pdf.setFontSize(8);    
            var copyRight = 'Copyright or Small Confidential Info????';            
            pdf.text(copyRight, pageWidth / 2 - copyRight.length / 2, pageHeight - 5);

            pdf.setFontSize(9);
            pdf.text("Page: " + String(i) + ' of ' + String(pageCount), pageWidth - 5, pageHeight - 5, {align: 'right'});
          }
        }

        // ------------------------
        // Patient Information
        // ------------------------
        var patsupprovList = [ { label1: '', value1: ''
                               , label2: '', value2: ''
                               , label3: '', value3: ''
                               }
                             , { label1: 'Patient:'     
                               , value1: this.Patient.firstName + ' ' + this.Patient.lastName
                               , label2: (this.selectedClinic != null) ? 'Clinic:': ''
                               , value2: (this.selectedClinic != null) ? this.selectedClinic.clinicname : ''
//                               , label3: 'Provider:'    
//                               , value3: this.selectedProvider.providername 
                               }
                             , { label1: 'HSN:'         
                               , value1: this.Patient.hsn
                               , label2: (this.selectedClinic != null) ? 'Clinic #:' : ''
                               , value2: (this.selectedClinic != null) ? this.selectedClinic.clinicno : ''
//                               , label3: 'Provider #:'  
//                               , value3: this.selectedProvider.orgid.concat(this.selectedProvider.providerno) 
                               }
                             , { label1: 'Address:'     
                               , value1: this.Patient.address1 + ' ' + this.Patient.address2
                               , label2: (this.selectedClinic != null) ? 'Address:' : ''     
                               , value2: (this.selectedClinic != null) ? this.selectedClinic.address : ''
//                               , label3: 'Service:'     
//                               , value3: this.selectedProvider.service 
                               }
                             , { label1: 'DOB:'         
                               , value1: moment(this.Patient.birthDay).format('YYYY/MM/DD')
                               , label2: (this.selectedClinic != null) ? 'City:' : ''      
                               , value2: (this.selectedClinic != null) ? this.selectedClinic.city : ''
//                               , label3: 'Service Type:'
//                               , value3: this.selectedProvider.subtype 
                               }
                             ];

        var patsupprovHead = [//[],
                              [ {"content":"Patient Information","colSpan":2,"styles":{"cellWidth":"even"}}
                              , {"content":(this.selectedClinic != null) ? "Clinic Information" : '',"colSpan":4,"styles":{"cellWidth":"even"}}
//                              , {"content":"Provider Information","colSpan":2,"styles":{"cellWidth":"even"}}
                              ]];

        // ------------------------
        // Patient Information
        // ------------------------
        pdf.autoTable
        (
          {
            theme: 'plain', 
            //startY: 15, //pdf.lastAutoTable.finalY + 3,   
            headStyles: 
            {
              font: fontType,
              fontSize: 12,
              fontStyle: 'bold',
            }, 
            styles: 
            {
              font: fontType,
              fontSize: 9,
              cellPadding: 0, 
              padding: 0, 
//                  cellspacing: 0, 
              border: 0
            }, 
            columnStyles: 
            {
              0: {cellWidth: 15}, 
              2: {cellWidth: 16},
              4: {cellWidth: 22}
            }, 
            body: patsupprovList, 
            head: patsupprovHead,
            columns: 
            [ {dataKey: 'label1'}
            , {dataKey: 'value1'}
            , {dataKey: 'label2'}
            , {dataKey: 'value2'}
            , {dataKey: 'label3'}
            , {dataKey: 'value3'}
            ],                                                     
            margin: 
            {
              top: 20,
              left: 5,
              right: 5,
              bottom: 20
            },  
            didParseCell: function (data) 
            {
              if (data.section === 'head')
              {
                if (data.row.index == 0) data.cell.styles.fillColor = [236,236,236];     // light grey  
                data.cell.styles.fontStyle = 'bold';                  
                data.cell.styles.cellPadding = 0;
              };

              // Bold for Legend column
              if (data.column.index === 0 || data.column.index === 2 || data.column.index === 4 ) 
              {
                data.cell.styles.fontStyle = 'bold';
              }
            },
//            didDrawPage: pageHeaderFooter 
          }
        );

        // ------------------------
        // Service Code Information
        // ------------------------
        {
          // set legend headers to show if true for ViewNotesCoverage or for Claim Status
          var headerInit =  [ {code: 'scstatus', header: 'Status', show: true, assessor: false, legend: false, legendHeader:'', align:'left'}
                            , {code: 'scprovidername', header: 'Provider Name', show: false, assessor: false, legend: false, legendHeader:'', align:'left'}
                            , {code: 'scclinicname', header: 'Clinic Name', show: false, assessor: false, legend: false, legendHeader:'', align:'left'}
                            , {code: 'scservicedate', header: 'Service Date', show: true, assessor: false, legend: false, legendHeader:'', align:'left'}                            
                            , {code: 'scservicecode', header: 'Service Code', show: true, assessor: false, legend: false, legendHeader:'', align:'left'}                            
                            , {code: 'scdescription', header: 'Description', show: true, assessor: false, legend: false, legendHeader:'', align:'left'}
                            , {code: 'providersubmittedamount', header: 'SA ($)', show: true, assessor: false, legend: true, legendHeader:'(SA) ' + ((vm.AppServiceID == 3) ? 'Service' : 'Submitted') + ' Amount', align:'right'}
                            , {code: 'dpebbpaidamount', header: 'DPA ($)', show: true, assessor: false, legend: true, legendHeader:'(DPA) DPEBB Paid Amount', align:'right'}
                            , {code: 'thirdpartypaidamount', header: '1PPA ($)', show: true, assessor: false, legend: true, legendHeader:'(1PPA) 1st Payer Paid Amount', align:'right'}
                            , {code: 'scerrorcode', header: 'Message', show: true, assessor: false, legend: false, legendHeader:'', align:'left'}                             
                            ];

          // Show Provider Name if AppServiceID not 4 - Hearing 
          if (this.AppServiceID != 4)
          {
            headerInit.find(tbl => tbl.code == 'scprovidername').show = true;
          }

          // If Not Assessor then show Clinic Name
          if (this.isAssessor) 
          {
            headerInit.find(tbl => tbl.code == 'scclinicname').show = true;
          }
                        
          // Filter only Headers to show
          var headerList = headerInit.filter(hdr => hdr.show);
          var serviceColumnList = [];
          var serviceColumnHeaderList = [];
          for (var hdrIdx = 0; hdrIdx < headerList.length; hdrIdx++)   
          {    
            var serviceColumnObj = {};
            var serviceColumnHeaderObj = {};
            serviceColumnObj["title"] = headerList[hdrIdx].header;
            serviceColumnObj["dataKey"] = headerList[hdrIdx].code; 
            serviceColumnHeaderObj["id"] = headerList[hdrIdx].code;  
            serviceColumnHeaderObj["content"] = headerList[hdrIdx].header;  
            serviceColumnHeaderObj["styles"] = {"halign":headerList[hdrIdx].align};
            serviceColumnList.push(serviceColumnObj);
            serviceColumnHeaderList.push(serviceColumnHeaderObj);
          }

          // create data row for Service Codes to show
          var serviceBodyList = [];
          var serviceDataList = [];
          for (var srcIdx = 0; srcIdx < vm.PatSumList.length; srcIdx++)                                                     
          {
            var dataRowList = [];
            var labelVal = '';
            var valueVal = '';
            var showVal = '';            
            var show = false;

            for (var hdrIdx = 0; hdrIdx < headerList.length; hdrIdx++)   
            {
              labelVal  = headerList[hdrIdx].code;
              showVal = headerList[hdrIdx].show;
              valueVal = '';     

//              var validID = headerList[hdrIdx].validID;
//              var assessorVal = headerList[hdrIdx].assessor;

//              if ((assessorVal && this.ViewNotesCoverage) || !assessorVal)
              {
                switch(labelVal)
                {
                  // Status
                  case 'scstatus':
                    valueVal = vm.PatSumList[srcIdx].servicecodestatusind;
                    break;

                  // Provider Name
                  case 'scprovidername':
                    valueVal = vm.PatSumList[srcIdx].providername;
                    break;

                  // Clinic Name
                  case 'scclinicname':
                    valueVal = vm.PatSumList[srcIdx].clinicname;
                    break;

                  // Service Date
                  case 'scservicedate':
                    var svcDateVal = vm.PatSumList[srcIdx].servicedate
                    valueVal =  ( svcDateVal != null && svcDateVal != '' ) ? moment(svcDateVal).format('YYYY/MM/DD') : ''
                    break;

                  // Service Code
                  case 'scservicecode':
                    valueVal = vm.PatSumList[srcIdx].servicecode;
                    break;

                  // Description
                  case 'scdescription':
                    valueVal = vm.PatSumList[srcIdx].description;
                    break;

                  // Service Amount/Submitted Amount
                  case 'providersubmittedamount':
                    valueVal = Number(vm.PatSumList[srcIdx].providersubmittedamount).toFixed(2).replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
                    break;

                  // DPEBB Paid Amount
                  case 'dpebbpaidamount':
                    valueVal = Number(vm.PatSumList[srcIdx].dpebbpaidamount).toFixed(2).replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
                    break;

                  // 1st Payer Paid Amount
                  case 'thirdpartypaidamount':
                    valueVal = Number(vm.PatSumList[srcIdx].thirdpartypaidamount).toFixed(2).replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
                    break;

                  // Message Code
                  case 'scerrorcode':
                    valueVal = vm.PatSumList[srcIdx].messagecode;
                    break;

                  default:
                }
                dataRowList.push({ label: labelVal, value: valueVal, show: showVal });               
              }
            }
            
            var serviceBodyObj = {};
            var serviceDataObj = {};

            // filter only Columns to show
            var svcList = dataRowList.filter(svcCol => svcCol.show);             
            // create data elements for Service Codes information
            for (var j = 0; j < svcList.length; j++)   
            {
              serviceBodyObj[svcList[j].label] = svcList[j].value;
            }  

            serviceBodyList.push(serviceBodyObj);    
          }
        
          var serviceHeadList = [//[],
                                [ {id: "rowHdr1", "content":"Service Code Information","colSpan":serviceColumnHeaderList.length} ],
                                [ {id: "rowHdr2", "content":"","colSpan":serviceColumnHeaderList.length,"styles":{"cellPadding":0, "border":0, "height":0.25}} ],
                                serviceColumnHeaderList
                                ];  

          var noServiceCodesFoundList = [];
          if (vm.PatSumList.length == 0)
          {
             serviceHeadList.push([{id: "rowHdr3", "content":"<< No Service Code Found >>","colSpan":serviceColumnHeaderList.length, "styles":{"cellPadding":0, "halign":"center", "fontStyle":"normal"}}]);
          }

          //************************
          // Service Code Lines Table       
          //************************
          pdf.autoTable
          (
            {
              theme: 'plain', 
              startY: pdf.lastAutoTable.finalY + 7,   
              headStyles: 
              {
                font: fontType,
                fontSize: 12,
                fontStyle: 'bold',
                cellPadding: 0.5,
              }, 
              styles: 
              {
                font: fontType,
                fontSize: 9,
                cellPadding: 0.5, 
//                lineWidth: .5,
              }, 
              body: serviceBodyList, 
              head: serviceHeadList,
              columns: serviceColumnList,                                                     
              margin: 
              {
                top: 20,
                left: 5,
                right: 5,
                bottom: 20
              },  
              didParseCell: function (data) 
              {
                data.cell.styles.cellWidth = 'auto';
                if (data.section === 'head')
                {
                  if (data.row.index == 0) 
                  {
                    data.cell.styles.fillColor = [236,236,236];     // light grey                                      
                    data.cell.styles.cellPadding = 0;
                  }
                  else 
                  {
                    data.cell.styles.fontSize = 9;
//                    data.cell.styles.cellPadding = 0.5;
                  }
                }
                else
                {
                  data.cell.styles.halign = serviceColumnHeaderList[data.column.index].styles.halign;
//                  data.cell.styles.cellPadding = 0.5;
                }
              },
//              didDrawPage: pageHeaderFooter 
            }
          );

          //--************************
          // Legend Information
          //--************************
          {
            // initialize data matrix
            var legendList =[ 
                              { datakey1: 'Legend'
                              , datakey2: '          '
                              , datakey3: '          '
                              , datakey4: '          '
                              , datakey5: '          '
                              , datakey6: '          '
                              , datakey7: '          '
                              }
                            ];
            // filter only legend records to show
            var legendInit = headerInit.filter(hdrList => hdrList.legend);
                        
            // only show values with show = true and sort by code
            var showLegendList = _.sortBy( legendInit.filter(legend => legend.show), 'legendHeader' );

            // create second row if more than 6 values in list
            if (showLegendList.length > 6) 
            {
              var legendListb = { datakey1: '          '
                                , datakey2: '          '
                                , datakey3: '          '
                                , datakey4: '          '
                                , datakey5: '          '
                                , datakey6: '          '
                                , datakey7: '          '
                                };
              legendList.push(legendListb);
            }

            // update values in data matrix
            var cntLoop = 0;
            var cntRow = 0;
            for (var i = 0; i < showLegendList.length; i++) 
            {  
              cntRow++;
              var arrval = showLegendList[i].legendHeader;
              legendList[cntLoop]["datakey" + (cntRow+1)] = arrval;

              // add new line if need to since stores datakey 1-7                
              if (cntRow == 6) 
              {
                cntLoop++;
                cntRow = 0;
              }
            }

            //--************************
            // Legend table        
            //--************************
            pdf.autoTable
            (
              {
                theme: 'plain', 
                startY: pdf.lastAutoTable.finalY + 3,   
                headStyles: 
                {
                  font: fontType,
                  fontSize: 8,
                  fontType: 'bold',
                  cellPadding: 0                  
                }, 
                styles: 
                {
                  font: fontType,
                  fontSize: 8,
                  cellPadding: 0
                }, 
                body: legendList,
                head: [[]],
                columns: 
                [
                  { dataKey: 'datakey1' },
                  { dataKey: 'datakey2' },
                  { dataKey: 'datakey3' },
                  { dataKey: 'datakey4' },
                  { dataKey: 'datakey5' },
                  { dataKey: 'datakey6' },
                  { dataKey: 'datakey7' },              
                ], 
                columnStyles: 
                {
                  0: { cellWidth: 14}
                },   
                margin: 
                {
                  top: 20,
                  left: 5,
                  right: 5,
                  bottom: 20
                }, 
                didParseCell: function (data) 
                {
                  // Bold for Legend column
                  if (data.column.index === 0) data.cell.styles.fontStyle = 'bold';
                } 
              }
            );                    
          } // End Legend

          //--************************
          // Message Codes
          //--************************
          if (vm.ErrorAndDesc != null && vm.ErrorAndDesc != '' && vm.ErrorAndDesc.length != 0 && vm.PatSumList.length != 0)
          {
            pdf.autoTable
            (
              {
                theme: 'plain', 
                startY: pdf.lastAutoTable.finalY + 3,   
                headStyles: 
                {
                  font: fontType,
                  fontSize: 8,
                  fontType: 'bold',
                }, 
                styles: 
                {
                  font: fontType,
                  fontSize: 8,
                  cellPadding: 0, 
                }, 
                body: vm.ErrorAndDesc,
                head: [[],['Message', 'Description']],
                columns: 
                [
                  { dataKey: 'item1' },  //errorCode
                  { dataKey: 'item2' },  //errMsg
                ],
                columnStyles: 
                {
                  0: { cellWidth: 14}
                },   
                margin: 
                {
                  top: 20,
                  left: 5,
                  right: 5,
                  bottom: 20
                },  
              }
            );
          } // End Message Codes
          
        } // End Service Codes

        // draw the header/footers on each page
        addHeaderFooter(pdf);
        
        // save the pdf file
        pdf.save('patientSummary.pdf');

      },
      
       ValEffDate(){ 
        if((this.effectivedate != '' && this.effectivedate != null) && (this.expirydate != '' && this.expirydate != null))
        {
          console.log('affect' + this.effectivedate)
          if(moment(this.effectivedate).toISOString() < moment(this.expirydate).toISOString())
          {
              return true;
          }  
          else
          return false;
        }
        else if((this.effectivedate == '' && this.effectivedate == null) && (this.expirydate != '' && this.expirydate != null))
        {
           return true;
        }
       else if((this.effectivedate == '' || this.effectivedate == null) && (this.expirydate == '' || this.expirydate == null))
        {
           console.log('all zero' + this.effectivedate)
           return true;
        }
        else
        {
          return false;
        }        
      },
      ValExpDate(){
        
        if((this.effectivedate != '' && this.effectivedate != null))
          
        {
           if (this.expirydate == '' || this.expirydate != null)
            return true;
            else
            return false;
        }
        else
        {
           return true;
        }        
      },
      ClinictextChanged(){
        console.log(this.clinicno)
        if(this.clinicno == ''){
          this.selectedClinic = null;
          this.searched = false;
        }
      },
      PSExit(){
        this.showModal = false;
      },
      HSNtextChanged(){
         if(this.HSN == null || this.HSN.length < 9){
           this.Patient = null;
           this.searched = false;
         }
       },
 
         Show(){
             this.Showinfo =true;
        }, 
         GetHsnInfo(){
         
           var vm = this;
           vm.$v.$touch();
           if (!vm.$v.$invalid){ 
            var params = new URLSearchParams();
             params.append('HSN', this.HSN);
             axios.get('SaskHealthApi/Host/GetHsnInq', { headers: { 'Authorization': 'Bearer ' + localStorage.access_token },params})
             .then(function (response) {
                    console.log(response.data);
                    vm.Patient =response.data;                    
                    //vm.Showinfo= true;
                    vm.loadTable(); 
                    vm.searched = true;
                })
            .catch(function (er) {
                console.log(er)
                vm.PatSumList = [];
              if(er.status ==400)
                {
                  console.log('here')
                  vm.showModal = true;
                  vm.msg = er.data.message; 
                }
                else if(er.status == 500)
                {
                    vm.showModal = true;                
                    if(er.data.message !=null)
                      vm.msg = er.data.message;
                    else
                    vm.msg = "Network Related Error !" 
                }              
            })
           }  
        },
        GetServiceType(){
          
           var vm = this;
           var params = new URLSearchParams();            
           params.append('ServiceID', this.AppServiceID);
            axios.get('SaskHealthApi/Codes/GetServiceType?_='+Date.now(), { headers: { 'Authorization': 'Bearer ' + localStorage.access_token }, params})
            .then(function (response) {
                //console.log(response.data);
                vm.Services=response.data;
                })
            .catch(function (er) {

                console.log(er)
                
                })
        },
        loadTable(){
         
           var vm = this;
           var frm = ''
           var to = ''
            vm.PatSumList = [];
            //console.log(this.selectedClinic.clinicno);
           this.servicetype=this.Services; 
          //this.clinicno= this.selectedClinic==null?'00000':this.selectedClinic.clinicno;
            if (vm.effectivedate == '' || vm.effectivedate == null)
              frm = "00000000";
            else
              frm = moment(vm.effectivedate, "YYYY-MM-DD").format('YYYYMMDD');
            if (vm.expirydate == '' || vm.expirydate == null)
              to = "00000000";
            else
              to = moment(vm.expirydate, "YYYY-MM-DD").format('YYYYMMDD');
            var params = new URLSearchParams();
            params.append('HSN', this.HSN);
            params.append('effectivedate',  frm);
            params.append('expirydate',to);            
            // params.append('effectivedate', EffDate);
            // params.append('expirydate', ExpDate);
            params.append('servicetype', this.servicetype);
            params.append('clinicno',  this.selectedClinic==null?'00000':this.selectedClinic.clinicno)
           //console.log("getpatientsuMinq  2");           
             axios.get('SaskHealthApi/Host/GetPatientSumInq', { headers: { 'Authorization': 'Bearer ' + localStorage.access_token },params})
             .then(function (response) {
                     console.log("GetPatientSumInq: " + response.data);                      
                    vm.PatSumList =response.data;
                })
            .catch(function (er) {
                vm.PatSumList = [];
            if(er.status ==400)
            {
                vm.showModal = true;
              console.log('here') 
              vm.msg = er.data.message; 
            }
            else if(er.status == 500)
            {  
                vm.showModal = true;
                if(er.data.message !=null)
                  vm.msg = er.data.message;
                else
                vm.msg = "Network Related Error !" 
             }}).then(function (f){
                console.log('length : ' + vm.PatSumList.length);
                if(vm.PatSumList.length >0)
                {
                  vm.ErrorAndDesc = _.map(_.uniqBy(vm.PatSumList, 'messagecode'), function (item) {
                      return {
                          item1: item.messagecode,
                          item2: item.errordesc
                      };  
                  });
                  console.log('Error dec = ' + vm.ErrorAndDesc);
                  _.forEach(vm.ErrorAndDesc, function(value) {
                    console.log(value);
                  });
                }
            })
        },
          showMsg(msg,data,Title) {
          this.boxTwo = ''
          this.$bvModal.msgBoxOk(msg, {
          title: Title,
          size: 'md',
          buttonSize: 'md',
          okVariant: 'danger',          
          okTitle: 'Close', 
          footerClass: 'p-2',
          hideHeaderClose: true,
          hideHeaderCancel: true,
          centered: true, 
        })
          .then(value => {
            

            this.boxTwo = this.msg;
            if(value)
            {
             
            }
          })
          .catch(err => {
            // An error occurred
          })
      },
        getMessage(MessageCode){
          var vm = this;

          var params = new URLSearchParams();
            
            params.append('program', 'HCHXA020');
            params.append('code',  MessageCode);
                axios.get('SaskHealthApi/Codes/GetMessage?_='+Date.now(), { headers: { 'Authorization': 'Bearer ' + localStorage.access_token },params})
                .then(function (response) {
                    // vm.PACodes=response.data;
                    // console.log(response);
                    // vm.PAReq = vm.PACodes.find(x=>x.id === vm.codePriorApproval);
                    vm.showMsg(response.data,'',"Message");
                    // vm.showModal = true;
                    
                }).catch(function (er) {
                console.log(er)
                });
        }, 
  GetUserClinics(){
           var vm = this; 
           var params = new URLSearchParams();
          params.append('ServiceID', this.AppServiceID);
            axios.get('/SaskHealthApi/Codes/GetUserClinic', { headers: { 'Authorization': 'Bearer ' + localStorage.access_token }, params})
                .then(function (response) {
                    vm.Clinic = response.data;
                    if(!vm.isAssessor){
                      vm.selectedClinic= vm.Clinic[0];
                      vm.clinicno = vm.Clinic[0].clinicno.toString();
                    }

                    // console.log(vm.selectedClinic);
                })
            .catch(function (er) {
                console.log(er)
            })   
        },
 
        showMsgBox(msg,data) {
        this.boxTwo = ''
        this.$bvModal.msgBoxConfirm(msg, {
          title: 'Please Confirm',
          size: 'md',
          buttonSize: 'md',
          okVariant: 'danger',
          cancelVariant: 'default',
          okTitle: 'YES',
          cancelTitle: 'NO',
          footerClass: 'p-2',
          hideHeaderClose: true,
          centered: true, 
        })
          .then(value => {
            this.boxTwo = value
            if(value)
            {
              //console.log(data);
                 this.DeleteServiceCode(data);
            }
          })
          .catch(err => {
            // An error occurred
          })
      },
    },
    computed:{
 
    },
     created: function() { 
        this.AppServiceID = this.ServiceID;
        this.DateFormat = this.$store.getters.GetDateFormat;
        this.GetServiceType()      
        var params = new URLSearchParams();
        var vm = this;
        axios.get('SaskHealthApi/Codes/IsAssessororSuper?_='+Date.now(), { headers: { 'Authorization': 'Bearer ' + localStorage.access_token },params})
        .then(function (response) {
          console.log(response.data);
          vm.isAssessor = response.data;
        }).catch(function (er) {
          console.log(er)
        });

        
    },
     beforeCreate: function() {  
        //console.log(this.AppServiceID)
        // this.$store.dispatch('AddServiceID',this.$store.getters.GetHearingID);
       // this.$store.dispatch('GetMenuItems',this.$store.getters.GetHearingID); 
    },
     mounted: function () {
        this.$nextTick(function () {
          this.GetUserClinics();
        //this.GetProvider(); 
       //console.log('at mount')
 
      })
    },
    
}
 

</script>

<style scopped>
 .row.no-gutter [class*='col-']   {
   padding-right:1px;
   
 }
 .list-group-item {
    position: relative;
    display: block;
    padding: 0px 15px;
    margin-bottom: -1px;
    border: 1px solid #ddd;
    background-color: blue;
    line-height: 1em
}
/* remove right padding from first column */
/* .row.no-gutter [class*='col-']:first-child {
  padding-right:5px;
} */
/* remove left padding from first column */
/* .row.no-gutter [class*='col-']:last-child {
  padding-left:5px;
} */


/* only for column content visible */
.col-lg-1>div {background-color:#ddd;}

#docimg {
   
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50; 
  /* margin-top: 10px; */
}
#line {
  border-top:1px solid   rgba(7, 14, 109, 0.25);
  /* border-bottom:1px solid #c00;
  border-bottom: 1px solid rgba(255,255,255,.25); */
}
 
</style>