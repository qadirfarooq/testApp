<template>
 <div> 
   <b-modal id="modal-sm" size="md" title="Service Code" v-model="showModal" no-close-on-esc no-close-on-backdrop hide-header-close>
  <div slot="default">
    <div class='alert alert-warning' role='alert' v-if=!succeeded> {{Msg}} <br> Please Contact System Administrator. </div>
    <div class="alert alert-success" role="alert" v-if=succeeded> {{Msg}} </div>
   </div> 
  <div slot="modal-footer" class="w-100">
        <p class="float-left" variant="primary"></p>
         <b-button variant="primary"  size="md"  class="float-right"  @click="PopMsgClose"> Close </b-button>
      </div>
</b-modal>
   <form> 
  <div class="form-group row">
      <div class="col-sm-12 form-control-xs">
       <vue-bootstrap-typeahead ref="searchbox"   :data="ServiceCodes"  @hit="SelectedCode = $event"
                        :serializer="item => item.servicedesc"  textVariant=".text-info"   placeholder="Search Service Code"  size="sm"  backgroundVariant="bg-light" :maxMatches="20" >
                        <template slot="prepend">
                          <span class="input-group-text" style="font-size: .7rem;"><i class="fas fa-search fa-sm"></i></span>
                        </template>                      
    </vue-bootstrap-typeahead> 
      </div> 
  </div> 
  <div class="form-group row  my-1">
    <label for="CodeID" class="col-sm-4 label-small my-0">Service Code:</label>
    <div class="col-sm-4 my-0">
      <input id="CodeID" v-model="SelectedCode.servicecode" readonly placeholder="Service Code ID" class="form-control form-control-xs my-0 mb-0">
    </div>
    <div :class="{ 'col-sm-4 my-0': $v.SelectedCode.$error}"   v-show="$v.SelectedCode.$error">
        <div class="row">
         <small class="sml-red" v-if="!$v.SelectedCode.required">Service code is required. 
           </small>
        </div> 
    </div> 
  </div> 
  <!-- <div class="form-group row  my-1">
    <label for="Fee" class="col-sm-4  label-small my-0">Service Fee:</label>
    <div class="col-sm-4 my-0">
       <input id="Fee" v-model="ServiceFee" placeholder="Service Fee" class=" my-0 form-control form-control-xs">
    </div>
    <div :class="{ 'col-sm-4 my-0': $v.ServiceFee.$error}"   v-show="$v.ServiceFee.$error">
        <div class="row">
         <small class="sml-red" v-if="!$v.ServiceFee.required">Service fee is required.</small>
         <small class="sml-red" v-if="!$v.ServiceFee.fee">must be a valid fee.</small>
        </div> 
    </div>
  </div>  -->
  
<div class="form-group row  my-0 mb-0 mt-1" v-if="ClaimTypeID==1">
    <label for="inputEmail3" class="col-sm-4 label-small mb-0">Prior Approval #:</label>
    <div class="col-sm-4 ">
        <input id="pa" type="text" v-model="PriorApprovalNo"  placeholder="Prior Approval #" class=" my-0 form-control form-control-xs">
    </div>
       <div class="col-sm-4 mb-0"  v-show="$v.PriorApprovalNo.$error"> 
         <div class="row mb-0">
          <!-- <small class="sml-red" v-if="!$v.PriorApprovalNo.numeric">must be a number.</small> -->
          <small class="sml-red" v-if="!$v.PriorApprovalNo.Panumber">must be a valid number.</small>
         </div > 
       </div>
</div> 
<div class="form-group row my-1">
    <label for="Qty" class="col-sm-4 label-small">Qty:</label>
    <div class="col-sm-4">      
      <input id="Qty" type="number" min="1" max="50" v-model.number="Qty"  maxlength="2" placeholder="Qty" class=" my-0 form-control form-control-xs">
    </div>
    <div  :class="{ 'col-sm-4 mb-0': $v.Qty.$error}"   v-show="$v.Qty.$error"> 
      <div class="row">
        <small class="sml-red" v-if="!$v.Qty.required">Qty is required.</small> 
        <small class="sml-red" v-if="!$v.Qty.val">must be a valid qty.</small> 
        <small class="sml-red" v-if="!$v.Qty.numeric">must be a number.</small>
      </div>      
    </div>
</div>
<div class="form-group row my-1" v-if="SelectedClaimStatusID==4 && ClaimTypeID==2">
    <label for="Tooth1" class="col-sm-4 label-small">Expiry Date:</label>
    <div class="col-sm-4"> 
      <div><datepicker typeable :open-date="new Date()"  v-model="ExpiryDate" :format="dateFormat" id="exp" :bootstrap-styling="true" :input-class="datapickClass" name="expirydatepicker"></datepicker> </div>     
   </div>
    <!-- <div  :class="{ 'col-sm-4 mb-0': $v.Qty.$error}"   v-show="$v.Qty.$error">
      <div class="row">
        <small class="sml-red" v-if="!$v.Qty.required">Confirm Password is required.</small>
        </div>
    
    </div> -->
  </div>

  <div class="form-group row my-1">
    <label for="Tooth1" class="col-sm-4 label-small">Unit Cost:</label>
    <div class="col-sm-4">      
      <input id="Tooth1" type="text" v-model.number="ACQCost"  placeholder="Unit Cost" class=" my-0 form-control form-control-xs">
    </div>
    <div  :class="{ 'col-sm-4 mb-0': $v.ACQCost.$error}"   v-show="$v.ACQCost.$error">
      <div class="row">
        <small class="sml-red" v-if="!$v.ACQCost.fee">Must be a valid cost.</small>
        <small class="sml-red" v-if="!$v.ACQCost.required">Cost is required.</small>
      </div> 
    </div>
  </div>

  <div class="form-group row my-1" v-if="this.AppServiceID==2">
    <label for="Markupper" class="col-sm-4 label-small">Markup Percentage: {{AppServiceID}}</label>
    <div class="col-sm-4">      
      <input id="Markupper" type="text" v-model="Markup"  placeholder="##.#" class=" my-0 form-control form-control-xs">
    </div>
    <div  class="col-sm-4 mb-0"   v-show="$v.Markup.$error">
      <div class="row">
        <small class="sml-red" v-if="!$v.Markup.isPercent">Must be a valid %.</small>
        <!-- <small class="sml-red" v-if="!$v.Markup.required">Markup is required.</small> -->
      </div>
      <!-- <div class="row">
        <small class="sml-red" v-if="!$v.Markup.T1Check">Must enter Tooth1 first.</small>
      </div>     -->
    </div>
  </div>
  <div class="form-group row my-0" v-if="this.AppServiceID==2">
    <div class="col-sm-4">  
    </div>
    <div class="col-sm-4 sml-red pl-3">      
       <b>Format : 12.5% , 12% </b>
    </div>
    <div class="col-sm-4 sml-red">      
         
    </div>
  </div>
  <div class="form-group row my-1">
    <label for="Tooth2" class="col-sm-4 label-small">Shipping Cost:</label>
    <div class="col-sm-4">      
      <input id="Tooth2" type="text" v-model="ShippingCost"  placeholder="Shipping Cost" class=" my-0 form-control form-control-xs">
    </div>
    <div  class="col-sm-4 mb-0"   v-show="$v.ShippingCost.$error">
      <div class="row">
        <small class="sml-red" v-if="!$v.ShippingCost.fee">Must be a valid cost.</small>
      </div>
      <!-- <div class="row">
        <small class="sml-red" v-if="!$v.Markup.T1Check">Must enter Tooth1 first.</small>
      </div>     -->
    </div>   
  </div>
<div class="form-group row my-1" v-if="ClaimTypeID==1">
    <label for="third" class="col-sm-4 label-small">1st Payer Paid Amount (if applicable):</label>
    <div class="col-sm-4">      
      <input id="third" type="text"   v-model="ThirdPartyAmt"  placeholder="1st Payer Paid Amount" class=" my-0 form-control form-control-xs">
    </div>
    <div  class="col-sm-4 mb-0"   v-show="$v.ThirdPartyAmt.$error">
      <div class="row">
          <small class="sml-red" v-if="!$v.ThirdPartyAmt.fee">must be a valid amount.</small>
          </div>
    </div>
</div>

  <div class="form-group row my-1" v-if="this.SelectedClaimStatusID===4 && this.ClaimInfo.CanOverride">
    <label for="third" class="col-sm-4 label-small">Assessed Amount</label>
    <div class="col-sm-4">      
      <input id="dpamt" type="text"   v-model="AssessedAmt"  placeholder="Assessed Amount" class=" my-0 form-control form-control-xs">
    </div>
    <div  class="col-sm-4 mb-0"   v-show="$v.AssessedAmt.$error">
      <div class="row">
          <small class="sml-red" v-if="!$v.AssessedAmt.fee">must be a valid amount.</small>
          <small class="sml-red" v-if="!$v.AssessedAmt.val">enter a valid amount.</small>
 </div>
    </div>
  </div>

 <div class="form-group row my-0 pb-0">
    <label for="Tooth2" class="col-sm-4 label-small">Tax1:</label>
    <div class="col-sm-4 mb-0" >      
      <template class="mb-0"><RadioToggleButtons v-model='Tax1' :values='taxes'  color='#006537'
      textColor='#000' selectedTextColor='#fff' /><span v-on:click="Tax1=''" style="font-size: .7em;"><i class="fas fa-times ml-2 pointer"></i>  </span></template>
    </div> 
    <div  :class="{ 'col-sm-4 mb-0': $v.Tax1.$error}"   v-show="$v.Tax1.$error"> 
      <div class="row">
        <small class="sml-red" v-if="!$v.Tax1.needValue">Tax1 and Tax2 can't be same.</small>  
      </div>      
    </div>
  </div>

   <div class="form-group row my-0">
    <label for="Tooth2" class="col-sm-4 label-small">Tax2:</label>
    <div class="col-sm-4">      
      <template><RadioToggleButtons v-model='Tax2' :values='taxes'  color='#006537'
      textColor='#000' selectedTextColor='#fff' /><span v-on:click="Tax2=''" style="font-size: .7em;"><i class="fas fa-times ml-2 pointer"></i>  </span> </template>
    </div>
    <div  :class="{ 'col-sm-4 mb-0': $v.Tax2.$error}"   v-show="$v.Tax2.$error"> 
      <div class="row">
        <small class="sml-red" v-if="!$v.Tax2.needValue">Select Tax1 First.</small>  
      </div>      
    </div> 
  </div>

</form>

<h6><small class="text-muted"><b>{{Note}}</b></small></h6> 
<hr>
<div class="row">
    <div class="col-sm-6">
        <button v-on:click="AddEditPA" type="button" class="btn BtnSave  btn-sml"><i :class="saveIcon"></i> {{btnName}} </button>
    </div>
        <!-- {{adduser}} -->
    <div class="col-sm-6">
        <button v-on:click="Exit" type="button" class="btn BtnClose btn-sml float-right"><i class="fas fa-times"></i> Close Form </button>
    </div>
</div>  
</div>
</template>
<script>
import axios from 'axios'
import Vue from 'vue'; 
import Vuelidate from 'vuelidate'
import { helpers } from 'vuelidate/lib/validators'
//import vselect from 'vue-select'
import Datepicker from 'vuejs-datepicker'
import moment from 'moment'
import {required,minLength,sameAs, not, maxLength,numeric} from 'vuelidate/lib/validators'
import { notEqual } from 'assert';
import { constants } from 'fs';
const Panumber = helpers.regex('Panumber',  /^([0-9]{21})$/);
const qtyreg = helpers.regex('qtyreg',  /^[0-9]{2}$/);  
//const fee = helpers.regex('fee',  /^\d+(\.\d{1,2})?$/); 
const isPercent = helpers.regex('alphaNum', /100$|^[0-9]{1,2}$|^[0-9]{0,3}\.[0-9]{1}$/);
const fee = helpers.regex('fee', /^[0-9]{0,6}(\.[0-9]{1,2})?$/) 
//import 'vue-select/dist/vue-select.css'; /^([0-9]{15}|9)$/
Vue.use(Vuelidate);

export default {
    props:{ClaimInfo:{type: Object},ServiceCodeInfo:{type:Object},ServiceID:''},
    data: function () {
    return {
            AssessedAmt:null,
            saveIcon:'fas fa-plus',
            btnName: 'Add Service Code',
            Note:'Note: You can add one or more Service Codes using the Add button below. Must add at least one service code to proceed.',
            ClaimStatusId:'',
            SelectedClaimStatusID:'',
            calendarwidth: '50px',
            ClaimRequestNo:null,
            ClaimTypeID:'',
            HSN:'',
            PriorApprovalNo:null,
            ProviderNo:'',
            ClinicNo:'',
            ServiceCode:'',
            ServiceCodeId :null,
            ServiceFee:'',
            ServiceDate:'',
            ExpiryDate:null,
            Qty:'',
            ACQCost:null,
            Markup:null,
            ThirdPartyAmt:null,
            ShippingCost:null, 
            Tax1:'', 
            Tax2:'', 
            taxes :[],
            SelectedCode:'',
            AppServiceID:'',
            ServiceCodes:[], 
            datapickClass:"form-control form-control-xs my-0", 
            updateMessage:'',
            showUpdate:true, 
            activeColor: 'red',
            fontSize: 30,   
            exit: '',
            dateFormat: '',
            succeeded: false,
            Msg:'',
            showModal:false 
        }
     },
    components: {
        Datepicker,
          
    }, 
    filters: {
          moment: function (date) {
          return moment(date,"YYYY-MM-DD").format('YYYY/MM/DD');
          },
          stringify(value) {
          return JSON.stringify(value, null, 2)
          }  
        },
    methods: {
        PopMsgClose(){
           
            if(this.succeeded)
            {
               this.ClrForm();
               this.showModal = false;
               if(this.ServiceCodeId!=null && this.ServiceCodeId != undefined)
               {
                  this.Exit();
               }
               
            }
            else
            {
               //this.ClrForm();
               this.showModal = false;
            } 
        },
         ClrForm:function()
         {
           //this.$forceUpdate();
            //this.searchbox.value = ''; 
            this.ServiceCode ='';
            //this.ServiceCodeId ='';
            this.ServiceFee='';
            this.ServiceDate='';
            this.Qty='';
            this.ACQCost=null;
            this.Markup=null;
            this.ThirdPartyAmt=null;
            this.expirydate = null;
            this.ShippingCost = null;
            // this.Comments='';
            this.SelectedCode='';
            this.Tax1='';
            this.Tax2='';
            this.PriorApprovalNo=null;
            this.$refs.searchbox.inputValue = ''
         },
         EditPA :function(event)
          {
            var vm = this;
              var url = "/SaskHealthApi/Claims/PostEditClaimServiceCode/"
              var params = {
                  "_": Date.now(),
                  "ServiceCodeID": vm.ServiceCodeId,"ServiceID": vm.AppServiceID,"Qty": vm.Qty, //"ServiceDate": vm.ServiceDate,
                  "ACQCost": vm.ACQCost,"ShippingCost": vm.ShippingCost,"Markup": vm.Markup,"ServiceCode":vm.SelectedCode.servicecode,"ServiceCodeDesc":vm.SelectedCode.servicedesc,
                  "ClaimRequestNo":vm.ClaimRequestNo,"ThirdPartyAmt" :vm.ThirdPartyAmt, "ExpiryDate" : vm.ExpiryDate, "PriorApprovalNo": vm.PriorApprovalNo,
                  "Tax1": vm.Tax1,"Tax2": vm.Tax2,
                   "AssessedAmt": vm.AssessedAmt
                  } 
                  axios({
                      method: 'post',
                      url: url,
                      headers: { 'Authorization': 'Bearer ' + vm.$store.getters.GetAccessToken },
                      data: params
                      }).then(function (response) {
                          if(response.status ==200)
                              {    
                                  vm.showModal =true;
                                  vm.succeeded = true;
                                  vm.Msg= "Service Code successfully updated";                           
                                  //vm.ClaimRequestNo = response.data;
                                  console.log(response.data);
                                  // if (response.data.succeeded)
                                  // {
                                  //       vm.showModal =true;
                                  //       vm.succeeded = true;
                                  //       vm.Msg= "Service Code successfully updated"; 
                                  // } 
                              }
                      })
                  .catch(function (error) {
                      if (error.response) {
                      //console.log(error.response.data);
                        //console.log(error.response.status);
                        if(error.response.status ==500)
                        {                   
                            vm.succeeded = false;
                            vm.Msg="System Error; service code is not successfully saved."; 
                            vm.showModal=true; 
                        }
                        //console.log(error.response.headers);
                      }
                      console.log(error)
                  });
          },
         AddPA:function(event)
          {
            var vm = this;
              var url = "/SaskHealthApi/Claims/PostAddClaimServiceCode/"
              var params = {
                  "_": Date.now(),
                  "HSN": vm.HSN,
                  "ProviderNo": vm.ProviderNo,
                  "ClaimTypeID": vm.ClaimTypeID,
                  "ClinicNo": vm.ClinicNo,
                  "ServiceID": vm.AppServiceID,
                  "ServiceDate": vm.ServiceDate,
                  "Qty": vm.Qty,
                  "ACQCost": vm.ACQCost,
                  "ShippingCost": vm.ShippingCost,
                  "Markup": vm.Markup, 
                  "ServiceCode":vm.SelectedCode.servicecode,
                   "ServiceCodeDesc":vm.SelectedCode.servicedesc,
                  // "ServiceFee":vm.ServiceFee,
                  "ClaimRequestNo":vm.ClaimRequestNo,
                  "ThirdPartyAmt" :vm.ThirdPartyAmt,
                  "ExpiryDate" : vm.ExpiryDate,
                  "PriorApprovalNo": vm.PriorApprovalNo,
                  "Tax1": vm.Tax1,
                  "Tax2": vm.Tax2,
                  } 
                  axios({
                      method: 'post',
                      url: url,
                      headers: { 'Authorization': 'Bearer ' + vm.$store.getters.GetAccessToken },
                      data: params
                      }).then(function (response) {
                          if(response.status ==200)
                              {                              
                                  vm.ClaimRequestNo = response.data;
                                  console.log( vm.ClaimRequestNo);
                                  if (vm.ClaimRequestNo!=null)
                                  {
                                        vm.showModal =true;
                                        vm.succeeded = true;
                                        vm.Msg= "Service Code successfully added"; 
                                  }
                              }
                      })
                  .catch(function (error) {
                      if (error.response) {               
                        if(error.response.status ==500)
                        {                   
                            vm.succeeded = false;
                            vm.Msg="System Error; service code is not successfully saved."; 
                            vm.showModal=true; 
                        }                     
                      }
                      console.log(error)
                  });
          },
         AddEditPA: function (event) {
            var vm = this;
            this.$v.$touch();
            //console.log(vm.SelectedCode)
            //console.log(vm.ServiceCode);
            //this.$refs.searchbox.clear();
            //console.log(this.$refs.searchbox)
           //this.ClrForm()
           console.log(vm.ServiceCodeId)
           if (!this.$v.$invalid){
             console.log('t')
              if(vm.ServiceCodeId !=null)
              {
                  this.EditPA();
              }
              else
              {
                  this.AddPA();
              }
           } 
         },
         Exit: function (event) {
          this.$root.$emit('bv::hide::modal', 'modal-PA', '#btnShow');
          this.$emit('ServiceCodeDone', this.ClaimRequestNo);
        }, 
        Go(){
            this.$router.push('/DPEBB/MainHome')
        },
         Show(){
             this.showModal =true;
        },
        GetTaxes: function(ErrorCode) { 
        var t=[]; 
         var vm = this;
         
          var params = new URLSearchParams();  
            axios.get('SaskHealthApi/Codes/GetTaxType', { headers: { 'Authorization': 'Bearer ' + localStorage.access_token },params})
            .then(function (response) {
                 vm.t = response.data;
            }).catch(function (er) {
                console.log(er)
            }).then(function () {
                _.forEach(vm.t, function(value, key) {
                vm.taxes.push({'label' : value.tax,'value' : value.tax});
              });
                //vm.taxes.push({'label' : 'NONE','value' : 'NONE'});
            }); 
        },
        GetServiceCodes(){ 
           var vm = this;
           console.log('Service ID at GET ' +  this.AppServiceID)
            var params = new URLSearchParams();
             params.append('ServiceID', this.AppServiceID);
             axios.get('SaskHealthApi/Codes/GetServiceCode', { headers: { 'Authorization': 'Bearer ' + localStorage.access_token },params})
             .then(function (response) {
                    //console.log(response.data);
                    vm.ServiceCodes =response.data; 
                    //console.log(vm.ServiceCodes)
                })
            .catch(function (er) {
                console.log(er)
            })
        },

      ValidateTax1(){ 
        console.log('Tax1:'+ this.Tax1)
       if(this.Tax1 !==null &&  this.Tax1 !=='')
        {
           if(this.Tax2 !==null ||  this.Tax2 !=='')
            {
               if(this.Tax1===this.Tax2)
               {
                 return false;
               }
               else
               {
                 return true;
               }
            }
            else
            {
              return true;
            } 
        }
        else
        {
          return true;
        } 
      },
      ValidateTax2(){
        if(this.Tax2 !==null &&  this.Tax2 !=='')
        {
            if(this.Tax1 === null || this.Tax1==='')
            {
              return false;
            }
            else
            {
              return true;
            }
        }
        else
        {
          return true;
        }
      },
      ValAssessedAmt()
        {
          if(this.SelectedClaimStatusID===4 && this.ClaimInfo.CanOverride)
          {
             if(this.AssessedAmt == null || this.AssessedAmt =="" )
             {
               return false;
             }
             else
             return true;
          }
          else
          return true;
        }, 
 
    }, 
    created: function() {  
        this.AppServiceID = this.ServiceID;
        
        this.dateFormat= this.$store.getters.GetDateFormat;      
        this.HSN = this.ClaimInfo.HSN;
        this.ProviderNo = this.ClaimInfo.ProviderNo;
        this.ClinicNo = this.ClaimInfo.ClinicNo;
        this.ClaimRequestNo = this.ClaimInfo.ClaimRequestNo;
        this.ClaimStatusId = this.ClaimInfo.StatusID;
        this.SelectedClaimStatusID = this.ClaimInfo.SelectedID;
        this.ClaimTypeID = this.ClaimInfo.ClaimTypeID;
        //console.log('tax  no ' + this.ServiceCodeInfo.tax2)
        if(this.ClaimTypeID !=undefined && this.ClaimTypeID===1)
        {
            //console.log('sss' + this.ServiceCodeInfo.PriorApprovalNo)
            this.PriorApprovalNo = this.ServiceCodeInfo.PriorApprovalNo;
        }
        if(this.SelectedClaimStatusID !=undefined && this.SelectedClaimStatusID===4)
        {
            //console.log('Assessed Amount = ' + this.ServiceCodeInfo.AssessedAmt)
            this.AssessedAmt = this.ServiceCodeInfo.AssessedAmt;
        }
        if(this.ServiceCodeInfo.acqcost !=undefined)
        {
            this.ACQCost=this.ServiceCodeInfo.acqcost;
            //console.log('Comment through Edit val' + this.Comments);
        }
        if(this.ServiceCodeInfo.expirydate !=undefined)
        {
            this.ExpiryDate=this.ServiceCodeInfo.expirydate;
        }
        if(this.ServiceCodeInfo.description !=undefined && this.ServiceCodeInfo.servicecode !=undefined)
        {
            //this.$refs.searchbox.inputValue = this.ServiceCodeInfo.description;
            // this.ServiceCode=this.ServiceCodeInfo.description;
            this.SelectedCode ={"servicecode": this.ServiceCodeInfo.servicecode , "servicedesc": this.ServiceCodeInfo.description  }
        } 
        // if(this.ServiceCodeInfo.servicecode !=undefined)
        // {
        //     console.log(this.ServiceCodeInfo.servicecode);
        //     this.ServiceCodeId=this.ServiceCodeInfo.servicecode;
        // }
        if(this.ServiceCodeInfo.servicecodeid !=undefined || this.ServiceCodeInfo.servicecodeid !=null)
        {
            //console.log(this.ServiceCodeInfo.servicecodeid);
            this.btnName = 'Edit Service Code';
            this.saveIcon = 'far fa-edit';
            this.Note='';
            this.ServiceCodeId=this.ServiceCodeInfo.servicecodeid;
        }
         if(this.ServiceCodeInfo.servicedate !=undefined)
        {
            this.ServiceDate=this.ServiceCodeInfo.servicedate;
        }
        if(this.ServiceCodeInfo.servicefee !=undefined)
        {
            this.ServiceFee=this.ServiceCodeInfo.servicefee;
        }
        if(this.ServiceCodeInfo.qty !=undefined)
        {
            this.Qty=this.ServiceCodeInfo.qty;
        }
         if(this.ServiceCodeInfo.thirdpartyamt !=undefined)
        {
            this.ThirdPartyAmt=this.ServiceCodeInfo.thirdpartyamt;
        }
        if(this.ServiceCodeInfo.markup !=undefined)
        {
            this.Markup = parseFloat((this.ServiceCodeInfo.markup * 100).toFixed(1));  
            //this.Markup=this.ServiceCodeInfo.markup;
        }
        //console.log(this.ServiceCodeInfo)
        if(this.ServiceCodeInfo.shippingcost !=undefined)
        {
            this.ShippingCost=this.ServiceCodeInfo.shippingcost;
        }
        if(this.ServiceCodeInfo.tax1 !=undefined)
        {
            this.Tax1=this.ServiceCodeInfo.tax1;
        }
        if(this.ServiceCodeInfo.tax2 !=undefined)
        {
            this.Tax2=this.ServiceCodeInfo.tax2;
        }
    },
    mounted: function () {
      this.$nextTick(function () {
        var vm = this;
        vm.GetServiceCodes();
        vm.GetTaxes();
        if(this.ServiceCodeInfo.description !=undefined && this.ServiceCodeInfo.servicecode !=undefined)
        {
            this.$refs.searchbox.inputValue = this.ServiceCodeInfo.description;
            // this.ServiceCode=this.ServiceCodeInfo.description;
            //this.SelectedCode ={"servicecode": this.ServiceCodeInfo.servicecode , "servicedesc": this.ServiceCodeInfo.description  }
        }
      })
      },
     validations(){
      return {  
            Qty:{
              required,
               val: value=> (value<50 && value !=0),
              numeric 
            },  
          //  ServiceFee : {
          //     required, 
          //     fee
          //   },
            ThirdPartyAmt : { 
              fee
            },  
            AssessedAmt : { 
              fee,
              val : value => this.ValAssessedAmt()
            },  
            SelectedCode:{ 
               required,
            }, 
            PriorApprovalNo:{
              numeric,
              Panumber
            },
            ACQCost : { 
              required,
              fee
            },  
            ShippingCost : { 
              fee
            }, 
           Markup : { 
              //required,
              isPercent
            },
            Tax1:{
              needValue:value=>  this.ValidateTax1(),
            }, 
            Tax2:{
              needValue:value=>  this.ValidateTax2(),
            }  

        }
     }

}
</script>
<style scoped>
/* radio-toggle-button {
  position: relative;
  cursor: pointer;
  border: 1px solid #ccc;
  border-collapse: collapse;
  margin-top: .0rem;
  padding-top: .0rem;
  padding-right: .2rem;
  padding-bottom: .5rem;
  padding-left: .2rem;
  transition-property: color, border, background-color;
  transition-duration: 0.5s;
  transition-timing-function: ease-in-out;
  z-index: 0;
} */
</style>