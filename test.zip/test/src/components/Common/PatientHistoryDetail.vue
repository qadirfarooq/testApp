<template>
<div >  
<div class="row no-gutters Hometitle pl-2 mt-0 pt-0"> 
    <div class="col-sm-8">            
    <h4 v-if="this.hDetails.claimType == 'CL'"><small class="text-muted">  <strong> {{AppName}} : Patient Claim History</strong> </small></h4> 
    <h4 v-else><small class="text-muted">  <strong> {{AppName}} : Patient Prior Approval History</strong> </small></h4> 
   
    </div> 
    <div class="col-sm-4">
     <button  v-on:click="Exit"  type="button" class="ml-1 btn btn-primary btn-sml float-right"><i class="far fa-times-circle"></i>Close</button>
     <button  v-on:click="GeneratePDF" type="button" class="btn btn-outline-primary btn-sml float-right">  <i class="fas fa-print"></i> Print</button>      
    </div>  
</div>

<div id="PriorApprovalForm" v-if="!(ClaimRequestNo==null)" class="mb-2 mt-1">
  <div class="row no-gutters"> 
    <div class="col-4 pr-1" v-if="selectedPatient!=null">
      <div class="card">
        <div class="card-header d-flex align-items-center" style="height: 2rem; margin:0;padding:0 !important;">
          <h5>
            <small class="text-muted pl-1" style="text-align:left;"><b><i class="fas fa-user-injured"></i>Patient: {{selectedPatient.firstName}} {{selectedPatient.lastName}}</b>
            </small>
          </h5>  
        </div> 
        <div  class="card-body p-2 mb-0" v-if="selectedPatient!=null">
          <div class="row" >
            <span for="cname" class="col-sm-4"><b>HSN:</b></span> 
            <span   class="col-sm-8" type="text">{{selectedPatient.hsn}}</span> 
          </div>
          <div class="row">
            <span for="cname" class="col-sm-4"><b>Address:</b></span> 
            <span class="col-sm-8" type="text">{{selectedPatient.address1}} {{selectedPatient.address2}}</span> 
          </div>
          <div class="row">
            <span for="cname" class="col-sm-4"><b>DOB:</b></span> 
            <span class="col-sm-8" type="text">{{selectedPatient.birthDay|moment}} </span> 
          </div>   
        </div> 
      </div>
    </div>
  
    <div class="col-4 pr-1" v-if="selectedClinic!=null">
      <div class="card">
        <div class="card-header   d-flex align-items-center  pl-1" style="height: 2rem; text-align:left;">
          <h5><small class="text-muted"><b><i class="fas fa-clinic-medical"></i>Clinic: {{selectedClinic.clinicname}}</b></small></h5>
        </div>
        <div  class="card-body p-2 mb-0"> 
          <div class="row">
            <span for="cname" class="col-sm-4"><b>Clinic #:</b></span> 
            <span class="col-sm-8" type="text">{{selectedClinic.clinicno}}</span> 
          </div>
          <div class="row">
            <span for="cname" class="col-sm-4"><b>Address:</b></span> 
            <span class="col-sm-8" type="text">{{selectedClinic.address}}</span> 
          </div>
          <div class="row">
            <span for="cname" class="col-sm-4"><b>City:</b></span> 
            <span class="col-sm-8" type="text">{{selectedClinic.city}}</span> 
          </div> 
        </div>  
      </div>
    </div> 
    <div class="col-4 pr-1" v-if="selectedProvider!=null">
        <div class="card">
          <div class="card-header   d-flex align-items-center  pl-1" style="height: 2rem; text-align:left;">
           <h5 v-if="selectedProvider.providername.length<25"><small class="text-muted"><b><i class="far fa-file-powerpoint"></i>Provider: {{selectedProvider.providername}}</b></small></h5>
           <h5 v-else style="font-size: 90%;"><small class="text-muted"><b><i class="far fa-file-powerpoint"></i>Provider: {{selectedProvider.providername}}</b></small></h5>
       
            <!-- <h5><small class="text-muted"><b> <i class="far fa-file-powerpoint"></i>Provider: {{selectedProvider.providername}}</b></small></h5> -->
          </div>
          <div  class="card-body p-2 ">
              <div class="row" >
                <span for="cname" class="col-sm-4"><b>Provider #:</b></span> 
                <span   class="col-sm-8" type="text">{{selectedProvider.orgid}}{{selectedProvider.providerno}}</span> 
              </div>
              <div class="row" >
                <span for="cname" class="col-sm-4"><b>Service:</b></span> 
                <span   class="col-sm-8" type="text">{{selectedProvider.service}}</span> 
              </div>
              <div class="row" >
                <span for="cname" class="col-sm-4"><b>Service Type:</b></span> 
                <span   class="col-sm-8" type="text">{{selectedProvider.subtype}}</span> 
              </div>    
          </div> 
        </div> 
        </div> 
  </div>
   
  <div id="ServiceCodeGrid" class="mt-2"> 
        <v-client-table :columns="columns" :data="SourceCodeData" :options="options"  ref="table">
        <template slot="errorcode" slot-scope="props">
          <span class="pointer"  :class="getMsgClass(props.row.errorcode)"   v-on:click="GetMsg(props.row.errorcode)"><i class="fas fa-comment-medical"></i>{{props.row.errorcode}}</span>
        </template>
        
        </v-client-table> 
    </div> 
  <div class="card" id="PAFormUploadStatus">
  <div class="row mt-2 no-gutters">
      <div class="col-6">
        <div class=" mr-1">
        <div class="card-header   d-flex align-items-center  pl-1" style="height: 2rem; text-align:left;">
          <h5><small class="text-muted"><b><i class="fas fa-thumbs-up"></i>Claim Data:</b></small></h5>
        </div>
        <form>
          <div class="p-2 pb-0 mb-0" > 
            <div class="form-group row my-1" v-if="isAssessor">               
              <label for="ClaimNotes" class="col-sm-5 label-small">Created By: </label>
              <div class="col-sm-7"> 
               
                    {{this.hDetails.addLogonID}} ({{this.hDetails.addDate | moment(this.hDetails.addDate)}} <i class="far fa-clock fa-xs"></i>{{this.hDetails.addTime}})
              
              </div>                 
            </div>
            <div class="form-group row my-1" v-if="isAssessor">               
              <label for="ClaimNotes" class="col-sm-5 label-small">Modified By:</label>
              <div class="col-sm-7"> 
                 {{this.hDetails.modifyLogonID}} ({{this.hDetails.modifyDate | moment(this.hDetails.modifyDate)}} <i class="far fa-clock fa-xs"></i>{{this.hDetails.modifyTime}})
              </div>                 
            </div>

            <div class="form-group row my-1">               
              <label for="ClaimNotes" class="col-sm-5 label-small">Notes</label>
              <div class="col-sm-7"> 
                   {{this.hDetails.claimNotes}}                
              </div>                 
            </div>
            <div class="form-group row my-1">               
                  <label for="lab" class="col-sm-5 label-small">Service Date:</label>
                  <div class="col-sm-4">      
                   {{ServiceDate | moment(ServiceDate)}}   
                  </div> 
            </div>
            <div class="form-group row my-1">               
                  <label for="lab" class="col-sm-5 label-small">Lab Name:</label>
                  <div class="col-sm-4">
                     {{this.hDetails.labName}}	
                    <!-- <input id="lab" type="text" min="1" max="50" v-model="LabName"  placeholder="Lab Name" class=" my-0 form-control form-control-xs"> -->
                  </div> 
            </div>

            <div class="form-group row my-0">
                  <label  class="col-sm-5 label-small">1st Payer Paid Amount (if applicable):</label>
                  <div class="col-sm-4">      
                      {{PaidByThirdPArty}}   
                  </div> 
            </div>

            <div class="form-group row my-0">
                  <label  class="col-sm-5 label-small">Temporary Health Certificate:(THC)</label>
                  <div class="col-sm-3">      
                      {{this.hDetails.thcIndicator}}   
                  </div> 
            </div>
            <transition name="slide-fade"> 
            <div v-if="this.hDetails.thcIndicator=='Y'">
              <div class="form-group row my-1" >               
                    <label for="eff" class="col-sm-5 label-small">THC: Effective Date:</label>
                    <div class="col-sm-4">      
                      {{THCEffectDate | moment(THCEffectDate)}}
                    </div> 
              </div> 
              <div class="form-group row my-1">               
                <label for="exp" class="col-sm-5 label-small">THC: Expiry Date:</label>
                <div class="col-sm-4">      
                    {{THCExpiryDate | moment(THCExpiryDate)}}
                </div> 
              </div> 
            </div>
             </transition> 
             <div class="form-group row my-0" v-if="isAssessor">
                <label  class="col-sm-5 label-small">Reimburse to Patient:</label>
                <div class="col-sm-4">      
                    {{ReimburseToPatient}}	
                </div> 
              </div> 
          </div>
        </form>
        </div>
      </div>
      <div class="col-6">
        <div class="">
        <div class="card-header   d-flex align-items-center  pl-1" style="height: 2rem; text-align:left;">
          <h5><small class="text-muted"><b><i class="fas fa-upload"></i>Documents:</b></small></h5>
        </div>
        <div class=" p-2 pb-0 mb-0" >           
          <div class="form-group row">
                <label for="Qty" class="col-sm-10 label-small">X-Rays and documents:</label>
                <div class="col-sm-2">      
                    {{this.hDetails.claimattachment}}
                </div>                              
          </div>        
          <transition name="slide-fade">            
          <div v-if="this.hDetails.claimattachment=='Y'"  class="row mt-2" id="docimg" style="display: flex; justify-content: center;">
            <v-client-table id="docGrid" :columns="docColumns" :data="docList" :options="docOptions">
            <span class="pointer" v-on:click="OpenClaimDoc(props.row)" slot="docname" 
              slot-scope="props">
                <a> {{props.row.docname}} </a>
            </span>       
            </v-client-table>
          </div>
           </transition>
        </div>
        </div>
      </div>    
  </div>
  <div class="row mt-2 no-gutters PayeeForm" id="PatientPayeeForm"  v-if="isAssessor && this.ReimburseToPatient == 'Y' && this.GivenName!='' && this.PostalCode!=''">   
    <div class="col-12">
      <div class="card-header d-flex align-items-center  pl-1" style="height: 2rem; text-align:left;">
        <h5><small class="text-muted"><b><i class="fas fa-file-invoice-dollar" aria-hidden="true"></i>Patient Payee:</b></small></h5>
      </div>
    </div>

      <div class="col-6">
        <div class=" mr-1">   
          <div class="p-2 pb-0 mb-0" >  
            <div class="form-group row my-1">               
                  <label for="lab" class="col-sm-5 label-small">Payee Name:</label>
                  <div class="col-sm-7">      
                     {{this.hDetails.payeeName}}
                  </div> 
            </div> 
          </div> 
        </div>
      </div>
      <div class="col-6">
        <div class="form-group row my-1">               
              <label for="lab" class="col-sm-5 label-small">Address:</label>
              <div class="col-sm-7">      
                  {{this.hDetails.payeeAddress1}}, {{this.hDetails.payeeAddress2}} ,  {{this.hDetails.payeePostal}} , {{this.hDetails.payeeProv}}
              </div> 
        </div> 
      </div>    
  </div>
  
    <div class="mt-1  no-gutter" v-if="isAssessor && this.hDetails.overideNote!=''">
      <div class="col-12 row">
        <div class="col-2 mr-0">
          <b class="ml-1">Manual Approval Notes:</b>
        </div>   
        <div class="col-sm-8 pl-5 ml-3 row"> 
            {{this.hDetails.overideNote}}
        </div>  
      </div>
    </div>

  </div>  
  </div>
 <!-- form upload status End -->  

  <!-- <i class="fab fa-buffer fa-2x"></i> -->    
</div><!-- Prior Approval PRocess End --> 
</template>
<script>

import Vue from 'vue';
import {mapGetters} from 'vuex'
import moment from 'moment'
import axios from 'axios' 
//import PAShowCoverageInfo from '@/components/Common/PAShowCoverageInfo.vue';
//import PAShowHSNInfo from '@/components/Common/PAShowHSNInfo.vue';
//import PAAddEdit from '@/components/Dental/ClaimPAAddEdit.vue';
import LayoutDefault from '@/Common/Default/DefaultLayout.vue';
import Subtitle from '@/Common/Default/SubTitle.vue';  
import Card from "@/Common/Card.vue";
import CardBody from "@/Common/CardBody.vue";
import TileNote from "@/Common/TileNote.vue";
import { PopUpVariant } from '@/Common/Default/PopUpVariant';
import { SKLogoString } from '@/Common/Default/SKLogo';
import { isNullOrUndefined } from 'util';
import VueUploadMultipleImage from 'vue-upload-multiple-image'; 
import Datepicker from 'vuejs-datepicker';
import Vuelidate from 'vuelidate'
import { helpers } from 'vuelidate/lib/validators'
import jsPDF from 'jspdf'   // used for GeneratePDF
import autoTable from 'jspdf-autotable'    // used for GeneratePDF
const SixvTwo = helpers.regex('SixvTwo', /^[0-9]{0,6}(\.[0-9]{1,2})?$/)
const OnevThree = helpers.regex('OnevThree',/^1{1}(\.[0]{1,3})?$|^0{0,1}(\.[0-9]{1,3})?$/)
const alpha = helpers.regex('alpha', /^[a-zA-Z]*$/)
const postal = helpers.regex('postal',  /^[A-Za-z]\d[A-Za-z][ -]?\d[A-Za-z]\d$/);
const alphaNum = helpers.regex('alphaNum', /^\d{1,5}\s\w*/)
const Panumber = helpers.regex('Panumber',  /^([0-9]{9})$/);
Vue.use(Vuelidate)
import { required, minLength, maxLength, between,withParams,numeric} from 'vuelidate/lib/validators'
export default  {
  name: 'PatientHistoryDetail',
  props: {
      hDetails: { required: true },
      claimRequestNumber: { required: true },
      selectedProvider: { required: true },
      selectedClinic: { required: true },
      selectedPatient: { required: true }, 
      isAssessor: { required: true}, 
      AppName: {required: true},
  },
  data: function () {
    return {
        ErrorAndDesc:[],  
        ClaimStatusDisable:true,
        TypeHeadinptClass:'form-control form-control-xs',
        dis:true,
        Prov:['AB', 'BC', 'MB', 'NB', 'NL', 'NT', 'NS', 'NU', 'ON', 'PE', 'QC', 'SK', 'YT'],  
        ViewNotesCoverage:false,
        DisableStatus:false,
        LabName:'',
        PaidByThirdParty:false,
        TempTHC:false,
        THCEffectDate:'',
        THCExpiryDate:'',
        DocUpload:false,
        ServiceDate:'',
        ReimburseToPatient:'N', 
        ClaimNotes:'',
        ClaimNotesAvailable:false,
        ThirdPartyPaidSign:"+",
        ThirdPartyPaidAmt:0,
        OverRideNotes:'',  
        PayeeHSN:null,
        GivenName:'',
        SurName:'',
        Address1:'',
        Address2:'',
        Province:'SK',
        PostalCode:'',        
        dateFormat : '',       
        CanOverRide:false,
        ClaimStatusID:'', 
        datapickClass:"form-control form-control-xs my-0",  
        GetNotes:false,
        showNotesCov:false,
        ImageType:'image/gif,image/jpeg,image/png,image/bmp,image/jpg,image/jp2,image/jpx,image/jpf',
        boxTwo: '',
        BtnSubmitdisabled:false,
        popupTitle:'Dental HSN Notes',
        PopAddEditTitle:'Add Service Code Form',
        popupText:'',         
        primaryText:'',
        PaidByThirdPArty:false,
        dragText:'Upload X-Rays and Documents',
        browseText:'Click Here',
        AppServiceID :0,
        MaxMatch:20,  
        title:"Dental Application",
        subtitle: "Welcome", 
        HSN:'',
        ProviderNo:'',
        Showinfo : false,
        Provider:[{'providerno': 1000, 'providername': 'test'}],
        Clinic: [],
        ClinicNo:'',
        SelectedClinic:null,
        images: [],
        SourceCodeData: [],
        fileList :'',
        Patient:null,
        PopUpVar:PopUpVariant,
        SKLogoConst:SKLogoString,         
        showModal:false,
        ClaimInfo:null,
        ServiceCodeInfo:null,
        RequestForm:true,
        ClaimRequestNo:null,        
        ClaimStatus:[{id:3,text:'In Progress'}],
        SelectedClaimStatus:'',
        ServiceStatus: [],
        docList: [],
        NewOverrideStatus:'',    
        columns: ['codestatuspa','voidind','errorcode','priorapprovalno','dateexpiry','servicecodedescription','servicecode','qty','amtchargeacq','thirdpartypaidamt','amtpaiddpebb', 'tax1type','tax1amt','tax2type','tax2amt'],
        docColumns: ['docname', 'doctypeicon', 'createddate'],
        options: {
        texts:{
              count:"Showing {from} to {to} of {count} records|{count} records|One record",
              first:'First',
              last:'Last',
              limit:"Records:",
              page:"Page:",
              noResults:"No Service Code Found",
              loading:'Loading...',
              defaultOption:'Select {column}',
              columns:'Columns'
          },
          responseAdapter({data}) { 
              return {
                data: formatData,
                count: data.length
              };
            },
         // skin:'table table-hover',
          perPage:10,
          perPageValues:[10,15,25],
          dateColumns:['servicedate'],
          //toMomentFormat: 'YYYY/MM/DD',
          //templates: {edit: 'edit'},
          templates: {
            dateexpiry(h, row) {
             // moment.locale('es');               
              return moment(row.dateexpiry,"YYYY-MM-DD").format('YYYY/MM/DD');  
            }, 
            servicecodedescription(h, row) {                           
              return   <div style="font-size: 70%">{row.servicecodedescription}</div> ;
            }, 
            thirdpartypaidamt(h, row) {   
              return <div>${Number.parseFloat(row.thirdpartypaidamt).toFixed(2)}</div> ; 
            }, 
            amtpaiddpebb(h, row) {   
              return <div>${Number.parseFloat(row.amtpaiddpebb).toFixed(2)}</div> ; 
            },  
            amtchargeacq(h, row) {   
              return <div>${Number.parseFloat(row.amtchargeacq).toFixed(2)}</div> ; 
            },  
            codestatuspa(h, row) {
              return row.codestatuspa == "A" ? "ACTIVE" : row.codestatuspa == "U" ? "USED" : row.codestatuspa == "R" ? "REJECTED" : row.codestatuspa == "E" ? "EXPIRED" : "";
            },  
            tax1amt (h, row) {   
              return <div>${Number.parseFloat(row.tax1amt).toFixed(2)}</div> ; 
            },        
            tax2amt (h, row) {   
              return <div>${Number.parseFloat(row.tax2amt).toFixed(2)}</div> ; 
            },
            voidind(h,row){
              if(row.voidind == "Y")
              return <span  class="bd-highlight">VOIDED</span>
              else
              return  <span></span>
             
            }                   
          },
          headings: {
            ovdstatusid:'Manual Approval',
            edit: '',
            delete:'',
            status: 'Status'  , 
            codestatuspa: 'Status',
            errorcode: 'Msg',         
            priorapprovalno: 'Prior Approval #',
            dateexpiry: 'Expiry Date',
            servicecode: 'Service Code',
            servicedate: 'Service Date',
            servicecodedescription:  'Description',
            qty: 'QTY',
            amtchargeacq: ((this.AppServiceID == 3) ? 'Service' : 'Submitted') + ' Amount', //GT: 20201120 from Submitted Fee
            thirdpartypaidamt:   '1st Payer Paid Amount',
            amtpaiddpebb: 'Assessed Amount', //GT: 20201120 from Assessed Fee
            tax1type: 'Tax 1',
            tax1amt: 'Tax 1 Amount',
            tax2type: 'Tax 2',
            tax2amt: 'Tax 2 Amount',            
            comments: 'Comments',
            paymentcode: 'Payment Code',
            // codecoverage: 'Code Coverage',
            plan: 'Plan',
            coderun: 'Run Code',
            codepaymenttype: 'Payment Code',
            codecoveragedp: 'Code Coverage',
            codecoverageterm : 'Code Term',
            voidind: 'Void Status'
          },
          pagination: {
            edge: true,
            nav: 'scroll',
            chunk: 5
          },
           sortable: ['servicecodedescription', 'qty' , 'amtchargeacq', 'status'],
          sortIcon: {
                  base : 'fas',
                  is: 'fa-sort',
                  up: 'fa-sort-up',
                  down: 'fa-sort-down'
                  },
          },
          
           docOptions: {
          texts:{
              count:"{from} to {to} of {count} documents|{count} documents|One document",
              first:'First',
              last:'Last',
              limit:"Records:",
              page:"Page:",
              noResults:"No Claim Documents Found",
              loading:'Loading...',
              defaultOption:'Select {column}',
              columns:'Columns'
          },
          responseAdapter({data}) 
          {          
              return {
              data: formatData,
              count: data.length
              }
          },
          perPage:5,
          perPageValues:[5],
          dateColumns:['createddate'],
          templates: {
           
          },
          headings: {
            docname: 'Document', 
            doctypeicon: 'Type',
            createddate: 'Added',         
          },
          pagination: {
            edge: true,
            nav: 'scroll',
            chunk: 5
          },
          sortable: ['DocName', 'DocType', 'CreatedDate'],
          sortIcon: {
                  base : 'fas',
                  is: 'fa-sort',
                  up: 'fa-sort-up',
                  down: 'fa-sort-down'
          },
          filterable: false,
          // eslint-disable-next-line no-dupe-keys
          templates: {    
            createddate(h, row) {         
              return moment(row.createddate,"YYYY-MM-DD").format('YYYY/MM/DD');  
            }, 
            doctypeicon(h, row) {
              if (row.doctype.includes("pdf"))
              {
                return <span style="color:black" v-b-tooltip title="PDF"><i class="fa fa-file-pdf-o"></i></span>
              }
              else if (row.doctype.includes("word"))
              {
                return <span style="color:black" v-b-tooltip title="Document"><i class="fa fa-file-word-o"></i></span>                
              }
              else if (row.doctype.includes("text"))
              {
                return <span style="color:black" v-b-tooltip title="Text"><i class="fa fa-file-text-o"></i></span>                
              }
              else if (row.doctype.includes("image"))
              {
                return <span style="color:black" v-b-tooltip title="Image"><i class="fa fa-file-photo-o"></i></span>                
              }
              else
              {
                return <span style="color:black" v-b-tooltip title='Other'><i class="fa fa-file-o" ></i></span>
              }
            }
          }
        },

        }
    },
    filters: {
      moment: function (date) {
        
      return moment(date,"YYYY-MM-DD").format('YYYY/MM/DD');
      },
      stringify(value) {
      return JSON.stringify(value, null, 2)
      }  
    }, 
    watch:{ 
      BtnSubmitdisabled:function(val){
        this.BtnSubmitdisabled=val;
      }, 
    },
    components: { 
            Card,
            CardBody,
            TileNote ,
 //           PAAddEdit,
            VueUploadMultipleImage,
 //           PAShowHSNInfo,
 //           PAShowCoverageInfo,
            Datepicker,
            Subtitle
        },
    methods: {
      Exit: function (event) {
        this.$root.$emit('bv::hide::modal', 'phModal', '#btnShow'); 
      }, 
      GeneratePDF: function (event) 
      {
        var vm = this;
        
        //console.log('GeneratePDF')
        // generated from https://ezgif.com/image-to-datauri
        const skLogo = vm.SKLogoConst.Logo64Bit;        
        
        const pdf = new jsPDF('l', 'mm', 'letter');
        const pageHeight = pdf.internal.pageSize.height;
        const pageWidth = pdf.internal.pageSize.width;
        const fontType = 'helvetica';

        function appendLeadingZeroes(n)
        {
          if(n <= 9)
          {
            return "0" + n;
          }
          return n
        }
      
        // Add Header and Footer to every page in report
        const addHeaderFooter = pdf => 
        {
          // get total number of pates
          const pageCount = pdf.internal.getNumberOfPages()

          // cycle through every page to add header/footer
          for (var i = 1; i <= pageCount; i++) 
          {
            pdf.setPage(i)

            var currDate = new Date();
            var rptDate = currDate.getFullYear() + "-" 
                             + appendLeadingZeroes(currDate.getMonth() + 1) + "-" 
                             + appendLeadingZeroes(currDate.getDate()) + " " 
                             + appendLeadingZeroes(currDate.getHours()) + ":" 
                             + appendLeadingZeroes(currDate.getMinutes()) + ":" 
                             + appendLeadingZeroes(currDate.getSeconds());
                  
            pdf.setFont(fontType);

            // Header Image                    
            pdf.addImage(skLogo,'png', 5, 5);//, 45, 18); //15,10,30,10); //5,5,30,10);
          
            // Header Title
            var rptTitle = vm.AppName;         
            var rptSubTitle = 'Claim';
            if (vm.hDetails.claimType == 'PA') rptSubTitle = 'Prior Approval';
            rptTitle = rptTitle + ' - Patient ' + rptSubTitle + ' History';

          
            pdf.setFontSize(14);
            pdf.text(rptTitle, (pageWidth / 2), 10, 'center', 'center');    


            // Footer
            pdf.setFontSize(9);
            pdf.line(5, pageHeight - 10, pageWidth - 5, pageHeight - 10);
            pdf.text("Run Date: " + rptDate, 5, pageHeight - 5);

            pdf.setFontSize(8);    
            var copyRight = 'Copyright or Small Confidential Info????';            
            pdf.text(copyRight, pageWidth / 2 - copyRight.length / 2, pageHeight - 5);

            pdf.setFontSize(9);
            pdf.text("Page: " + String(i) + ' of ' + String(pageCount), pageWidth - 5, pageHeight - 5, {align: 'right'});
          }
        }
        
        // ------------------------
        // Patient Information
        // ------------------------
        var patsupprovList =  [ { label1: '', value1: ''
                                , label2: '', value2: ''
                                , label3: '', value3: ''
                                }                                  
                                , { label1: 'Patient:'     
                                  , value1: this.selectedPatient.firstName + ' ' + this.selectedPatient.lastName
                                  , label2: 'Clinic:'    
                                  , value2: this.selectedClinic.clinicname
                                  , label3: 'Provider:'    
                                  , value3: this.selectedProvider.providername 
                                  }
                                , { label1: 'HSN:'         
                                  , value1: this.selectedPatient.hsn
                                  , label2: 'Clinic #:' 
                                  , value2: this.selectedClinic.clinicno
                                  , label3: 'Provider #:'  
                                  , value3: this.selectedProvider.orgid + this.selectedProvider.providerno 
                                  }
                                , { label1: 'Address:'     
                                  , value1: this.selectedPatient.address1 + ' ' + this.selectedPatient.address2
                                  , label2: 'Address:'     
                                  , value2: this.selectedClinic.address
                                  , label3: 'Service:'     
                                  , value3: this.selectedProvider.service 
                                  }
                                , { label1: 'DOB:'         
                                  , value1: moment(this.selectedPatient.birthDay).format('YYYY/MM/DD')
                                  , label2: 'City:'        
                                  , value2: this.selectedClinic.city
                                  , label3: 'Service Type:'
                                  , value3: this.selectedProvider.subtype 
                                  }                                
                                 ];
                                 
        var patsupprovHead = [//[],
                              [ {"content":"Patient Information","colSpan":2,"styles":{"cellWidth":"even"}}
                              , {"content":"Clinic Information","colSpan":2,"styles":{"cellWidth":"even"}}
                              , {"content":"Provider Information","colSpan":2,"styles":{"cellWidth":"even"}}
                             ]];

        // ------------------------
        // Patient Information
        // ------------------------
        pdf.autoTable
        (
          {
            theme: 'plain', 
            //startY: pdf.lastAutoTable.finalY + 3,   
            headStyles: 
            {
              font: fontType,
              fontSize: 12,
              fontStyle: 'bold',
            }, 
            styles: 
            {
              font: fontType,
              fontSize: 9,
              cellPadding: 0, 
            }, 
            columnStyles: 
            {
              0: {cellWidth: 15}, 
              2: {cellWidth: 16},
              4: {cellWidth: 22}
            }, 
            body: patsupprovList, 
            head: patsupprovHead,
            columns: 
            [ {dataKey: 'label1'}
            , {dataKey: 'value1'}
            , {dataKey: 'label2'}
            , {dataKey: 'value2'}
            , {dataKey: 'label3'}
            , {dataKey: 'value3'}
            ],                                                     
            margin: 
            {
              top: 20,
              left: 5,
              right: 5,
              bottom: 20
            },  
            didParseCell: function (data) 
            {
              if (data.section === 'head')
              {
                if (data.row.index == 0) data.cell.styles.fillColor = [236,236,236];     // light grey  
                data.cell.styles.fontStyle = 'bold';                  
                data.cell.styles.cellPadding = 0;
              };

              // Bold for Legend column
              if (data.column.index === 0 || data.column.index === 2 || data.column.index === 4 ) 
              {
              data.cell.styles.fontStyle = 'bold';
              }
            },
//            didDrawPage: pageHeaderFooter 
          }
        );

        // ------------------------
        // Service Code Information
        // ------------------------
        {
          // set legend headers to show if true for ViewNotesCoverage or for Claim Status         
          var headerInit = [ //{code: 'scvoidaction', header: 'Void Action', show: true, assessor: false, legend: false, legendHeader:'', align:'left'}
                            //, 
                              {code: 'scstatus', header: 'Status', show: true, assessor: false, legend: false, legendHeader:'', align:'left'}
                            , {code: 'scvoidind', header: 'Void Status', show: true, assessor: false, legend: false, legendHeader:'', align:'left'}
                            , {code: 'scerrorcode', header: 'Msg', show: true, assessor: false, legend: false, legendHeader:'', align:'left'}                             
                            , {code: 'scpriorapproval', header: 'Prior Approval #', show: true, assessor: false, legend: false, legendHeader:'', align:'left'}                             
                            , {code: 'scexpdate', header: 'Expiry Date', show: false, assessor: false, legend: false, legendHeader:'', align:'left'}                             
                            , {code: 'scdescription', header: 'Description', show: true, assessor: false, legend: false, legendHeader:'', align:'left'}
                            , {code: 'scservicecode', header: 'Service Code', show: true, assessor: false, legend: false, legendHeader:'', align:'left'}
                            , {code: 'scqty', header: 'Qty', show: true, assessor: false, legend: false, legendHeader:'', align:'left'}                             
                            , {code: 'scpaidamt', header: 'AA ($)', show: true, assessor: false, legend: true, legendHeader:'(AA) Assessed Amount', align:'right'}
                            , {code: 'scservicefee', header: 'SA ($)', show: true, assessor: false, legend: true, legendHeader:'(SA) ' + ((vm.AppServiceID == 3) ? 'Service' : 'Submitted') + ' Amount', align:'right'}
                            , {code: 'scacqcost', header: 'UC ($)', show: false, assessor: false, legend: false, legendHeader:'(UC) Unit Cost', align:'right'}
                            , {code: 'scmarkup', header: 'MU %', show: false, assessor: false, legend: false, legendHeader:'(MU) Markup', align:'right'}
                            , {code: 'scshippingcostsub', header: 'SC ($)', show: false, assessor: false, legend: false, legendHeader:'(SC) Shipping Cost', align:'right'}
                            , {code: 'scshippingcostpaid', header: 'SP ($)', show: false, assessor: false, legend: false, legendHeader:'(SP) Shipping Paid', align:'right'}
                            , {code: 'scthirdpartyamt', header: '1PPA ($)', show: true, assessor: false, legend: true, legendHeader:'(1PPA) 1st Payer Paid Amount', align:'right'}
                            , {code: 'sctax1', header: 'Tax 1', show: true, assessor: false, legend: false, legendHeader:'', align:'left'}
                            , {code: 'sctax1amt', header: 'T1A ($)', show: true, assessor: false, legend: true, legendHeader:'(T1A) Tax 1 Amount', align:'left'}
                            , {code: 'sctax2', header: 'Tax 2', show: true, assessor: false, legend: false, legendHeader:'', align:'left'}
                            , {code: 'sctax2amt', header: 'T2A ($)', show: true, assessor: false, legend: true, legendHeader:'(T2A) Tax 2 Amount', align:'left'}
                            , {code: 'sctooth1', header: 'Tooth 1', show: false, assessor: false, legend: false, legendHeader:'', align:'left'}
                            , {code: 'sctooth2', header: 'Tooth 2', show: false, assessor: false, legend: false, legendHeader:'', align:'left'}
                            , {code: 'sccomments', header: 'Comments', show: false, assessor: false, legend: false, legendHeader:'', align:'left'}
                            , {code: 'scruncode', header: 'RC', show: false, assessor: false, legend: true, legendHeader:'(RC) Run Code', align:'left'}
                            , {code: 'scpaymentcode', header: 'PC', show: false, assessor: true, legend: true, legendHeader:'(PC) Payment Code', align:'left'}
                            , {code: 'sccovcode', header: 'CC', show: false, assessor: true, legend: true, legendHeader:'(CC) Coverage Code', align:'left'}
                            , {code: 'scplan', header: 'Plan', show: false, assessor: true, legend: false, legendHeader:'', align:'left'}
                            , {code: 'sccodeterm', header: 'CT', show: false, assessor: true, legend: true, legendHeader:'(CT) Code Term', align:'left'}
                            ];

          // need to set rules for headers
          // If Prior Approval then show Expiry Date and hide Tax 1/2 Type and Amounts
          if (this.hDetails.claimType == 'PA') 
          {
            headerInit.find(tbl => tbl.code == 'scexpdate').show = true;
            headerInit.find(tbl => tbl.code == 'sctax1').show = false;
            headerInit.find(tbl => tbl.code == 'sctax1amt').show = false;
            headerInit.find(tbl => tbl.code == 'sctax2').show = false;
            headerInit.find(tbl => tbl.code == 'sctax2amt').show = false;
          }

          // If isAssessor and Claim then show Run Code, Pmt Code, Code Coverage, Code Term
          if (this.isAssessor && this.hDetails.claimType == 'CL') 
          {
            headerInit.find(tbl => tbl.code == 'scruncode').show = true;
            headerInit.find(tbl => tbl.code == 'scpaymentcode').show = true;
            headerInit.find(tbl => tbl.code == 'sccovcode').show = true;
            headerInit.find(tbl => tbl.code == 'sccodeterm').show = true;
          }
    
          // Filter only Headers to show
          var headerList = headerInit.filter(hdr => hdr.show);
          var serviceColumnList = [];
          var serviceColumnHeaderList = [];
          for (var hdrIdx = 0; hdrIdx < headerList.length; hdrIdx++)   
          {  
              var serviceColumnObj = {};
              var serviceColumnHeaderObj = {};
              serviceColumnObj["title"] = headerList[hdrIdx].header;
              serviceColumnObj["dataKey"] = headerList[hdrIdx].code; 
              serviceColumnHeaderObj["id"] = headerList[hdrIdx].code;  
              serviceColumnHeaderObj["content"] = headerList[hdrIdx].header;  
              serviceColumnHeaderObj["styles"] = {"halign":headerList[hdrIdx].align};
              serviceColumnList.push(serviceColumnObj);
              serviceColumnHeaderList.push(serviceColumnHeaderObj);
          }

          // create data row for Service Codes to show
          // need to set rules for data row and also for the header (data rules below)
          var serviceBodyList = [];
          var serviceDataList = [];
          for (var srcIdx = 0; srcIdx < vm.SourceCodeData.length; srcIdx++)                                                     
          {
            var dataRowList = [];
            var show = false;
            var labelVal = '';
            var valueVal = '';
            var showVal = '';

            for (var hdrIdx = 0; hdrIdx < headerList.length; hdrIdx++)   
            {
              labelVal  = headerList[hdrIdx].code;
              showVal = headerList[hdrIdx].show;
              valueVal = '';     

              var validID = headerList[hdrIdx].validID;
              var assessorVal = headerList[hdrIdx].assessor;

//              if ((assessorVal && this.ViewNotesCoverage) || !assessorVal)
              {
                switch(labelVal)
                {
                  //Previous Status
                  case 'scstatus':
                    if (this.hDetails.claimType == 'CL')
                    {
                      valueVal = vm.SourceCodeData[srcIdx].status;
                    }
                    else
                    {
                      var codestatuspatmp = vm.SourceCodeData[srcIdx].codestatuspa;
                      valueVal = codestatuspatmp == "A" ? "ACTIVE" : codestatuspatmp == "U" ? "USED" : codestatuspatmp == "R" ? "REJECTED" : codestatuspatmp == "E" ? "EXPIRED" : "";
                    }
                    break;

                  case 'scvoidind':
                    valueVal = ( vm.SourceCodeData[srcIdx].voidind == 'Y' ) ? 'VOIDED' : '';
                    break;

                  // Message
                  case 'scerrorcode':
                    valueVal = vm.SourceCodeData[srcIdx].errorcode;
                    break;

                  // Prior Approval
                  case 'scpriorapproval':
                    valueVal = '';            
                    var pa = vm.SourceCodeData[srcIdx].priorapprovalno; 
                    var idx = 0;
                    if (pa != null && pa != '') 
                    {
                      pa = pa.trim();
                      idx = pa.length/2;
                      var splitChar = (pa.length >0 ? '\n': '');
                      valueVal = pa.substring(0,idx) + splitChar + pa.substring(idx);
                    }
                    break;

                  // Expiry Date              
                  case 'scexpdate':
                    var expDateVal = vm.SourceCodeData[srcIdx].dateexpiry
                    valueVal =  ( expDateVal != null && expDateVal != '' ) ? moment(expDateVal).format('YYYY/MM/DD') : ''
                    break;

                  // Description
                  case 'scdescription':
                    valueVal = vm.SourceCodeData[srcIdx].servicecodedescription;
                    break;

                  // Service Code
                  case 'scservicecode':
                    valueVal = vm.SourceCodeData[srcIdx].servicecode;
                    break;

                  // Quantity
                  case 'scqty':
                    valueVal = vm.SourceCodeData[srcIdx].qty;
                    break;

                  // Assessed Amount
                  case 'scpaidamt':
                    valueVal = vm.SourceCodeData[srcIdx].amtpaiddpebb.toFixed(2).replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
                    break;

                  // Service Amount/Submitted Amount
                  case 'scservicefee':
                    valueVal = vm.SourceCodeData[srcIdx].amtchargeacq.toFixed(2).replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
                    break;

                  // Acq Unit Cost
                  case 'scacqcost':
                    valueVal = vm.SourceCodeData[srcIdx].acqcost.toFixed(2).replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
                    break;

                  // Markup %
                  case 'scmarkup':
                    valueVal = vm.SourceCodeData[srcIdx].markup.toFixed(3); 
                    //valueVal = vm.SourceCodeData[srcIdx].markup.toFixed(1);
                    break;

                  // Shipping Cost
                  case 'scshippingcostsub':
                    valueVal = vm.SourceCodeData[srcIdx].shippingcostsub.toFixed(2).replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
                    break;

                  // Shipping Paid
                  case 'scshippingcostpaid':
                    valueVal = vm.SourceCodeData[srcIdx].shippingcostpaid.toFixed(2).replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
                    break;

                  // 1PPA
                  case 'scthirdpartyamt':
                    valueVal = vm.SourceCodeData[srcIdx].thirdpartypaidamt.toFixed(2).replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
                    break;

                  // Tax 1
                  case 'sctax1':
                    valueVal = vm.SourceCodeData[srcIdx].tax1type;
                    break;            

                  // Tax 1 Amount
                  case 'sctax1amt':
                    valueVal = vm.SourceCodeData[srcIdx].tax1amt.toFixed(2).replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
                    break;            

                  // Tax 2
                  case 'sctax2':
                    valueVal = vm.SourceCodeData[srcIdx].tax2type;
                    break;            

                  // Tax 2
                  case 'sctax2amt':
                    valueVal = vm.SourceCodeData[srcIdx].tax2amt.toFixed(2).replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
                    break;            

                  // Tooth 1
                  case 'sctooth1':
                    valueVal = vm.SourceCodeData[srcIdx].tooth1;
                    break;

                  // Tooth 2
                  case 'sctooth2':
                    valueVal = vm.SourceCodeData[srcIdx].tooth2;
                    break;

                  // Comments
                  case 'sccomments':
                    valueVal = vm.SourceCodeData[srcIdx].comments.substring(0,39);
                    break;

                  // Run Code
                  case 'scruncode':
                    valueVal = vm.SourceCodeData[srcIdx].coderun;
                    break;

                  // Payment Code
                  case 'scpaymentcode':
                    valueVal = vm.SourceCodeData[srcIdx].codepaymenttype;
                    break;

                  // Coverage Code
                  case 'sccovcode':
                    valueVal = vm.SourceCodeData[srcIdx].codecoveragedp;
                    break;

                  // Plan
                  case 'scplan':
                    valueVal = vm.SourceCodeData[srcIdx].plan;
                    break;

                  // Code Term
                  case 'sccodeterm':
                    valueVal = vm.SourceCodeData[srcIdx].codecoverageterm;
                    break;

                  default:
                }
                dataRowList.push({ label: labelVal, value: valueVal, show: showVal });               
              }
            }

            var serviceBodyObj = {};
            var serviceDataObj = {};

            // filter only Columns to show
            var svcList = dataRowList.filter(svcCol => svcCol.show);             
            // create data elements for Service Codes information
            for (var j = 0; j < svcList.length; j++)   
            {
              serviceBodyObj[svcList[j].label] = svcList[j].value;
            }  

            serviceBodyList.push(serviceBodyObj);  
          }
        
          var serviceHeadList = [//[{id: "rowHdr0", "content":"","colSpan":22} ],
                                [ {id: "rowHdr1", "content":"Service Code Information","colSpan":serviceColumnHeaderList.length} ],
                                [ {id: "rowHdr2", "content":"","colSpan":serviceColumnHeaderList.length,"styles":{"cellPadding":0, "height":0.25}} ],
                                serviceColumnHeaderList
                                ];  

          var noServiceCodesFoundList = [];
          if (vm.SourceCodeData.length == 0)
          {
             serviceHeadList.push([{id: "rowHdr3", "content":"<< No Service Code Found >>","colSpan":serviceColumnHeaderList.length, "styles":{"cellPadding":0, "halign":"center", "fontStyle":"normal"}}]);
          }

          //************************
          // Service Code Lines Table       
          //************************
          pdf.autoTable
          (
            {
              theme: 'plain', 
              startY: pdf.lastAutoTable.finalY + 7,   
              headStyles: 
              {
                font: fontType,
                fontSize: 12,
                fontStyle: 'bold',
                cellPadding: 0.5,
              }, 
              styles: 
              {
                font: fontType,
                fontSize: 9,
                cellPadding: 0.5, 
//                lineWidth: .5,
              }, 
              body: serviceBodyList, 
              head: serviceHeadList,
              columns: serviceColumnList,                                                     
              margin: 
              {
                top: 20,
                left: 5,
                right: 5,
                bottom: 20
              },  
              didParseCell: function (data) 
              {
//                data.cell.styles.cellWidth = 'auto';
                if (data.section === 'head')                                     // header
                {
                  if (data.row.index == 0)                                  // Service Code information row in header
                  {
                    data.cell.styles.fillColor = [236,236,236];     // light grey       
                    data.cell.styles.cellPadding = 0;                               
                  }
                  else                                                           // column headers row in header
                  {
                    data.cell.styles.fontSize = 9;
//                    data.cell.styles.cellPadding = 0.5;
                  }
                }
                else                                                             // body
                {
                  data.cell.styles.halign = serviceColumnHeaderList[data.column.index].styles.halign;
//                  data.cell.styles.cellPadding = 0.5;             
                }
              },
//              didDrawPage: pageHeaderFooter 
            }
          );

          //************************
          // Legend Information
          //************************
          {
            // initialize data matrix
            var legendList =[ 
                              { datakey1: 'Legend'
                              , datakey2: '          '
                              , datakey3: '          '
                              , datakey4: '          '
                              , datakey5: '          '
                              , datakey6: '          '
                              , datakey7: '          '
                              }
                            ];
            // filter only legend records to show
            var legendInit = headerInit.filter(hdrList => hdrList.legend);
                        
            // only show values with show = true and sort by code
            var showLegendList = _.sortBy( legendInit.filter(legend => legend.show), 'legendHeader' );

            // create second row if more than 6 values in list
            if (showLegendList.length > 6) 
            {
              var legendListb = { datakey1: '          '
                                , datakey2: '          '
                                , datakey3: '          '
                                , datakey4: '          '
                                , datakey5: '          '
                                , datakey6: '          '
                                , datakey7: '          '
                                };
              legendList.push(legendListb);
            }

            // update values in data matrix
            var cntLoop = 0;
            var cntRow = 0;
            var leg = [];

            for (var i = 0; i < showLegendList.length; i++) 
            {  
              cntRow++;
              var arrval = showLegendList[i].legendHeader;
              legendList[cntLoop]["datakey" + (cntRow+1)] = arrval;

              // add new line if need to since stores datakey 1-7                
              if (cntRow == 6) 
              {
                cntLoop++;
                cntRow = 0;
              }
            }

            //************************
            // Legend table        
            //************************
            pdf.autoTable
            (
              {
                theme: 'plain', 
                startY: pdf.lastAutoTable.finalY + 3,   
                headStyles: 
                {
                  font: fontType,
                  fontSize: 8,
                  fontType: 'bold',
                  cellPadding: 0                  
                }, 
                styles: 
                {
                  font: fontType,
                  fontSize: 8,
                  cellPadding: 0
                }, 
                body: legendList,
                head: [[]],
                columns: 
                [
                  { dataKey: 'datakey1' },
                  { dataKey: 'datakey2' },
                  { dataKey: 'datakey3' },
                  { dataKey: 'datakey4' },
                  { dataKey: 'datakey5' },
                  { dataKey: 'datakey6' },
                  { dataKey: 'datakey7' },              
                ], 
                columnStyles: 
                {
                  0: { cellWidth: 14}
                },   
                margin: 
                {
                  top: 20,
                  left: 5,
                  right: 5,
                  bottom: 20
                }, 
                didParseCell: function (data) 
                {
                  // Bold for Legend column
                  if (data.column.index === 0) data.cell.styles.fontStyle = 'bold';
                } 
              }
            );            
          
          } // End Legend

          //************************
          // Message Codes
          //************************    
          if (vm.ErrorAndDesc != null && vm.ErrorAndDesc != '' && vm.ErrorAndDesc.length != 0 && vm.SourceCodeData.length != 0)
          {
            pdf.autoTable
            (
              {
                theme: 'plain', 
                startY: pdf.lastAutoTable.finalY + 3,   
                headStyles: 
                {
                  font: fontType,
                  fontSize: 8,
                  fontType: 'bold',
                  cellPadding: 0                  
                }, 
                styles: 
                {
                  font: fontType,
                  fontSize: 8,
                  cellPadding: 0, 
                }, 
                body: vm.ErrorAndDesc,
                head: [[],['Message', 'Description']],
                columns: 
                [
                  { dataKey: 'item1' },  //errorCode
                  { dataKey: 'item2' },  //errMsg
                ],
                columnStyles: 
                {
                  0: { cellWidth: 14}
                },   
                margin: 
                {
                  top: 20,
                  left: 5,
                  right: 5,
                  bottom: 20
                },  
              }
            );
          } // End Message Codes
        } // End Service Codes

        // ------------------------
        // Claim/Prior Approval Information
        // ------------------------
        function isEmpty(obj) 
        {
          for(var key in obj) 
          {
            if(obj.hasOwnProperty(key))
                return false;
          }
          return true;
        }

        var emptyRowObj = { label1: ''
                          , value1: '' 
                          };
        var payeeObj = {};
        if (this.isAssessor && this.hDetails.claimType == 'CL' && this.ReimburseToPatient == 'Y') 
        {
          payeeObj = { label1: 'Payee Name:'    
                     , value1: this.hDetails.payeeName
                     , label2: 'Address:'
                     , value2: {"content":this.hDetails.payeeAddress1.trim() + ', ' + this.hDetails.payeeAddress2.trim() + ', ' + this.hDetails.payeePostal.trim() + ', ' + this.hDetails.payeeProv.trim(),"colSpan":3}
                     };
        }

        var overrideObj = {};
        if (this.isAssessor)
          overrideObj = { label1: {"content":"Manual Approval Notes:","colSpan":1}
                        , value1: {"content":this.hDetails.overideNote,"colSpan":5}
                        };   

        var createModByObj = {};
          createModByObj = { label1: 'Created By:'
                           , value1: this.hDetails.addLogonID 
                           , label2: 'Modified By:'
                           , value2: this.hDetails.modifyLogonID 
                           };
        
        var createModDateObj = {}; 
          createModDateObj = { label1: 'Created Date/Time:'
                           , value1: moment(this.hDetails.addDate).format('YYYY/MM/DD') + ' ' + this.hDetails.addTime
                           , label2: 'Modified Date/Time:'
                           , value2: moment(this.hDetails.modifyDate).format('YYYY/MM/DD') + ' ' + this.hDetails.modifyTime
                           }         

        var claimList = [ { label1: '', value1: '' }
                        , { label1: {"content":"Notes:","colSpan":1}
                          , value1: {"content":this.hDetails.claimNotes,"colSpan":5}  
                            }
                        , { label1: ''
                          , value1: '' 
                          }
                        , createModByObj
                        , createModDateObj
                        , { label1: 'Service Date:'    
                          , value1: moment(this.ServiceDate).format('YYYY/MM/DD')
                          , label2: 'Lab Name:'
                          , value2: this.LabName
                          , label3: '1st Payer Paid Amount:'
                          , value3: this.hDetails.paidbythirdparty 
                          }
                        , { label1: 'Temporary Health Certificate (THC):'
                          , value1: this.hDetails.thcIndicator
                          , label2: 'THC Effective Date:'
                          , value2: ( this.hDetails.thcIndicator == 'Y' ) ? moment(this.THCEffectDate).format('YYYY/MM/DD') : ''
                          , label3: 'THC Expiry Date:'
                          , value3: ( this.hDetails.thcIndicator == 'Y' ) ? moment(this.THCExpiryDate).format('YYYY/MM/DD') : ''   
                          }
                        , { label1: 'X-Rays and Documents:'    
                          , value1: this.hDetails.claimattachment
                          , label2: ( this.hDetails.claimType == 'CL' ) ? 'Reimburse to Patient:' : ''
                          , value2: ( this.hDetails.claimType == 'CL' ) ? this.ReimburseToPatient : ''
                          }
                        ];

        if (!this.isAssessor)
          claimList.splice(3,2); // remove Created By/Date if not Assessor

        if (!isEmpty(payeeObj)) 
        {
          claimList.push(payeeObj);
        }

        if (!isEmpty(overrideObj)) 
        {
          claimList.push(emptyRowObj);               
          claimList.push(overrideObj);         
        }

//        claimList.push(emptyRowObj); 
//        claimList.push(claimstatusObj);            

        var claimPA = ( this.hDetails.claimType == 'CL' ) ? 'Claim Information' : 'Prior Approval Information';
        var claimHead = [
             //[],
             [ {"content":claimPA,"colSpan":6,"styles":{"cellWidth":"even"}} ]];

        
        pdf.autoTable
        (
          {
            theme: 'plain', 
            startY: pdf.lastAutoTable.finalY + 7,   
            headStyles: 
            {
              font: fontType,
              fontSize: 12
            },            
            styles: 
            {
              font: fontType,
              fontSize: 9,
              cellPadding: 0, 
              cellWidth: 'wrap'
            }, 
            columnStyles: 
            {
              0: {cellWidth: 55}, 
              1: {cellWidth: 'auto'}, 
              2: {cellWidth: 34}, 
              3: {cellWidth: 50}, 
              4: {cellWidth: 37},
              5: {cellWidth: 'auto'}
            }, 
            body: claimList, 
            head: claimHead,
            columns: 
            [ {dataKey: 'label1'}
            , {dataKey: 'value1'}
            , {dataKey: 'label2'}
            , {dataKey: 'value2'}
            , {dataKey: 'label3'}
            , {dataKey: 'value3'}
            ],
                                                  
            margin: 
            {
              top: 20,
              left: 5,
              right: 5,
              bottom: 20
            },  
            didParseCell: function (data) 
            {
              if (data.section === 'head' && data.row.index == 0)
              {data.cell.styles.fontStyle = 'bold';
                data.cell.styles.fillColor = [236,236,236];     // light grey  
                data.cell.styles.cellPadding = 0;
                if (data.column.index === 0) data.cell.colspan = 2;
                if (data.column.index === 1) data.cell.colspan = 0;
              };

              // Bold for Legend column
              if (data.column.index === 0 || data.column.index === 2 || data.column.index === 4 ) data.cell.styles.fontStyle = 'bold';
            },
          }
        );

        // draw the header/footers on each page
        addHeaderFooter(pdf);

        // save the pdf file
        pdf.save('patientHistoryDetail.pdf');

      },

      LoadClaimDocs(claimRequestNumber) {
        var vm = this;
        var params = new URLSearchParams();
//        params.append("claimRequestNo", claimRequestNo);
        params.append("claimRequestNo", this.claimRequestNumber);        
        axios.get('SaskHealthApi/Claims/GetClaimDocumentsByClaimRequestNo', {
        headers: {
          'Authorization': 'Bearer ' + localStorage.access_token}, params})
        .then(function (response) {
          vm.docList = response.data;
         })
       .catch(function (er) {
            vm.docList = [];
            console.log(er)
            this.$bvModal.msgBoxOk(er);
         })
      }, 
      OpenClaimDoc(row) {
        var dl = document.createElement('a');
        dl.target = '_blank';
        dl.download = row.docname;
        //The atob function will decode a base64-encoded string into a new string with a character for each byte of the binary data.
        const byteChar = atob(row.doc);
        //Each character's code point (charCode) will be the value of the byte. 
        //We can create an array of byte values by applying this using the .charCodeAt method for each 
        //character in the string.
        const byteNumbers = new Array(byteChar.length);
        for (let i = 0; i < byteChar.length; i++) {
            byteNumbers[i] = byteChar.charCodeAt(i);
        }
        //You can convert this array of byte values into a real typed byte array by passing it to the Uint8Array constructor.
        const byteArray = new Uint8Array(byteNumbers);
        //This in turn can be converted to a Blob by wrapping it in an array and passing it to the Blob constructor.
        var blob = new Blob([byteArray], {type: row.doctype});
        //create the URL for the blob, then open it
        var URL = window.URL || window.webkitURL;
        if (window.navigator && window.navigator.msSaveOrOpenBlob) {
            window.navigator.msSaveOrOpenBlob(blob);  
        }
        else {
            var dlURL = URL.createObjectURL(blob);
            window.open(dlURL);
        }
      }, 
      getMsgClass(value) 
        {
          return ( value>= 3000 ) ? 'text-danger' : 'text-primary';
        },
      getErrorStyle(value) 
      {
        return ('width: 7.5rem !important;  padding:3px !important;')
      },
      GetMsg: function(ErrorCode) {
         var vm = this; 
          var params = new URLSearchParams(); 
          if(this.hDetails.claimType == 'CL')
            params.append('program', 'HCHXA020');
          else
            params.append('program', 'HCHXA010');
            params.append('code', ErrorCode);
            axios.get('SaskHealthApi/Codes/GetMessage', { headers: { 'Authorization': 'Bearer ' + localStorage.access_token },params})
            .then(function (response) {
                vm.showMsg(response.data,'','Service Code Message')
            }).catch(function (er) {
                console.log(er)
            }).then(function () {
                  
            }); 
      }, 
        Go(){
            this.$router.push('/DPEBB/MainHome')
        },
         Show(){
             this.Showinfo =true;
        }, 
        showMsgBox(msg,data) {
          this.boxTwo = ''
          this.$bvModal.msgBoxConfirm(msg, {
          title: 'Please Confirm',
          size: 'md',
          buttonSize: 'md',
          okVariant: 'danger',
          cancelVariant: 'default',
          okTitle: 'YES',
          cancelTitle: 'NO',
          footerClass: 'p-2',
          hideHeaderClose: true,
          centered: true, 
          })
            .then(value => {
              this.boxTwo = value
              if(value)
              {
                //console.log(data);
                  this.DeleteServiceCode(data);
                  //console.log(data)
              }
            })
            .catch(err => {
              // An error occurred
            })
      },
      showMsg(msg,data,Title) {
          this.boxTwo = ''
          this.$bvModal.msgBoxOk(msg, {
          title: Title,
          size: 'md',
          buttonSize: 'md',
          okVariant: 'danger',          
          okTitle: 'Close', 
          footerClass: 'p-2',
          hideHeaderClose: true,
          hideHeaderCancel: true,
          centered: true, 
        })
          .then(value => {
            this.boxTwo = value
            if(value)
            {
             
            }
          })
          .catch(err => {
            // An error occurred
          })
      },
    },
    computed:{
    },
    created: function() { 
              this.ErrorAndDesc = _.map(_.uniqBy(this.hDetails.serviceCode, 'errorcode'), function (item) {
            return {
                item1: item.errorcode,
                item2: item.errordesc
            };  
        });
        console.log('Error dec = ' + this.ErrorAndDesc);
        _.forEach(this.ErrorAndDesc, function(value) {
          console.log(value);
        });
        this.AppServiceID = this.Type;

        this.dateFormat = this.$store.getters.GetDateFormat; 
        this.ServiceDate=moment(new Date()).format('YYYY/MM/DD');
        this.ClaimRequestNo =  this.claimRequestNumber; 
        this.THCEffectDate = moment(this.hDetails.thcEffDate,"YYYY-MM-DD").format('YYYY/MM/DD');
        this.THCExpiryDate = moment(this.hDetails.thcExpDate,"YYYY-MM-DD").format('YYYY/MM/DD');
        this.ServiceDate = moment(this.hDetails.serviceCode[0].servicedate,"YYYY-MM-DD").format('YYYY/MM/DD');
        //moment(ServiceDate,"YYYY-MM-DD").format('YYYY/MM/DD')
        this.ReimburseToPatient = "N";
        //if (this.hDetails.payeeHSN > 0)
        if(this.hDetails.payeeName != null && this.hDetails.payeeName !="")
        {
            this.ReimburseToPatient = "Y";
        }
        this.GivenName = this.hDetails.payeeName;
        this.Address1 = this.hDetails.payeeAddress1;
        this.Address2 = this.hDetails.payeeAddress2;
        this.Province = this.hDetails.province;
        this.PostalCode = this.hDetails.payeePostal;
        this.LabName = this.hDetails.labName;
        this.PaidByThirdPArty = this.hDetails.paidbythirdparty;
        this.status = this.hDetails.serviceCode[0].status;
        var vm = this;
        vm.SourceCodeData = this.hDetails.serviceCode;
        
        if(this.hDetails.serviceCode[0].claimtype =="CL")
        {
          if (this.isAssessor)
          {
          this.columns = ['status','voidind','errorcode','priorapprovalno','servicecodedescription','servicecode','qty','amtchargeacq','thirdpartypaidamt','amtpaiddpebb', 'tax1type','tax1amt','tax2type','tax2amt','coderun','codepaymenttype','codecoveragedp','codecoverageterm'];
          }
          else{
          this.columns = ['status','voidind','errorcode','priorapprovalno','servicecodedescription','servicecode','qty','amtchargeacq','thirdpartypaidamt','amtpaiddpebb','tax1type','tax1amt','tax2type','tax2amt'];
          }

        } 
        else //Prior Approval GT - 20201120 - removed tax1, tax2 data
        {
          this.columns = ['codestatuspa','voidind','errorcode','priorapprovalno','dateexpiry','servicecodedescription','servicecode','qty','amtchargeacq','thirdpartypaidamt','amtpaiddpebb'];
        }        
        this.LoadClaimDocs(parseInt(this.ClaimRequestNo));
    
    },
    beforeCreate: function() {  
    },
     mounted: function () {
     this.$nextTick(function () { 
      })
    },
}
</script>
<style scopped> 
 .row.no-gutter [class*='col-']   {
   padding-right:1px; 
 }
 .list-group-item {
    position: relative;
    display: block;
    padding: 0px 15px;
    margin-bottom: -1px;
    border: 1px solid #ddd;
    background-color: blue;
    line-height: 1em
} 
.col-lg-1>div {background-color:#ddd;} 
#docimg { 
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50; 
  /* margin-top: 10px; */
}
#line {
  border-top:1px solid   rgba(7, 14, 109, 0.25);
 
} 
 .select-css {
    display: block;
    font-size: 14px;
    /* font-family: sans-serif; */
    font-weight: 600;
    color: #444;
    line-height: 1.3;
    padding: .6em 1.4em .5em .8em;
    width: 100%;
    max-width: 100%; 
    box-sizing: border-box;
    margin: 0;
    border: 1px solid #aaa;
    box-shadow: 0 1px 0 1px rgba(0,0,0,.04);
    border-radius: .5em;
    -moz-appearance: none;
    -webkit-appearance: none;
    /* appearance: none; */
    background-color: #fff;
    background-image: url('data:image/svg+xml;charset=US-ASCII,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22292.4%22%20height%3D%22292.4%22%3E%3Cpath%20fill%3D%22%23007CB2%22%20d%3D%22M287%2069.4a17.6%2017.6%200%200%200-13-5.4H18.4c-5%200-9.3%201.8-12.9%205.4A17.6%2017.6%200%200%200%200%2082.2c0%205%201.8%209.3%205.4%2012.9l128%20127.9c3.6%203.6%207.8%205.4%2012.8%205.4s9.2-1.8%2012.8-5.4L287%2095c3.5-3.5%205.4-7.8%205.4-12.8%200-5-1.9-9.2-5.5-12.8z%22%2F%3E%3C%2Fsvg%3E'),
    linear-gradient(to bottom, #ffffff 0%,#e5e5e5 100%);
    background-repeat: no-repeat, repeat;
    background-position: right .7em top 50%, 0 0;
    background-size: .65em auto, 100%;
}
.select-css::-ms-expand {
    display: none;
}
.select-css:hover {
    border-color: #888;
}
.select-css:focus {
    border-color: #aaa;
    box-shadow: 0 0 1px 3px rgba(59, 153, 252, .7);
    box-shadow: 0 0 0 3px -moz-mac-focusring;
    color: #222; 
    outline: none;
}
.select-css option {
    font-weight:normal;
}
#ServiceCodeGrid .VuePagination__count{
  visibility: hidden;
  height:0px;
}
#ServiceCodeGrid .pagination{
  height:0px
} 
.highlight {
    background-color: #fff2ac;
    background-image: linear-gradient(to right, #ffe359 0%, #fff2ac 100%);
}
.bd-highlight {
    /* background-color: rgba(86,61,124,0.15); */
    /* border: 1px solid rgba(86,61,124,0.15); */
    background-image: linear-gradient(to right, #ffe359 0%, #fff2ac 100%);
    /* background-image: linear-gradient(to right, #ac9732ad 0%, #cebc5985 100%); */
    /* text-decoration-line: underline; */
    font-weight: bold;
    padding: .4rem;
    margin: 0rem !important;
    
} 
.cov { 
    font-size: 1.3rem;
    font-weight: bolder;
    /* padding: .2rem; */
    margin: 0rem !important; 
}
</style>