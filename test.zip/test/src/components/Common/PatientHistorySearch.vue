<template>
<div id="PatientHistorySearch">
<Subtitle  v-bind:ServiceID="this.AppServiceID">
   <template v-slot:header>
    <i class="fas fa-history"></i><b>Patient History Search:</b>
  </template> 
</Subtitle>
<b-modal id="modal-sm"  size="md" title="Patient History Error" v-model="showError" no-close-on-esc no-close-on-backdrop hide-header-close>
<div slot="default">
    <div class='alert alert-warning' role='alert'> {{MsgPopup}} </div>
</div> 
<div slot="modal-footer" class="w-100">
    <p class="float-left" variant="primary"></p>
    <b-button variant="primary"  size="md"  class="float-right"  @click="ClosePopup"> Close </b-button>
</div>
</b-modal>
<b-modal modal-class="test-modal fade" id="phModal" v-model="showDetailModal"
      scrollable no-close-on-backdrop hide-header  hide-footer
      header-class="PopUpHeader" 
      :header-text-variant=PopUpVar.headerTextVariant
      :body-bg-variant=PopUpVar.bodyBgVariant
      :body-text-variant=PopUpVar.bodyTextVariant
      :footer-bg-variant=PopUpVar.footerBgVariant
      :footer-text-variant=PopUpVar.footerTextVariant> 
     <!-- <template slot="modal-header"  class="w-100" > 
      <div  style="margin: 0 auto;">
      </div> 
    </template> -->
    <PatientHistoryDetail v-if="showDetailModal" @finished="CloseDetailModal" :hDetails="phDetails" :isAssessor="isAssessor"
      :claimRequestNumber="claimRequestNumber" :selectedProvider="detailProvider" :selectedClinic="detailClinic" 
      :selectedPatient="patient" :hHSN="HSN" :hType="phType" :AppName="AppName"></PatientHistoryDetail>
 </b-modal> 
 <form class="card  p-0 mb-1" id="SearchForm">
  <div class="card-header d-flex align-items-center  pl-1" style="height: 1rem; text-align:left;">
        <h5><small class="text-muted"><b><i class="fas fa-search-plus"></i>Search: HSN required (all others optional)</b></small></h5>
  </div>
  <div class="form-row p-1">
    <div class="form-group col-sm-1">
      <label for="inputEmail4" class="label-small">HSN</label>
       <input id="hsntxt" @input="HSNtextChanged" v-model="HSN" maxlength="9" class="form-control form-control-xs">
    <div class="row" v-show="$v.HSN.$error">           
        <div class="col-sm-12">
            <small class="sml-red" v-if="!$v.HSN.required">HSN is required.</small>
        </div>
      </div>
      <div class="row" v-show="$v.HSN.$error">           
        <div class="col-sm-12">
           <small class="sml-red" v-if="!$v.HSN.minLength">Minimum 9 digit required.</small>
        </div>
      </div>
      <div class="row" v-show="$v.HSN.$error">           
        <div class="col-sm-12">
           <small class="sml-red" v-if="!$v.HSN.numeric">HSN must be a number.</small>
        </div>
      </div>

    </div>
    <div class="form-group col-sm-1">
      <label for="inputPassword4" class="label-small">From Date</label>
      <div>
          <datepicker class="servdatapick" typeable :open-date="new Date()" v-model="fromDate"
            :format="DateFormat" id="effDate" :bootstrap-styling="true" :input-class="datapickClass"
            name="fromDatepicker"></datepicker>
      </div> 
      <div  class="row" v-show="$v.fromDate.$error">
        <div class="col-sm-12"> 
            <small class="sml-red" v-if="!$v.fromDate.needValue">Valid from date is required.</small>
       </div>  
      </div>
    </div>
    <div class="form-group col-sm-1">
      <label for="inputPassword4" class="label-small">To Date:</label>
      <div>
            <datepicker class="servdatapick" typeable :open-date="new Date()" v-model="toDate" :format="DateFormat"
              id="toDate" :bootstrap-styling="true" :input-class="datapickClass" name="toDatepicker"></datepicker>
      </div>
      <div  class="row" v-show="$v.toDate.$error">
           <div class="col-sm-12"> 
            <small class="sml-red" v-if="!$v.toDate.needValue">Valid from date is required.</small>
           </div> 
      </div>
    </div>
    <div class="form-group col-sm-4" v-if="isAssessor">
      <label for="inputEmail4" class="label-small">Clinic Name:</label>
      <div class="">
              <vue-bootstrap-typeahead :inputClass="TypeHeadinptClass" id="clinicSel" ref="clinicRef"  @input="ClinictextChanged" v-model="clinicno" :data="clinics"
                @hit="selectedClinic = $event; searched=false" :serializer="item => item.clinicname"
                textVariant=".text-primary" placeholder="Search Clinics" size="sm" backgroundVariant="bg-light"
                :maxMatches="20" updateOn='blur' >
                <template slot="prepend">
                  <span class="input-group-text form-control-xs" style="font-size: .7rem;"><i class="fas fa-search fa-sm"></i></span>
                </template>
              </vue-bootstrap-typeahead>
      </div> 
    </div>
    <div class="form-group col-sm-4">
      <label  for="inputPassword4" class="label-small">Provider Name:</label>
      <div  class="col-sm-12 m-0 pr-3 pl-0">
            <vue-bootstrap-typeahead  :inputClass="TypeHeadinptClass" id="provSel" ref="providerRef" @input="ProvidertextChanged" v-model="providerName" :data="providers"
              @hit="selectedProvider = $event; searched=false" :serializer="item => item.providername"
              textVariant=".text-primary" placeholder="Search Providers" size="sm" backgroundVariant="bg-light"
              :maxMatches="20">
              <template slot="prepend">
                <span class="input-group-text form-control-xs" style="font-size: .7rem;"><i class="fas fa-search fa-sm"></i></span>
              </template>
            </vue-bootstrap-typeahead>
        </div> 
    </div>
    <div class="form-group col-sm-1">
      <label for="inputPassword4" class="label-small">  </label>
              <div class=" ">
              <button v-on:click="GetHsnInfo" type="button" class="btn btn-primary btn-sml mt-1"> Search </button>
            </div>
    </div> 
  </div> 
</form>
 <div class="row no-gutters"> 
   <div class="col-4 pr-1"  v-if="patient!=null">
      <div class="card pb-1">
        <div class="card-header d-flex align-items-center  pl-1" style="height: 1rem; text-align:left;">
          <h5><small class="text-muted"><b><i class="fas fa-user-injured"></i>Patient: {{patient.firstName}}
            {{patient.lastName}} </b></small></h5>
        </div>
        <div class="card-body p-1">
          <div class="row">
            <span for="cname" class="col-sm-4"><b class="label-small">HSN:</b></span>
            <span class="col-sm-6 label-small" type="text">{{HSN}}</span>
          </div>
          <div class="row">
            <span for="cname" class="col-sm-4"><b class="label-small">Address:</b></span>
            <span class="col-sm-6 label-small" type="text"> {{patient.address1}} {{patient.address2}} </span>
          </div>
          <div class="row">
            <span for="cname" class="col-sm-4"><b class="label-small">DOB:</b></span>
            <span class="col-sm-6 label-small" type="text">{{patient.birthDay |moment(patient.birthDay) }} </span>
          </div>
        </div>
      </div>
  </div>
  <div class="col-4 pr-1" v-if="selectedClinic!=null && patient!=null">
    <div class="card pb-1" >
        <div class="card-header d-flex align-items-center  pl-1" style="height: 1rem; text-align:left;">
          <h5><small class="text-muted"><b><i class="fas fa-clinic-medical"></i>Clinic: {{selectedClinic.clinicname}}</b></small></h5>
        </div>
        <div class="card-body p-1">
          <div class="row">
            <span for="cname" class="col-sm-4"><b class="label-small">Clinic #:</b></span>
            <span class="col-sm-6 label-small" type="text">{{selectedClinic.clinicno}}</span>
          </div>
          <div class="row">
            <span for="cname" class="col-sm-4"><b class="label-small">Address:</b></span>
            <span class="col-sm-6 label-small" type="text">{{selectedClinic.address}}</span>
          </div>
          <div class="row">
            <span for="cname" class="col-sm-4"><b class="label-small">City:</b></span>
            <span class="col-sm-6 label-small" type="text">{{selectedClinic.city}}</span>
          </div>
        </div> 
    </div>
  </div>

  <div class="col-4 pr-0" v-if="selectedProvider!=null && patient!=null">
    <div class="card pb-1" >
        <div class="card-header d-flex align-items-center  pl-1" style="height: 1rem; text-align:left;">
          
           <h5 v-if="selectedProvider.providername.length<25"><small class="text-muted"><b><i class="fas fa-clinic-medical"></i>Provider: {{selectedProvider.providername}}</b></small></h5>
           <h5 v-else style="font-size: 90%;"><small class="text-muted"><b><i class="fas fa-clinic-medical"></i>Provider: {{selectedProvider.providername}}</b></small></h5>
        </div>
        <div class="card-body p-1">
          <div class="row">
            <span for="cname" class="col-sm-3"><b class="label-small">Provider #:</b></span>
            <span class="col-sm-9 label-small" type="text">{{selectedProvider.orgid}}{{selectedProvider.providerno}}</span>
          </div>
          <div class="row">
            <span for="cname" class="col-sm-3"><b class="label-small">Address:</b></span>
            <span class="col-sm-9 label-small" type="text">{{selectedProvider.address}}</span>
          </div>
          <div class="row">
            <span for="cname" class="col-sm-3"><b class="label-small">City:</b></span>
            <span class="col-sm-9 label-small" type="text">{{selectedProvider.city}}</span>
          </div>
        </div> 
    </div>
  </div>

</div> 
 <div id="SearchResult" v-if="searched" class="p0">
      <div class="mt-2">
        <v-client-table :columns="columns" :data="patientHistList" :options="options" >                  
       
           <span class="pointer"   v-if="props.row.reversalind=='R'"  v-on:click="ViewHistoryDetails(props.row)" slot="view" slot-scope="props">
            <i class="far fa-question-circle" ></i><span style="color:red"><i class="fa fa-recycle" aria-hidden="true"></i></span></span> 
           <span class="pointer"   v-else  v-on:click="ViewHistoryDetails(props.row)" slot="view" slot-scope="props">
            <i class="far fa-question-circle" ></i></span>   
           </v-client-table>    
      </div> 
  </div> 
  
</div>
</template> 
<script>
import Vue from 'vue'; 
import {mapGetters} from 'vuex'
import moment from 'moment'
import axios from 'axios' 
import Datepicker from 'vuejs-datepicker';
import LayoutDefault from '@/Common/Default/DefaultLayout.vue'; 
import Subtitle from '@/Common/Default/SubTitle.vue'; 
import Card from "@/Common/Card.vue";
import CardBody from "@/Common/CardBody.vue";
import TileNote from "@/Common/TileNote.vue";
import { PopUpVariant } from '@/Common/Default/PopUpVariant';
import { request } from 'http';
import PatientHistoryDetail from '@/components/Common/PatientHistoryDetail.vue'
import Vuelidate from 'vuelidate'
import {helpers, required, minLength, sameAs, not, maxLength, numeric, integer, between} from 'vuelidate/lib/validators'
  
Vue.use(Vuelidate);
export default  {
  props: {
      Type: ''
  },
  name: 'PatientHistorySearch',
  data: function () {
    return {
            DisbleProvider:true,
            MsgPopup :'',
            showError: false,
            TypeHeadinptClass:'form-control form-control-xs',
            boxTwo: '',
            BtnSubmitdisabled:0,
            primaryText:'',
            PaidByThirdPArty:false,
            browseText:'Click Here',
            AppServiceID:0,
            MaxMatch:20,
            AppName:'',
            title:"Dental Patient History Search",
            subtitle: "Welcome", 
            HSN:'',
            fromDate: '',
            toDate: '',
            serviceDate: '',
            DateFormat:'',
            datapickClass:"form-control form-control-xs my-0",
            showInfo : false,
            providers:[],
            providerName:'',
            selectedProvider: null,
            detailProvider: null,
            clinics: [],
            selfClinic: [],
            clinicName: '',
            selectedClinic: null,
            detailClinic: null,
            patientHistList: [],
            patient:null,
            PopUpVar:PopUpVariant,
            showDetailModal: false,
            showMessageModal: false,
            searched:false, 
            phListingParams: [],
            phDetailParams: [],     
            phDetails: [],
            phType: 'CL',
            claimRequestNumber: '',
            Msg: '',  
            Services:'',
            isAssessor:false,
            clinicno:'',
        columns: ['view', "claimtypedescription" ,'servicedate', 'priorapprvno','providerno' , 'name','clinicno', 'clinicname'],

        options: {
          texts:{
            count:"Showing {from} to {to} of {count} records|{count} records|One record",
            first:'First',
            last:'Last',
            limit:"Records:",
            page:"Page:",
            noResults:"No Claim or Prior Approval Found",
            filterBy:"Filter by {column}",
            loading:'Loading...',
            defaultOption:'Select {column}',
            columns:'Columns'
          },

          responseAdapter({data}) {
            return {
              data: formatData,
              count: data.length
            };
          },

          perPage:5,
          perPageValues:[5],

          dateColumns:['servicedate'],

          filterable: true,

          listColumns: {
            claimtype: [
              {id: "CL",
              text: "Claim"},
              {id: "PA",
              text: "Prior Approval"}
            ]
          },

          templates: {
            servicedate(h, row) {         
              return moment(row.servicedate,"YYYY-MM-DD").format('YYYY/MM/DD');  
            },  
          },

          headings: {
            claimtypedescription:'Claim/Prior Approval',
            status: 'Status',
            priorapprvno: "Prior Approval #",
            providerno: "Provider #",
            servicedate: "Service Date",
            clinicno: "Clinic #",
            claimtype: "Claim Type",
            servicetype: "Service Type",
            name: "Provider Name",
            clinicname: "Clinic Name"
          },

          pagination: {
            edge: true,
            nav: 'scroll',
            chunk: 5
          },

          sortable: ['servicedate', 'priorapprvno' ,  'providerno', 'clinicno', 'claimtype', 'servicetype'],

          sortIcon: {
                  base : 'fas',
                  is: 'fa-sort',
                  up: 'fa-sort-up',
                  down: 'fa-sort-down'
          },
        },
      }
    },

    components: { 
            Card,
            CardBody,
            TileNote ,
            Datepicker,
            PatientHistoryDetail,
            Subtitle
    },

    validations(){
      return { 
        HSN :{
             required,
             minLength:minLength(9),
             numeric
        },
       toDate:{
             needValue: value=>  this.ValidatetoDate(),             
       },    
       fromDate:{
             needValue: value=>  this.ValidatefromDate(),             
       },            
      }
    },

    filters: {
      moment: function (date) {
        return moment(date,"YYYY-MM-DD").format('YYYY/MM/DD');
      },
      stringify(value) {
        return JSON.stringify(value, null, 2)
      }  
    }, 

  methods: {
    Go(){
        this.$router.push('/DPEBB/MainHome')
    },
    ClosePopup(){
      this.showError =false;
    },
    Show(){
          this.showInfo =true;
    }, 

    GetHsnInfo(){         
      var vm = this;      
      vm.$v.$touch();
        if (!vm.$v.$invalid){   
        var params = new URLSearchParams();
        params.append('HSN', this.HSN);
        axios.get('SaskHealthApi/Host/GetHsnInq', { headers: { 'Authorization': 'Bearer ' + localStorage.access_token },params})
          .then(function (response) {
            vm.patient =response.data;   
            vm.loadTable(); 
            vm.searched = true;
          })
          .catch(function (er) {
            console.log(er)
            vm.patientHistList = [];
           if(er.status ==400)
            {
              //console.log('here')
              vm.showError = true;
              vm.MsgPopup = er.data.message; 
            }
            else if(er.status == 500)
            {
                vm.showError = true;
                
                if(er.data.message !=null)
                  vm.MsgPopup = er.data.message;
                else
                vm.MsgPopup = "Network Related Error, Please Contact System Administrator." 
            }           
  
          })
        }
    },

    loadTable(){

      if(this.clinicno==null)
        this.selectedClinic = null;
        else
      {
        if(this.isAssessor)
          this.selectedClinic = this.clinics.find(x=>x.clinicname == this.clinicno)
        else
          this.selectedClinic = this.clinics.find(x=>x.clinicno == this.clinicno);
      }         
    
   
      var vm = this;      
      vm.searched = false;
      this.SetPatientHistorySearchParms(vm);
      var params =  new URLSearchParams();
      params = vm.phListingParams;
      axios.get('SaskHealthApi/Host/GetPatientHistList', { headers: { 'Authorization': 'Bearer ' + localStorage.access_token }, params})
        .then(function (response) {                      
          vm.patientHistList = response.data;               
        })
        .catch(function (er) {
          console.log(er)
          vm.patientHistList = [];
          if(er.status ==400)
            {
              console.log('here')
              vm.showError = true;
              vm.MsgPopup = er.data.message; 
            }
            else if(er.status == 500)
            {
                vm.showError = true;
                
                if(er.data.message !=null)
                  vm.MsgPopup = er.data.message;
                else
                vm.MsgPopup = "Network Related Error, Please Contact System Administrator." 
            }           
    
      })
    },
    ClinictextChanged(){
      if(this.clinicno == ''){
        this.selectedClinic = null;
        this.searched = false;
      }
    },
    ProvidertextChanged(){
      if(this.providerName == ''){
        this.selectedProvider = null;
        this.searched = false;
      }
    },
    HSNtextChanged(){
      if(this.HSN == null || this.HSN.length < 9){
        this.patient = null;
        this.searched = false;
      }
    },
    CheckProvider(){
      this.selectedProvider = this.providers.find(x=>x.providerno == this.providerName);
    },
    GetProviders(){
      var vm = this;
      var params = new URLSearchParams();
        params.append('ServiceID', this.AppServiceID);
        axios.get('SaskHealthApi/Codes/GetProvidersByService', { headers: { 'Authorization': 'Bearer ' + localStorage.access_token },params})
          .then(function (response) {
            vm.providers = response.data;
            vm.showInfo= true; 
          })
          .catch(function (er) {
            console.log(er)
          }).then(function()
          {     
            console.log('Service ID'+vm.AppServiceID)
            if(vm.AppServiceID == 4)
            {
                vm.selectedProvider=  {"providerno":"9999999998","providername":"PSEUDO HEARING","address":"3475 ALBERT ST","city":"Regina","province":"SK","service":"Hearing","subtype":"Hearing AUD", "orgid": "SKMS"};
                vm.$refs.providerRef.inputValue = vm.selectedProvider.providername;
            } 
          })
    },
    ValidatetoDate(){
      if((this.toDate == '' || this.toDate ==null) && (this.fromDate != '' && this.fromDate != null))
        {
          return false;
        }
        else if((this.toDate != '' || this.toDate !=null) && (this.fromDate != '' && this.fromDate != null))
        {
          if(moment(this.fromDate).toISOString() <= moment(this.toDate).toISOString())
          {
              return true;
          }  
          else
          return false;
        }
        else if((this.toDate != '' || this.toDate !=null) && (this.fromDate == '' || this.fromDate == null))
        {
            return true;
        }
        else
        {
        return false;
        }

      },
    ValidatefromDate(){
      if((this.fromDate == '' || this.fromDate ==null) && (this.toDate != '' && this.toDate !=null ))               
        {
          if(moment(this.fromDate).toISOString() < moment(this.toDate).toISOString())
          {
              return true;
          }  
          else
          return false;
        }
        else
        {
            return true;
        }
      },      
  
  
  
  GetUserClinics(){
           var vm = this; 
           var params = new URLSearchParams();
          params.append('ServiceID', this.AppServiceID);
            axios.get('/SaskHealthApi/Codes/GetUserClinic', { headers: { 'Authorization': 'Bearer ' + localStorage.access_token }, params})
                .then(function (response) {
                    vm.clinics = response.data;
                    if(!vm.isAssessor){
                      vm.selectedClinic= vm.clinics[0];
                      vm.clinicno = vm.clinics[0].clinicno.toString();
                      vm.columns = ['view',  "claimtypedescription" ,'servicedate', 'priorapprvno','providerno' , 'name'];
                    } 
                    // console.log(vm.selectedClinic);
                })
            .catch(function (er) {
                console.log(er)
            })   
        },
 ClinictextChanged(){
        if(this.clinicno == ''){
          this.selectedClinic = null;
          this.searched = false;
        }
          
      },
      ProvidertextChanged(){
        if(this.providerName == ''){
          this.selectedProvider = null;
          this.searched = false;
        }
          
      },
    ClearSearch() {
        var vm = this;
        vm.providerName = "";
        vm.selectedProvider = null;
        vm.clinicName = "";
        vm.selectedClinic = null;
        vm.patient = null;
        vm.toDate = null;
        vm.fromDate = '';
        vm.HSN = "";
        vm.searched = false;
        vm.phDetailParams = [];
        vm.phListingParams = [];
        vm.clinicno = vm.selfClinic[0].clinicno;
        vm.selectedClinic = vm.selfClinic[0];
        vm.clinicName = vm.selfClinic[0].clinicname;
        this.$refs.providerRef.inputValue = ''
        this.$refs.clinicRef.inputValue = ''
    },

    ViewHistoryDetails(Rowdata) {
      var vm = this;
      vm.popUpAllowEdit = false;
    vm.phDetails = [];
      vm.popUpAllowEdit = false;
      vm.claimRequestNumber = Rowdata.claimrequestno;
      var frm = ''
      var to = '' 
      if (vm.fromDate == '' || vm.fromDate == null)
        frm = "00000000";
      else
        frm = moment(vm.fromDate, "YYYY-MM-DD").format('YYYYMMDD');
      if (vm.toDate == '' || vm.toDate == null)
        to = "00000000";
      else
        to = moment(vm.toDate, "YYYY-MM-DD").format('YYYYMMDD');
      var params = new URLSearchParams();
      params.append('HSN', this.HSN);
      params.append('servicetype', Rowdata.servicetype);
      params.append('fromDate', frm);
      params.append('toDate', to);
      params.append('clinicNo', Rowdata.clinicno);
      params.append('providerNo', Rowdata.providerno);
      params.append('Dbkey', Rowdata.dbkey);
      params.append('recordType', Rowdata.claimtype); 
      params.append('claimreqno', Rowdata.claimrequestno); 
      axios.get('SaskHealthApi/Host/GetPatientHistoryDetail', {
          headers: {
            'Authorization': 'Bearer ' + localStorage.access_token
          },
          params
        })
        .then(function (response) {
          vm.phDetails = response.data;
        })
        .catch(function (er) {
           if(er.status ==400)
            {
               vm.showDetailModal = false;
              console.log('here')
              vm.showError = true;
              vm.MsgPopup = er.data.message; 
            }
            else if(er.status == 500)
            {
               vm.showDetailModal = false;
                vm.showError = true; 
                if(er.data.message !=null)
                  vm.MsgPopup = er.data.message;
                else
                vm.MsgPopup = "Network Related Error !" 
            }

     }).then(function () {
           
            var MfPrvider = Rowdata.providerno.substring(4,14);
            var MfClinic =  Rowdata.clinicno; 
  
           vm.detailProvider = _.find(vm.providers, ['providerno', MfPrvider]); 
            vm.detailClinic = _.find(vm.clinics, ['clinicno', MfClinic]);
    
            if(vm.phDetails.length != 'undefined' && vm.phDetails.length != 0)
             vm.showDetailModal = true;  
        }); 
    },

    SetPatientHistorySearchParms(vm) {
      var frm = ''
      var to = ''
      var clinic = "00000"
      var provider = "0000000000"
      
      // if (vm.selectedClinic != null && vm.clinicno != "") {
      if(vm.clinicno=='')
        clinic = '00000';
        else
      {
        if(vm.isAssessor){
          vm.selectedClinic = vm.clinics.find(x=>x.clinicname == vm.clinicno)
          clinic = vm.selectedClinic.clinicno;
        }
        else
          clinic = vm.clinicno;
      }
    
      // } else {
      //   vm.selectedClinic = null;
      // }
      if (vm.selectedProvider != null) {
        provider = vm.selectedProvider.providerno;
      }

      if (vm.fromDate == '' || vm.fromDate == null)
        frm = "00000000";
      else
        frm = moment(vm.fromDate, "YYYY-MM-DD").format('YYYYMMDD');
      if (vm.toDate == '' || vm.toDate == null)
        to = "00000000";
      else
        to = moment(vm.toDate, "YYYY-MM-DD").format('YYYYMMDD');

      vm.phListingParams = new URLSearchParams();
      vm.phListingParams.append('HSN', this.HSN);
      vm.phListingParams.append('servicetype', this.Services);
      vm.phListingParams.append('fromDate', frm);
      vm.phListingParams.append('toDate', to);
      vm.phListingParams.append('clinicNo', clinic);
      vm.phListingParams.append('providerNo', provider);
    },

    CloseDetailModal() {
      this.showDetailModal = false;
    },

    PopMsgClose() {

    },

    OnResize(event){

    },
    GetServiceType(){
          
           var vm = this;
           var params = new URLSearchParams();            
           params.append('ServiceID', this.AppServiceID);
            axios.get('SaskHealthApi/Codes/GetServiceType?_='+Date.now(), { headers: { 'Authorization': 'Bearer ' + localStorage.access_token }, params})
            .then(function (response) {
                vm.Services=response.data;
                })
            .catch(function (er) {

                console.log(er)
                
                })
        }
  },

  computed:{
      UserName(){
          return !this.$store.getters.GetCurrentUser ? false : this.$store.getters.GetCurrentUser;
      },
      AllAppLevel(){
          return this.$store.getters.GetAllApplevel;
        } 
  },

  created: function() {         
         
    this.AppServiceID = this.Type;  
    
    if(this.AppServiceID == 3)
    {
      this.AppName = "Optical";
    }
    else if(this.AppServiceID == 4)
    {
      this.AppName = "Hearing";
    }
    else if(this.AppServiceID == 5)
    {
      this.AppName = "Podiatry";
    }
    
    this.DateFormat = this.$store.getters.GetDateFormat;   
    this.GetServiceType();
  },

  beforeCreate: function() {  
  
  },

  mounted: function () {

    var params = new URLSearchParams();
    var vm = this;

    axios.get('SaskHealthApi/Codes/IsAssessorOrSuper?_='+Date.now(), { headers: { 'Authorization': 'Bearer ' + localStorage.access_token },params})
    .then(function (response) {
        // console.log(response.data);
      vm.isAssessor = response.data;
        vm.GetUserClinics(); 
        vm.GetProviders();
    }).catch(function (er) {
      console.log(er)
    });
    
 
  },
}
 

</script>

<style scopped>
 .row.no-gutter [class*='col-']   {
   padding-right:1px;
   
 }
 .list-group-item {
    position: relative;
    display: block;
    padding: 0px 15px;
    margin-bottom: -1px;
    border: 1px solid #ddd;
    background-color: blue;
    line-height: 1em
}
.col-lg-1>div {background-color:#ddd;}

#docimg {
   
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50; 
}
#line {
  border-top:1px solid   rgba(7, 14, 109, 0.25);
}


.test-modal .modal {
    padding: 0 !important;
    padding-left: 0px !important;
    overflow-y: scroll;
}

.test-modal .modal-dialog { 
    max-width: 100%;
    height: 100%;
    margin: 0;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    display: flex;
    z-index: 100000;
    padding-right: 0px !important;
    padding-left: 0px !important;
}

.modal-open {
    padding: 0 !important;
    padding-left: 0px !important;
    overflow-y: scroll;
}

#phModal {
  padding-left: 0 !important;
  padding-right: 0 !important;
}
 
</style>