<template>
<div id="PatientEligibilityRequest">
<b-modal id="modal-sm"  size="md" title="Patient Eligibility" v-model="showModal" no-close-on-esc no-close-on-backdrop hide-header-close>
<div slot="default">
    <div class='alert alert-warning' role='alert'> {{Msg}} <br> Please Contact System Administrator. </div>
</div> 
<div slot="modal-footer" class="w-100">
    <p class="float-left" variant="primary"></p>
    <b-button variant="primary"  size="md"  class="float-right"  @click="PEExit"> Close </b-button>
</div>
</b-modal>

 <Subtitle  v-bind:ServiceID="this.AppServiceID">
   <template v-slot:header>
    <i class="fab fa-delicious"></i><b>Patient Eligibility:</b>
  </template> 
</Subtitle>


<!-- <h4><small class="text-muted"><i class="fas fa-user-shield"></i><b>Patient Eligibility Request:</b></small></h4>   -->
<form class="card  p-0 mb-1">
  <div class="card-header d-flex align-items-center  pl-1" style="height: 1rem; text-align:left;">
        <h5><small class="text-muted"><b><i class="fas fa-search-plus"></i>Search: HSN requried (all others optional)</b></small></h5>
  </div>
  <div class="form-row p-1">
    <div class="form-group col-sm-1">
      <label for="inputEmail4" class="label-small">HSN</label>
       <input id="UserID" v-model="HSN" maxlength="9" class="form-control form-control-xs">
      <div class="row" v-show="$v.HSN.$error">           
      <div class="col-sm-12">
          <small class="sml-red" v-if="!$v.HSN.required">HSN is required.</small>
            <small class="sml-red" v-if="!$v.HSN.numeric">HSN must be a number.</small>
      </div>
      </div>
    </div>
    <div class="form-group col-sm-1">
      <label for="inputPassword4" class="label-small">Service Date</label>
      <div> 
        <datepicker class="servdatapick" typeable :open-date="new Date()" :disabledDates="{ from: new Date(Date.now() +1) }" v-model="servicedate" 
            :format="DateFormat" id="effDate" :bootstrap-styling="true" :input-class="datapickClass" name="serviceDatepicker"></datepicker>                        
      </div>
       <div  class="row" v-show="$v.servicedate.$error">
        <div class="col-sm-12">     
            <small class="sml-red" v-if="!$v.servicedate.required">Date is required.</small> 
                       
       </div>
        <div class="col-sm-12"> 
            <small class="sml-red" v-if="!$v.servicedate.maxValue">Must not be future date.</small>
       </div>     
       </div>
    </div>
    <div class="form-group col-sm-3">
      <label for="inputPassword4" class="label-small">Service Code</label>
      <div >
        <vue-bootstrap-typeahead ref="SCRef" :inputClass="TypeHeadinptClass"  v-model="servicecode" @input="SCtextChanged" :data="ServiceCodes"  @hit="SelectedCode = $event; searched=false"
            :serializer="item => item.servicedesc"  textVariant=".text-info"   placeholder="Search Service Code"  size="sm"  backgroundVariant="bg-light" :maxMatches="20" >
            <template slot="prepend">
              <span class="input-group-text m-0 p-1 form-control-xs" style="font-size: .6rem;"><i class="fas fa-search fa-sm"></i></span>
            </template>                      
        </vue-bootstrap-typeahead>
      </div>
    </div>
    <div class="form-group col-sm-3" v-if="isAssessor">
      <label for="inputEmail4" class="label-small">Clinic #:</label>
      <div >
        <vue-bootstrap-typeahead  :inputClass="TypeHeadinptClass"   autocomplete="off" @input="ClinictextChanged" id="clinicSel" ref="clinicRef" v-model="clinicno" :data="Clinic"
          @hit="selectedClinic = $event; searched=false" :serializer="item => item.clinicname"
          textVariant=".text-primary" placeholder="Search Clinics" size="sm" backgroundVariant="bg-light"
          :maxMatches="20" updateOn='blur' >
          <template slot="prepend">
            <span class="input-group-text m-0 p-1 form-control-xs" style="font-size: .6rem;"><i class="fas fa-search fa-sm"></i></span>
          </template>
        </vue-bootstrap-typeahead>
      </div>
      <div class="row mb-1" v-show="$v.clinicno.$error">
        <div class="col-sm-4"></div>
        <div class="col-sm-8">
            <small class="sml-red" v-if="!$v.clinicno.needValue">Clinic No is required when service code is entered.</small>
        </div>
      </div>
    </div>
    <div class="form-group col-sm-3">
      <label for="inputPassword4" class="label-small">Provider No:</label>
      <div v-if="!isAssessor">
              <input id="UserID" @input="CheckProvider" v-model="providernum" maxlength="10" class="form-control form-control-xs">
      </div> 
      <div  v-if="isAssessor" >
        <vue-bootstrap-typeahead id="provSel" :inputClass="TypeHeadinptClass"  ref="providerRef" @input="ProvidertextChanged" v-model="providernum" :data="providers"
        @hit="selectedProvider = $event; searched=false" :serializer="item => item.providername"
        textVariant=".text-primary" placeholder="Search Providers" size="sm" backgroundVariant="bg-light"
        :maxMatches="20">
        <template slot="prepend">
          <span class="input-group-text m-0 p-1 form-control-xs" style="font-size: .6rem;"><i class="fas fa-search fa-sm"></i></span>
        </template>
        </vue-bootstrap-typeahead>
      </div>
      <div class="row" v-show="$v.providernum.$error">
        <div class="col-sm-12"></div>        
            <small class="sml-red" v-if="!$v.providernum.needValue">Provider No is required when service code is entered.</small>
            <small class="sml-red" v-if="!$v.providernum.isNumber && $v.providernum.needValue">Provider No is must be a number.</small>
      </div>
    </div>
    <div class="form-group col-sm-1">
      <label for="inputPassword4" class="label-small">  </label>
              <div class=" ">
              <button v-on:click="GetHsnInfo" type="button" class="btn btn-primary btn-sml mt-1"> Search </button>
            </div>
    </div>
  </div>
  <!-- <div class="form-row p-1" >
    <div class="form-group col-sm-4" v-if="isAssessor">
      <label for="inputEmail4" class="label-small">Clinic #:</label>
      <div >
        <vue-bootstrap-typeahead  :inputClass="TypeHeadinptClass"   autocomplete="off" @input="ClinictextChanged" id="clinicSel" ref="clinicRef" v-model="clinicno" :data="Clinic"
          @hit="selectedClinic = $event; searched=false" :serializer="item => item.clinicname"
          textVariant=".text-primary" placeholder="Search Clinics" size="sm" backgroundVariant="bg-light"
          :maxMatches="20" updateOn='blur' >
          <template slot="prepend">
            <span class="input-group-text m-0 p-1 form-control-xs" style="font-size: .6rem;"><i class="fas fa-search fa-sm"></i></span>
          </template>
        </vue-bootstrap-typeahead>
      </div>
      <div class="row mb-1" v-show="$v.clinicno.$error">
        <div class="col-sm-4"></div>
        <div class="col-sm-8">
            <small class="sml-red" v-if="!$v.clinicno.needValue">Clinic # is required when service code is entered.</small>
        </div>
      </div>
    </div>
    <div class="form-group col-sm-4">
      <label for="inputPassword4" class="label-small">Provider No:</label>
      <div v-if="!isAssessor">
              <input id="UserID" @input="CheckProvider" v-model="providernum" maxlength="10" class="form-control form-control-xs">
      </div> 
      <div  v-if="isAssessor" >
        <vue-bootstrap-typeahead id="provSel" :inputClass="TypeHeadinptClass"  ref="providerRef" @input="ProvidertextChanged" v-model="providernum" :data="providers"
        @hit="selectedProvider = $event; searched=false" :serializer="item => item.providername"
        textVariant=".text-primary" placeholder="Search Providers" size="sm" backgroundVariant="bg-light"
        :maxMatches="20">
        <template slot="prepend">
          <span class="input-group-text m-0 p-1 form-control-xs" style="font-size: .6rem;"><i class="fas fa-search fa-sm"></i></span>
        </template>
        </vue-bootstrap-typeahead>
      </div>
      <div class="row" v-show="$v.providernum.$error">
        <div class="col-sm-12"></div>        
            <small class="sml-red" v-if="!$v.providernum.needValue">Provider No is required when service code is entered.</small>
            <small class="sml-red" v-if="!$v.providernum.isNumber && $v.providernum.needValue">Provider No is must be a number.</small>
      </div>
    </div>
    <div class="form-group col-sm-4">
      <label for="inputPassword4" class="label-small">  </label>
              <div class=" ">
              <button v-on:click="GetHsnInfo" type="button" class="btn btn-primary btn-sml mt-1"> Search </button>
            </div>
    </div>
 
  </div> -->
  </form>

 <div  class="row no-gutters"> 
  <div class="col-4 pr-1" >
        <div class="card" v-if="Patient!=null" >
            <div class="card-header d-flex align-items-center  pl-1" style="height: 2rem; text-align:left;">
              <h5><small class="text-muted"><b><i class="fas fa-user-injured"></i>Patient: {{Patient.firstName}} {{Patient.lastName}} </b></small></h5>
            </div>
           <div  class="card-body p-2" >
                    <div class="row" >
                      <span for="cname" class="col-sm-3 label-small"><b>HSN:</b></span> 
                      <span   class="col-sm-9 form-control-xs" type="text">{{HSN}}</span> 
                    </div>
                    <div class="row">
                      <span for="cname" class="col-sm-3 label-small"><b>Address:</b></span> 
                      <span class="col-sm-9 form-control-xs" type="text"> {{Patient.address1}}  {{Patient.address2}} </span> 
                    </div>
                    <div class="row">
                      <span for="cname" class="col-sm-3 label-small"><b>DOB:</b></span> 
                      <span class="col-sm-9 form-control-xs" type="text">{{Patient.birthDay |moment(Patient.birthDay) }} </span> 
                    </div> 
           </div>
        </div>
   </div> 

  <div class="col-4 pr-1" v-if="(selectedClinic != null)  && Patient!=null">
        <div class="card">
        <div class="card-header   d-flex align-items-center  pl-1" style="height: 2rem; text-align:left;">
          <h5><small class="text-muted"><b><i class="fas fa-clinic-medical"></i>Clinic: {{selectedClinic.clinicname}}</b></small></h5>
        </div>

         <div  class="card-body p-2" v-if="Clinic.length"> 
                    <div class="row">
                      <span for="cname" class="col-sm-3 label-small pr-0"><b>Clinic No:</b></span> 
                      <span class="col-sm-9 form-control-xs" type="text">{{selectedClinic.clinicno}}</span> 
                    </div>
                    <div class="row">
                      <span for="cname" class="col-sm-3 label-small pr-0"><b>Address:</b></span> 
                      <span class="col-sm-9 form-control-xs" type="text">{{selectedClinic.address}}</span> 
                    </div>
                    <div class="row">
                      <span for="cname" class="col-sm-3 label-small pr-0"><b>City:</b></span> 
                      <span class="col-sm-9 form-control-xs" type="text">{{selectedClinic.city}}</span> 
                    </div> 
          </div>
        
        </div>
    </div>       
   <div class="col-4 pr-1" v-if="(selectedProvider != '00000000' && selectedProvider !=null) && isAssessor && Patient!=null">
        <div class="card">
        <div class="card-header   d-flex align-items-center  pl-1" style="height: 2rem; text-align:left;">
          <h5><small class="text-muted"><b><i class="fas fa-clinic-medical"></i>Provider: {{selectedProvider.providername}}</b></small></h5>
        </div>

         <div  class="card-body p-2" v-if="Clinic.length"> 
                    <div class="row">
                      <span for="cname" class="col-sm-3 label-small pr-0"><b>Prov No:</b></span> 
                      <span class="col-sm-9 form-control-xs" type="text">{{selectedProvider.providerno}}</span> 
                    </div>
                    <div class="row">
                      <span for="cname" class="col-sm-3 label-small pr-0"><b>Address:</b></span> 
                      <span class="col-sm-9 form-control-xs" type="text">{{selectedProvider.address}}</span> 
                    </div>
                    <div class="row">
                      <span for="cname" class="col-sm-3 label-small pr-0"><b>City:</b></span> 
                      <span class="col-sm-9 form-control-xs" type="text">{{selectedProvider.city}}</span> 
                    </div> 
          </div>
        
        </div>
    </div>  
 </div>
 

      <div class="mt-2" v-if="searched">            
              <v-client-table :columns="columns" :data="PatEligList" :options="options">  
            </v-client-table> 
      </div>  	    

</div>  <!-- PatientEligibilityRequest end --> 

</template>

<script>
import {mapGetters} from 'vuex'
import moment from 'moment'
import axios from 'axios' 
import Datepicker from 'vuejs-datepicker';
import LayoutDefault from '@/Common/Default/DefaultLayout.vue'; 
import Subtitle from '@/Common/Default/SubTitle.vue'; 
import Card from "@/Common/Card.vue";
import CardBody from "@/Common/CardBody.vue";
import TileNote from "@/Common/TileNote.vue";
import Vuelidate from 'vuelidate'
import { helpers } from 'vuelidate/lib/validators'
import { required, minLength, maxLength, between,withParams,email,numeric} from 'vuelidate/lib/validators'
import { PopUpVariant } from '@/Common/Default/PopUpVariant';
import { request } from 'http';
import { type } from 'os';
export default  {
   props:{
      Type:''
    },
  // name: 'DentalHome',
  data: function () {
    return {
       TypeHeadinptClass:'form-control form-control-xs',
        AppServiceID:0,
        selectedProvider:null,
        HSN:'480227039',
        servicedate: '',
        servicecode: null,
        tooth1: '00',
        tooth2: '00',
        providernum:null,
        DateFormat:'',
        datapickClass:"form-control form-control-xs my-0",
        Clinic: [],
        clinicno: null,
        Services: '',
        PatEligList: [],
        Patient: null,
        PopUpVar:PopUpVariant,
        showModal:false,
        isAssessor:false, 
        selectedClinic:null, 
        Msg:'',
        providers:[],
        ServiceCodes:[],
        SelectedCode:null,
        indicator:'',
        AppName:'',
        AppIcon:'',
        type:'',
        searched:false,
        columns: ['claimpriorapproval','status','servicedate','servicecode','servicecodedesc','tooth1','tooth2', 'comments','clinicno','providerno'],
        options: {
        texts:{
              count:"Showing {from} to {to} of {count} records|{count} records|One record",
              first:'First',
              last:'Last',
              //filter:"Search Service Code:",
              //filterPlaceholder:"Search Service Code",
              limit:"Records:",
              page:"Page:",
              noResults:"No Patient Eligibility Records Found",
              filterBy:"Filter by {column}",
              loading:'Loading...',
              defaultOption:'Select {column}',
              columns:'Columns'
          },
          responseAdapter({data}) {
            // const formatData = data.map(o => {
            //     const dataCopy = JSON.parse(JSON.stringify(o))
            //     dataCopy.expirydate = moment(o.expirydate).format('MMMM Do YYYY')
            //     return dataCopy
            //   })
              return {
                data: formatData,
                count: data.length
              };
              // return {
              //   data,
              //   count: data.length
              // }
            },
          perPage:10,
          perPageValues:[10,15,25],
          dateColumns:['servicedate'],
          //toMomentFormat: 'YYYY/MM/DD',
          //templates: {edit: 'edit'},
          templates: {
            servicedate(h, row) {
             // moment.locale('es');               
              return moment(row.servicedate,"YYYY-MM-DD").format('YYYY/MM/DD');  
            },
            description(h, row) {
                           
              return   <div style="font-size: 70%">{row.description}</div> 
            },
            claimpriorapproval(h, row){
              return row.claimpriorapproval == 'CL'?'Claim':'Prior Approval';
            }         
          },
          headings: {
            claimpriorapproval: "Claim/Prior Approval",
            status: "Status",     
            servicedate: 'Claim Service Date/Prior Approval Expiry Date',
            servicecode: 'Service Code',
            servicecodedesc:  'Description',
            tooth1: 'Tooth 1',
            tooth2: 'Tooth 2',
            comments: 'Tooth Comments',
            clinicno: 'Clininc No',
            providerno: 'Provider No'

          },
          pagination: {
            edge: true,
            nav: 'scroll',
            chunk: 5
          },
           sortable: ['claimpriorapproval','status','servicedate','servicecode'],
          // filterable: ['username', 'fullname', 'clinicname', 'role' ,'status'],
          sortIcon: {
                  base : 'fas',
                  is: 'fa-sort',
                  up: 'fa-sort-up',
                  down: 'fa-sort-down'
                  },
          },

        }
    },
    components: { 
            Card,
            CardBody,
            TileNote ,
            Datepicker,
            Subtitle            

        },
     filters: {
          moment: function (date) {
          return moment(date,"YYYY-MM-DD").format('YYYY/MM/DD');
          },
          stringify(value) {
          return JSON.stringify(value, null, 2)
          }  
        }, 
    methods: {
      CheckProvider(){
         this.selectedProvider = this.providers.find(x=>x.providerno == this.providernum);
      },
      ClinictextChanged(){
        if(this.clinicno == ''){
          this.selectedClinic = null;
          this.searched = false;
        }
      },
      ProvidertextChanged(){
        if(this.providernum == ''){
          this.selectedProvider = null;
          this.searched = false;
        }
      
      },
      SCtextChanged(){
        if(this.servicecode == ''){
          this.SelectedCode = null;
          this.searched = false;
        }
  
      },
         GetHsnInfo(){
            this.$v.$touch();
          // console.log(this.selectedClinic);
          if (!this.$v.$invalid){
            var vm = this;
            var params = new URLSearchParams();
             params.append('HSN', this.HSN);
             axios.get('SaskHealthApi/Host/GetHsnInq', { headers: { 'Authorization': 'Bearer ' + localStorage.access_token },params})
             .then(function (response) {
                    vm.searched = true;
                    vm.Patient =response.data;                    
                    vm.loadTable(); 
                })
            .catch(function (er) {
              console.log("hsn");
                console.log(er);
                   vm.PatEligList = [];
                   vm.Patient = null;
                   vm.showModal = true;
                   vm.Msg = 'HSN Info Not found';
            })
          }
        },
        GetServiceType(){
          
           var vm = this;
           var params = new URLSearchParams();            
           params.append('ServiceID', this.AppServiceID);
            axios.get('SaskHealthApi/Codes/GetServiceType?_='+Date.now(), { headers: { 'Authorization': 'Bearer ' + localStorage.access_token }, params})
            .then(function (response) {
                vm.Services=response.data;
                })
            .catch(function (er) {

                console.log(er)
                
                })
        },
        loadTable(){
         
           var vm = this;

          if(!this.isAssessor)
            this.selectedProvider = this.providers.find(x=>x.providerno == this.providernum);
          
          //
            // this.clinicno=this.Clinic[0].clinicno;
           //this.servicedate=moment(this.servicedate,"YYYY-MM-DD").format('YYYYMMDD');
           //this.expirydate=moment(this.expirydate,"YYYY-MM-DD").format('YYYYMMDD');

          if(this.clinicno==null)
            this.selectedClinic = null;
           else
          {
            if(this.isAssessor)
              this.selectedClinic = this.Clinic.find(x=>x.clinicname == this.clinicno)
            else
             this.selectedClinic = this.Clinic.find(x=>x.clinicno == this.clinicno);
          }



          if(this.servicecode==null)
            this.SelectedCode = null;
          else
           this.SelectedCode = this.ServiceCodes.find(x=>x.servicedesc == this.servicecode);

          //   console.log(this.providerno);
           console.log(this.selectedProvider);
           console.log(this.isAssessor && this.selectedProvider !=undefined);
          //  console.log(this.servicecode);
             this.$v.$touch();
              if (!this.$v.$invalid){
          var params = new URLSearchParams();
            
            params.append('HSN', this.HSN);
            params.append('providernum',  this.selectedProvider == null?'0000000000':this.selectedProvider.providerno);
            params.append('servicedate', moment(this.servicedate,"YYYY-MM-DD").format('YYYYMMDD'));
            params.append('servicetype', this.Services);
            params.append('servicecode', this.SelectedCode==null?'0000000000':this.SelectedCode.servicecode);
            params.append('clinicno', this.selectedClinic==null?'00000':this.selectedClinic.clinicno);
            params.append('tooth1', this.tooth1),
            params.append('tooth2', this.tooth2)
             axios.get('SaskHealthApi/Host/GetPatientEligInq', { headers: { 'Authorization': 'Bearer ' + localStorage.access_token },params})
             .then(function (response) {
                    // console.log(response);                      
                    vm.PatEligList=response.data.patientEligibilityRows;
                    vm.indicator = response.data.indicator;

                    if(vm.isAssessor){
                      if(vm.indicator=='S'){
                          vm.columns =  ['status','servicecode','clinicno','providerno'];
                      }
                      else{
                        vm.columns =  ['claimpriorapproval','status','servicedate','servicecode','clinicno','providerno'];
                      }
                    }
                    else{
                      if(vm.indicator=='S'){
                          vm.columns =  ['status','servicecode'];
                      }
                      else{
                        vm.columns =  ['claimpriorapproval','status','servicedate','servicecode'];
                      }
                    }
                })
            .catch(function (er) {
                vm.PatEligList = [];
                vm.Patient = null;
                vm.showModal = true;
                vm.Msg = er.response.data.message;
                // console.log(er.response.data.message)
            })
              }
        },
       
        GetUserClinics(){
           var vm = this; 
           var params = new URLSearchParams();
          params.append('ServiceID', this.AppServiceID);
            axios.get('/SaskHealthApi/Codes/GetUserClinic', { headers: { 'Authorization': 'Bearer ' + localStorage.access_token }, params})
                .then(function (response) {
                    vm.Clinic = response.data;
                    if(!vm.isAssessor){
                      vm.selectedClinic= vm.Clinic[0];
                      vm.clinicno = vm.Clinic[0].clinicno.toString();
                    }

                    console.log(vm.selectedClinic);
                })
            .catch(function (er) {
                console.log(er)
            })   
        },
        GetProviders(){
          var vm = this;
          var params = new URLSearchParams();
          params.append('ServiceID', this.AppServiceID);
          axios.get('SaskHealthApi/Codes/GetProvidersByService', { headers: { 'Authorization': 'Bearer ' + localStorage.access_token },params})
            .then(function (response) {
              vm.providers = response.data;
            })
          .catch(function (er) {
            console.log(er)
        })
    },
    GetServiceCodes(){ 
      var vm = this;
      var params = new URLSearchParams();
        params.append('ServiceID', this.AppServiceID);
        axios.get('SaskHealthApi/Codes/GetServiceCode', { headers: { 'Authorization': 'Bearer ' + localStorage.access_token },params})
        .then(function (response) {
              //console.log(response.data);
              vm.ServiceCodes =response.data; 
              //console.log(vm.ServiceCodes)
          })
      .catch(function (er) {
          console.log(er)
      })

      },
      ClearSearch(){
        this.HSN = '';
        this.Patient = null;
        this.servicedate=moment(new Date()).format('YYYY/MM/DD');        
        
        if(this.$refs.providerRef !=undefined)
          this.$refs.providerRef.inputValue = '';
       
       if(this.isAssessor){
          // this.clinicno = '';
           if(this.$refs.clinicRef !=undefined)
          this.$refs.clinicRef.inputValue = '';
        }
        if(this.$refs.SCRef !=undefined)
         this.$refs.SCRef.inputValue = '';
         
         this.SelectedCode = null;
         this.selectedProvider = null;
  
          this.PatEligList.splice(0, this.PatEligList.length);
        
      },
      // clearGride(){
      //  this.clinicno = '';
      //  this.selectedClinic = '';
      //  this.PatEligList.splice(0, this.PatEligList.length)
      // },
      PEExit(){
        this.showModal = false;
      },
      validProvider(){
       if(this.isAssessor)
          return true;
       else{
         if(this.SelectedCode == null && this.providernum == null)
          return true
        else{
            var myRe = /^\d{0,10}$/;
         return myRe.test(this.providernum);
        }
       }
      }
    },
    computed:{
        UserName(){
            return !this.$store.getters.GetCurrentUser ? false : this.$store.getters.GetCurrentUser;
        }
    },
     created: function() { 

        this.$emit('update:layout', LayoutDefault);    
      this.type = this.Type;
      
      this.$store.dispatch('AddServiceID',this.type);
      this.$store.dispatch('GetMenuItems',this.type); 

      if(this.type == '1')
      {
        this.AppName = 'Dental Application';
        this.AppIcon = 'fas fa-tooth';
      }
      else if(this.type == '2')
      {
        this.AppName = 'Medical Application';
        this.AppIcon = 'fas fa-hospital-alt';
      }
      else  if(this.type == '3')
      {
        this.AppName = 'Optical Application';
        this.AppIcon = 'fas  fa-glasses';
      }
      else  if(this.type == '4')
      {
        this.AppName = 'Hearing Application';
        this.AppIcon = 'fas fa-assistive-listening-systems';
      }
      else  if(this.type == '5')
      {
        this.AppName = 'Podiatry Application';
        this.AppIcon = 'fas  fa-shoe-prints';
      }
      
        this.AppServiceID = this.type;        
        this.DateFormat = this.$store.getters.GetDateFormat;           
        this.servicedate=moment(new Date()).format('YYYY/MM/DD');        
        //this.expirydate=moment(new Date()).format('YYYY/MM/DD');    
        this.GetProviders();
        this.GetServiceCodes();
        var params = new URLSearchParams();
        var vm = this;

        axios.get('SaskHealthApi/Codes/IsAssessorOrSuper?_='+Date.now(), { headers: { 'Authorization': 'Bearer ' + localStorage.access_token },params})
        .then(function (response) {
            // console.log(response.data);
          vm.isAssessor = response.data;

 
            vm.GetUserClinics();

          
        }).catch(function (er) {
          console.log(er)
        });
        
        this.GetServiceType()              
        
    },
    validations(){
    return {
        HSN:{//more validation required
            required,
            numeric
        },
        servicedate:{
          required,// new Date(Date.now() +1)
          maxValue: value => (moment(this.servicedate)).toISOString() <=  moment().startOf('day').toISOString(), 
        },
        clinicno:{
            needValue: value=> (this.SelectedCode==null || this.SelectedCode=='') || (this.SelectedCode != null && (this.selectedClinic !=null && this.selectedClinic !=''))
        },
        providernum:{
          isNumber: value=> this.validProvider(),
          needValue: value=> (this.SelectedCode==null) || (this.SelectedCode != null && (this.selectedProvider !=null))
        }
      }
    }
    }
    


</script>

<style scopped>
 .row.no-gutter [class*='col-']   {
   padding-right:1px;
   
 }
 .list-group-item {
    position: relative;
    display: block;
    padding: 0px 15px;
    margin-bottom: -1px;
    border: 1px solid #ddd;
    background-color: blue;
    line-height: 1em
}
/* remove right padding from first column */
/* .row.no-gutter [class*='col-']:first-child {
  padding-right:5px;
} */
/* remove left padding from first column */
/* .row.no-gutter [class*='col-']:last-child {
  padding-left:5px;
} */


/* only for column content visible */
.col-lg-1>div {background-color:#ddd;}

#docimg {
   
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50; 
  /* margin-top: 10px; */
}
#line {
  border-top:1px solid   rgba(7, 14, 109, 0.25);
  /* border-bottom:1px solid #c00;
  border-bottom: 1px solid rgba(255,255,255,.25); */
}
 
 #PatientEligibility .form-control {
    display: block;
    width: 80%;
    height: calc(2.25rem + 2px);
    padding: 0.375rem 0.75rem;
    font-size: .3rem;
    line-height: 1.6;
    color: #28a745;
    background-color:#fff;
    background-clip: padding-box;
    border: 1px solid #28a745;
    border-radius: 0;
    transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
}
</style>