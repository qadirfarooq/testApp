<template>
<div id="VoidClaim"> 
<Subtitle  v-bind:ServiceID="this.AppServiceID">
<template v-slot:header>
  <i class="fas fa-user-cog"></i><b>Void Claim:</b>
</template> 
</Subtitle> 

 <b-modal id="modal-sm"  size="md" title="Void Claims" v-model="showModal" no-close-on-esc no-close-on-backdrop hide-header-close>
<div slot="default">
    <div class='alert alert-warning' role='alert'> {{Msg}} . </div>
</div> 
<div slot="modal-footer" class="w-100">
    <p class="float-left" variant="primary"></p>
    <b-button variant="primary"  size="md"  class="float-right"  @click="VCExit"> Close </b-button>
</div>
</b-modal>
<b-modal modal-class="test-modal fade" id="phModal" v-model="showDetailModal" hide-footer hide-header
 
      scrollable no-close-on-backdrop  
      header-class="PopUpHeader" 
      :header-text-variant=PopUpVar.headerTextVariant
      :body-bg-variant=PopUpVar.bodyBgVariant
      :body-text-variant=PopUpVar.bodyTextVariant
      :footer-bg-variant=PopUpVar.footerBgVariant
      :footer-text-variant=PopUpVar.footerTextVariant>  
 
    <VoidClaimsDetail v-if="showDetailModal"  v-on:finished="CloseDetailModal" :vcdDetails="vcdDetails" :isAssessor="isAssessor"
      :claimRequestNumber="claimRequestNumber" :selectedProvider="detailProvider" :selectedClinic="detailClinic" 
      :selectedPatient="patient" :hHSN="HSN" :hType="phType" :ServiceID="AppServiceID" :AppName="AppName"></VoidClaimsDetail>
     
</b-modal>

 <form class="card  p-0 mb-1" id="SearchForm">
  <div class="card-header d-flex align-items-center  pl-1" style="height: 1rem; text-align:left;">
        <h5><small class="text-muted"><b><i class="fas fa-search-plus"></i>Search: Claims or Prior Approvals:</b></small></h5>
  </div>
  <div class="form-row p-1">
    <div class="form-group col-sm-1">
      <label for="inputEmail4" class="label-small">HSN</label>
       <input id="UserID" v-model="HSN" maxlength="9" class="form-control form-control-xs">
    <div class="row" v-show="$v.HSN.$error">           
        <div class="col-sm-12">
            <small class="sml-red" v-if="!$v.HSN.required">HSN is required.</small>
        </div>
      </div>
      <div class="row" v-show="$v.HSN.$error">           
        <div class="col-sm-12">
           <small class="sml-red" v-if="!$v.HSN.minLength">Minimum 9 digit required.</small>
        </div>
      </div>
      <div class="row" v-show="$v.HSN.$error">           
        <div class="col-sm-12">
           <small class="sml-red" v-if="!$v.HSN.numeric">HSN must be a number.</small>
        </div>
      </div>
 

    </div>
    <div class="form-group col-sm-1">
      <label for="inputPassword4" class="label-small">From Date</label>
      <div>
          <datepicker class="servdatapick" typeable :open-date="new Date()" v-model="fromDate"
            :format="DateFormat" id="fromDate" :bootstrap-styling="true" :input-class="datapickClass"
            name="fromDatepicker"></datepicker>
      </div>
      <div  class="row" v-show="$v.fromDate.$error">
        <div class="col-sm-12">     
            <small class="sml-red" v-if="!$v.fromDate.required">from Date is required.</small>            
       </div>
       </div>  
    </div>
    <div class="form-group col-sm-1">
      <label for="inputPassword4" class="label-small">To Date:</label>
      <div>
            <datepicker class="servdatapick" typeable :open-date="new Date()" v-model="toDate" :format="DateFormat"
              id="effDate" :bootstrap-styling="true" :input-class="datapickClass" name="toDatepicker"></datepicker>
      </div>
    <div  class="row" v-show="$v.toDate.$error">
      <div class="col-sm-12">     
        <small class="sml-red" v-if="!$v.toDate.required">To Date is required.</small>            
      </div>
    </div>  
    </div>
    <div class="form-group col-sm-3" v-if="isAssessor">
      <label for="inputEmail4" class="label-small">Clinic Name:</label>
      <div class="" >
              <vue-bootstrap-typeahead :inputClass="TypeHeadinptClass" id="clinicSel" ref="clinicRef"  @input="ClinictextChanged" v-model="clinicName" :data="clinics"
                @hit="selectedClinic = $event; searched=false" :serializer="item => item.clinicname"
                textVariant=".text-primary" placeholder="Search Clinics" size="sm" backgroundVariant="bg-light"
                :maxMatches="20" updateOn='blur' >
                <template slot="prepend">
                  <span class="input-group-text form-control-xs" style="font-size: .7rem;"><i class="fas fa-search fa-sm"></i></span>
                </template>
              </vue-bootstrap-typeahead>
      </div>
    <div class="row" v-show="$v.selectedClinic.$error">
        <div class="col-sm-12"></div>        
            <small class="sml-red ml-3" v-if="!$v.selectedClinic.required">Clinic info is required.</small>
    </div>
    </div>
    <div class="form-group col-sm-3">
      <label for="inputPassword4" class="label-small">Provider Name:</label>
       <div class="">
            <vue-bootstrap-typeahead  :inputClass="TypeHeadinptClass" id="provSel" ref="SearchProvider" @input="ProvidertextChanged" v-model="providerName" :data="providers"
              @hit="selectedProvider = $event; searched=false" :serializer="item => item.providername"
              textVariant=".text-primary" placeholder="Search Providers" size="sm" backgroundVariant="bg-light"
              :maxMatches="20">
              <template slot="prepend">
                <span class="input-group-text form-control-xs" style="font-size: .7rem;"><i class="fas fa-search fa-sm"></i></span>
              </template>
            </vue-bootstrap-typeahead>
        </div>
       <div class="row" v-show="$v.selectedProvider.$error">
        <div class="col-sm-12 "></div>        
            <small class="sml-red ml-3" v-if="!$v.selectedProvider.required">Provider info is required.</small>
       </div>

    </div>
    <div class="form-group col-sm-2 ml-0 float-left"> 
       <!-- style="background-color:lightblue"> -->
      <label for="btn" class="label-small"> </label>
        <div class="mt-4 float-left" id="btn"  >
           <template><RadioToggleButtons v-model='ClaimTypes' :values='values'   color='#006537'
              textColor='#000' selectedTextColor='#fff' /> </template>
        </div>
    </div> 
    <div class="form-group col-sm-1">
      <label for="inputPassword4" class="label-small">  </label>
              <div class=" ">
              <button v-on:click="GetHsnInfo" type="button" class="btn btn-primary btn-sml"> Search </button>
            </div>
    </div> 
  </div> 
</form>
 <div class="row no-gutters"> 
   <div class="col-4 pr-1"  v-if="searched && patient!=null">
      <div class="card pb-1">
        <div class="card-header d-flex align-items-center  pl-1" style="height: 1rem; text-align:left;">
          <h5><small class="text-muted"><b><i class="fas fa-user-injured"></i>Patient: {{patient.firstName}}
            {{patient.lastName}} </b></small></h5>
        </div>
        <div class="card-body p-1">
          <div class="row">
            <span for="cname" class="col-sm-4"><b class="label-small">HSN:</b></span>
            <span class="col-sm-6 label-small" type="text">{{HSN}}</span>
          </div>
          <div class="row">
            <span for="cname" class="col-sm-4"><b class="label-small">Address:</b></span>
            <span class="col-sm-6 label-small" type="text"> {{patient.address1}} {{patient.address2}} </span>
          </div>
          <div class="row">
            <span for="cname" class="col-sm-4"><b class="label-small">DOB:</b></span>
            <span class="col-sm-6 label-small" type="text">{{patient.birthDay |moment(patient.birthDay) }} </span>
          </div>
        </div>
      </div>
  </div>
  <div class="col-4 pr-1" v-if="selectedClinic!=null">
    <div class="card pb-1" >
        <div class="card-header d-flex align-items-center  pl-1" style="height: 1rem; text-align:left;">
          <h5><small class="text-muted"><b><i class="fas fa-clinic-medical"></i>Clinic: {{selectedClinic.clinicname}}</b></small></h5>
        </div>
        <div class="card-body p-1">
          <div class="row">
            <span for="cname" class="col-sm-4"><b class="label-small">Clinic #:</b></span>
            <span class="col-sm-6 label-small" type="text">{{selectedClinic.clinicno}}</span>
          </div>
          <div class="row">
            <span for="cname" class="col-sm-4"><b class="label-small">Address:</b></span>
            <span class="col-sm-6 label-small" type="text">{{selectedClinic.address}}</span>
          </div>
          <div class="row">
            <span for="cname" class="col-sm-4"><b class="label-small">City:</b></span>
            <span class="col-sm-6 label-small" type="text">{{selectedClinic.city}}</span>
          </div>
        </div> 
    </div>
  </div>

  <div class="col-4 pr-0" v-if="selectedProvider!=null">
    <div class="card pb-1" >
        <div class="card-header d-flex align-items-center  pl-1" style="height: 1rem; text-align:left;">
          <h5><small class="text-muted"><b><i class="fas fa-clinic-medical"></i>Provider:   {{selectedProvider.providername |Capitalize}}</b></small></h5>
        </div>
        <div class="card-body p-1">
          <div class="row">
            <span for="cname" class="col-sm-4"><b class="label-small">Provider #:</b></span>
            <span class="col-sm-6 label-small" type="text">{{selectedProvider.providerno}}</span>
          </div>
          <div class="row">
            <span for="cname" class="col-sm-4"><b class="label-small">Address:</b></span>
            <span class="col-sm-6 label-small" type="text">{{selectedProvider.address}}</span>
          </div>
          <div class="row">
            <span for="cname" class="col-sm-4"><b class="label-small">City:</b></span>
            <span class="col-sm-6 label-small" type="text">{{selectedProvider.city}}</span>
          </div>
        </div> 
    </div>
  </div>

</div> 
 <div id="SearchResult" v-if="searched" class="p0">
      <div class="mt-2">
        <v-client-table :columns="columns" :data="VoidClaimsHistList" :options="options" >                  
          <span class="pointer" v-on:click="GetVoidClaimDetails(props.row)" slot="Void" slot-scope="props">
            <i class="fab fa-vimeo-v"></i></span>        
        </v-client-table>    
      </div> 
  </div>  
</div>
</template>

<script>
import Vue from 'vue'; 
import {mapGetters} from 'vuex'
import moment from 'moment'
import axios from 'axios' 
import Datepicker from 'vuejs-datepicker';
import LayoutDefault from '@/Common/Default/DefaultLayout.vue'; 
import Subtitle from '@/Common/Default/SubTitle.vue'; 
import Card from "@/Common/Card.vue";
import CardBody from "@/Common/CardBody.vue";
import TileNote from "@/Common/TileNote.vue";
import { PopUpVariant } from '@/Common/Default/PopUpVariant';
import { request } from 'http';
import VoidClaimsDetail from '@/components/Common/VoidClaimsDetail.vue';
import { HomePaths } from '@/Common/Default/HomePaths';
//import PatientHistoryDetail from '@/components/Dental/PatientHistoryDetail.vue'
import Vuelidate from 'vuelidate'
import {helpers, required, minLength, sameAs, not, maxLength, numeric, integer, between} from 'vuelidate/lib/validators'
//import BModal from "bootstrap-vue/es/components/modal/modal";
//import BModalDirective from 'bootstrap-vue/es/directives/modal/modal';
//Vue.use(BModalDirective);
Vue.use(Vuelidate);

export default  {
  props: {
      Type:''
  },
  name: 'VoidClaimsHistorySearch',
  data: function () {
    return { 
      values: [
            { label: 'Claim', value: 'CL' },
            { label: 'Prior Approval', value: 'PA' },],		 
        ClaimTypes:'CL',
        TypeHeadinptClass:'form-control form-control-xs',
        boxTwo: '',
        BtnSubmitdisabled:0,
        HomePaths:HomePaths,
        primaryText:'',
        PaidByThirdPArty:false,
        browseText:'Click Here',
        AppServiceID:0,
        MaxMatch:20, 
        AppName: '',
        AppIcon: 'fas  fa-glasses',  
        subtitle: "Welcome",
        popupTitle : "Optical HSN Notes",
        title: "Optical Application",
        HomePath:'', 
        HSN:'',
        fromDate: '2019/01/01',
        toDate: '2020/11/21',
        serviceDate: '',
        DateFormat:'',
        datapickClass:"form-control form-control-xs my-0",
        showInfo : false,
        providers:[],
        providerName:'',
        selectedProvider: null,
        detailProvider: null,
        clinics: [],
        selfClinic: [],
        clinicName: '',
        selectedClinic: null,
        detailClinic: null,
        VoidClaimsHistList: [],
        patient:null,
        PopUpVar:PopUpVariant,
        showDetailModal: false,
        showMessageModal: false,
        searched:false, 
        vcListingParams: [],
        vcDetailParams: [],     
        vcdDetails: [],
        phType: '',
        claimRequestNumber: '',
        docavail: '',
        Msg: '',  
        Services:'',
        isAssessor:false,
        showModal:false,
        columns: ["Void",'hsn','givenname',"surname","servicetype",'providerno','servicedate','traceno','logonid'],
        // columns: ["Void",'hsn','givenname',"surname","servicetype",'providerno','servicedate',"claimno",'traceno','logonid'],
        //columns: ['view', "claimtypedescription" ,'servicedate', 'priorapprvno','providerno'],

        options: {
          texts:{
            count:"Showing {from} to {to} of {count} records|{count} records|One record",
            first:'First',
            last:'Last',
            limit:"Records:",
            page:"Page:",
            noResults:"No Claim or Prior Approval Found",
            filterBy:"Filter by {column}",
            loading:'Loading...',
            defaultOption:'Select {column}',
            columns:'Columns'
          },

          responseAdapter({data}) {
            return {
              data: formatData,
              count: data.length
            };
          },

          perPage:5,
          perPageValues:[5],

          dateColumns:['servicedate'],

          filterable: [],

          listColumns: {
            claimtype: [
              {id: "CL",
              text: "Claim"},
              {id: "PA",
              text: "Prior Approval"}
            ]
          },

          templates: {
            servicedate(h, row) {         
              return moment(row.servicedate,"YYYY-MM-DD").format('YYYY/MM/DD');  
            },   
          },

          headings: {
            Action: "Void",             
            hsn: 'HSN',
            givenname: "First Name",
            surname: "Last Name",
            servicetype: "Service Type",
            providerno: "Provider #", 
            servicedate: "Service Date",
            //claimno: "Claim #",
            traceno: "Trace Audit #",
            logonid: "Login ID",
                     
//            status: 'Status',
//            priorapprvno: "Prior Approval #",
//            providerno: "Provider #",
//            servicedate: "Service Date",
//            clinicno: "Clinic #",
//            claimtype: "Claim Type",
//            servicetype: "Service Type",
          },

          pagination: {
            edge: true,
            nav: 'scroll',
            chunk: 5
          },

          sortable: ['servicedate', 'priorapprvno' ,  'providerno', 'clinicno', 'claimtype', 'servicetype'],

          sortIcon: {
                  base : 'fas',
                  is: 'fa-sort',
                  up: 'fa-sort-up',
                  down: 'fa-sort-down'
          },
        },
      }
    },

    components: { 
            Card,
            CardBody,
            TileNote ,
            Datepicker,
            VoidClaimsDetail,
            Subtitle
    },

    validations(){
      return { 
        HSN :{
             required,
             minLength:minLength(9),
             numeric
        },
        selectedProvider :{
             required, 
        },
        selectedClinic :{
             required, 
        },
        toDate :{
            required, 
        },
        fromDate :{
            required, 
        },
      }
    },

    filters: {
      moment: function (date) {
        return moment(date,"YYYY-MM-DD").format('YYYY/MM/DD');
      },
      Capitalize: function(val)
      {
          return _.startCase(_.toLower((val)));
        // return _.capitalize(val);
      },
      stringify(value) {
        return JSON.stringify(value, null, 2)
      }  
    }, 

  methods: {
    Go(){
        this.$router.push('/DPEBB/MainHome')
    },

    Show(){
          this.showInfo =true;
    }, 

    GetHsnInfo(){         
      var vm = this;      
      vm.$v.$touch();
        if (!vm.$v.$invalid){   
  
        var params = new URLSearchParams();
        params.append('HSN', this.HSN);
        axios.get('SaskHealthApi/Host/GetHsnInq', { headers: { 'Authorization': 'Bearer ' + localStorage.access_token },params})
          .then(function (response) {
            vm.patient =response.data;   
            vm.loadTable(); 
            vm.searched = true;
          })
          .catch(function (er) {
            console.log(er)
            vm.VoidClaimsHistList = [];
            if(er.status ==400)
            {
              //console.log('here')
              vm.showModal = true;
              vm.Msg = er.data.message; 
            }
            else if(er.status == 500)
            {
                vm.showModal = true; 
                if(er.data.message !=null)
                  vm.Msg = er.data.message;
                else
                vm.MsgPopup = "Network Related Error !" 
            } 
  
          })
        }
    },
      VCExit(){
        this.showModal = false;
      },
    loadTable(){         
      console.log("---------------SaskHealthApi/Host/GetVoidClaimInq");            
      var vm = this;  
       vm.VoidClaimsHistList = [];    
      vm.searched = false;
      this.SetVoidClaimsHistorySearchParms(vm);
      var params =  new URLSearchParams();
      params = vm.vcListingParams;
      axios.get('SaskHealthApi/Host/GetVoidClaimInq', { headers: { 'Authorization': 'Bearer ' + localStorage.access_token }, params})
        .then(function (response) {                      
          vm.VoidClaimsHistList = response.data;               
        })
        .catch(function (er) {
          console.log(er)
          vm.VoidClaimsHistList = [];
          vm.showModal = true;
          vm.Msg = er.data.message;
          console.log(" provider after: " + vm.selectedProvider);          
      
      })
    },
    ClinictextChanged(){
      if(this.clinicName == ''){
        this.selectedClinic = null;
        this.searched = false;
      }
    },
    ProvidertextChanged(){
      if(this.providerName == ''){
        this.selectedProvider = null;
        this.searched = false;
      }
    },
    GetProviders(){
      var vm = this;
      var params = new URLSearchParams();
        params.append('ServiceID', this.AppServiceID);
        axios.get('SaskHealthApi/Codes/GetProvidersByService', { headers: { 'Authorization': 'Bearer ' + localStorage.access_token },params})
          .then(function (response) {
            vm.providers = response.data;
            vm.showInfo= true; 
          })
          .catch(function (er) {
            console.log(er)
          }).then(function(e){
          if(vm.AppServiceID ==4)
                {
                    vm.selectedProvider=  {"providerno":"9999999998","providername":"PSEUDO HEARING","address":"3475 ALBERT ST","city":"Regina","province":"SK","service":"Hearing","subtype":"Hearing AUD"};
                     vm.$refs.SearchProvider.inputValue = vm.selectedProvider.providername;
                }
          })
    },
    GetAssessor(){
        var params = new URLSearchParams();
        var vm = this; 
        axios.get('SaskHealthApi/Codes/IsAssessorOrSuper?_='+Date.now(), { headers: { 'Authorization': 'Bearer ' + localStorage.access_token },params})
        .then(function (response) {
            // console.log(response.data);
          vm.isAssessor = response.data; 
        }).catch(function (er) {
          console.log(er)
        }).then(function (f) {
            vm.GetClinics();
        });
    },        
    GetClinics(){
      var vm = this; 
      console.log(vm.isAssessor);
                var params = new URLSearchParams();
          params.append('ServiceID', this.AppServiceID);
            axios.get('/SaskHealthApi/Codes/GetUserClinic', { headers: { 'Authorization': 'Bearer ' + localStorage.access_token }, params})
            .then(function (response) {
            vm.clinics = response.data;
        })
        .catch(function (er) {
            console.log(er)
        }).then(function() { 
          console.log('Is Assessor='+vm.isAssessor)
            if(vm.isAssessor != true)
            {
              vm.selectedClinic = {clinicno:  vm.clinics[0].clinicno, clinicname: vm.clinics[0].clinicname, address:  vm.clinics[0].address, city:  vm.clinics[0].city, province:  vm.clinics[0].province}   
              //console.log(vm.SelectedClinic) 
            } 
        })  
 
    },
 
    ClearSearch() {
        var vm = this;
        vm.providerName = "";
        vm.selectedProvider = null;
        vm.clinicName = "";
        vm.selectedClinic = null;
        vm.patient = null;
        vm.toDate = null;
        vm.fromDate = null;
        vm.HSN = "";
        vm.searched = false;
        vm.vcDetailParams = [];
        vm.vcListingParams = [];
        vm.clinicno = vm.selfClinic[0].clinicno;
        vm.selectedClinic = vm.selfClinic[0];
        vm.clinicName = vm.selfClinic[0].clinicname;
        this.$refs.providerRef.inputValue = ''
        this.$refs.clinicRef.inputValue = ''
    },

    GetVoidClaimDetails(Rowdata) {
        var vm = this;
      //console.log(' clinics ' + vm.clinics)
      vm.vcdDetails = [];
      vm.vcType = Rowdata.claimtype;
      this.claimRequestNumber = Rowdata.claimno;
      var params = new URLSearchParams();
      var frm = moment(vm.fromDate, "YYYY-MM-DD").format('YYYYMMDD');
      var to = moment(vm.toDate, "YYYY-MM-DD").format('YYYYMMDD');
      params.append('HSN', this.HSN);
      params.append('servicetype', this.Services);
      params.append('fromDate', frm);
      params.append('toDate', to);
      params.append('clinicNo', Rowdata.clinicno);
      params.append('providerNo', Rowdata.providerno);
      params.append('Dbkey', Rowdata.dbkey);   
      params.append('logonID',Rowdata.logonid);     
      params.append('claimdate',frm);
      params.append('claimno',Rowdata.claimno); 
      params.append('traceno',Rowdata.traceno); 
      params.append('claimtype',Rowdata.claimtype); 
 
      axios.get('SaskHealthApi/Host/GetVoidClaimDetail', {
        headers: {
          'Authorization': 'Bearer ' + localStorage.access_token
        },
        params
      })
      .then(function (response) {
        vm.vcdDetails = response.data;
        vm.showDetailModal = true;
      }).catch(function (er) {
      if(er.status == 400)
        {
           vm.showDetailModal = false;
            if(er.data.message !="")
            {
                vm.showMsg(er.data.message ,'','Claim Request Error');
            }
            else
            {
               vm.showMsg('Network Error, please contact system admin for more detail.','','Claim Request Error');
            }
      }
      if(er.status == 500)
          {
             vm.showDetailModal = false;
              vm.showMsg('Network Error, please contact system admin for more detail.','','Claim Request Error');
          }
        console.log(er)
      }).then(function () { 
          var MfPrvider = Rowdata.providerno.substring(4,14); 
          var MfClinic =  Rowdata.clinicno; 
          //console.log('Mf clinic ' + vm.clinics)
          vm.detailProvider = _.find(vm.providers, ['providerno', MfPrvider]); 
          vm.detailClinic = _.find(vm.clinics, ['clinicno', MfClinic]); 
          //console.log('clinic ' + vm.detailClinic)
          if(vm.vcdDetails.length != 'undefined' && vm.vcdDetails.length != 0)
          vm.showDetailModal = true;  
        }); 
    },
      showMsg(msg,data,Title) {
          this.boxTwo = ''
          this.$bvModal.msgBoxOk(msg, {
          title: Title,
          size: 'md',
          buttonSize: 'md',
          okVariant: 'danger',          
          okTitle: 'Close', 
          footerClass: 'p-2',
          hideHeaderClose: true,
          hideHeaderCancel: true,
          centered: true, 
        })
          .then(value => {
            console.log('at value ' + value)
            this.boxTwo = value
            if(value)
            {
             
            }
          })
          .catch(err => {
            // An error occurred
          })
      },
    SetVoidClaimsHistorySearchParms(vm) {
      console.log("-------------SetVoidClaimsHistorySearchParms");
      var frm = ''
      var to = ''
      var clinic = "00000"
      var provider = "0000000000"
      if (vm.selectedClinic != null) {
        clinic = vm.selectedClinic.clinicno;
      } else {
        vm.selectedClinic = null;
      }
      if (vm.selectedProvider != null) {
        provider = vm.selectedProvider.providerno;
      } else {
        vm.selectedProvider = null;
      }
      if (vm.fromDate == '' || vm.fromDate == null)
        frm = "00000000";
      else
        frm =  moment(vm.fromDate, "YYYY-MM-DD").format('YYYYMMDD');
      if (vm.toDate == '' || vm.toDate == null)
        to = "00000000";
      else
        to =  moment(vm.toDate, "YYYY-MM-DD").format('YYYYMMDD');
      vm.vcListingParams = new URLSearchParams();
      vm.vcListingParams.append('HSN', this.HSN);
      vm.vcListingParams.append('servicetype', this.Services);
      vm.vcListingParams.append('fromDate', frm);
      vm.vcListingParams.append('toDate', to);
      vm.vcListingParams.append('clinicNo', clinic);
      vm.vcListingParams.append('providerNo', provider);
      vm.vcListingParams.append('claimtype',this.ClaimTypes);
      this.phType = this.ClaimTypes;
    },

    SetVoidClaimDetailSearchParams(Rowdata, vm) {
      var frm = ''
      vm.vcDetailParams = new URLSearchParams();
      vm.vcDetailParams = vm.vcListingParams;
      vm.vcDetailParams.append('Dbkey', Rowdata.dbkey);
      vm.vcDetailParams.append('providerNum',Rowdata.providerno);
      vm.vcDetailParams.append('logonID',Rowdata.logonid);
      frm = moment(vm.fromDate, "YYYY-MM-DD").format('YYYYMMDD');
      vm.vcDetailParams.append('claimdate',frm);
      vm.vcDetailParams.append('claimno',Rowdata.claimno); 
      vm.vcDetailParams.append('traceno',Rowdata.traceno);
      vm.vcDetailParams.append('claimtype',Rowdata.claimtype);
    },

    CloseDetailModal() {
      console.log('call hsn')
      this.GetHsnInfo();
      this.showDetailModal = false;
   
    },

    PopMsgClose() {

    },

    OnResize(event){

    },
    GetServiceType(){
          
           var vm = this;
           var params = new URLSearchParams();  
           console.log("GetServiceType");
           console.log("this.AppServiceID: " + this.AppServiceID);           
       
           params.append('ServiceID', this.AppServiceID);

            axios.get('SaskHealthApi/Codes/GetServiceType?_='+Date.now(), { headers: { 'Authorization': 'Bearer ' + localStorage.access_token }, params})
            .then(function (response) {
                vm.Services=response.data;
                })
            .catch(function (er) {

                console.log(er)
                
                })
        }
  },

  computed:{
 
  },                
  created: function() {      
    this.AppServiceID = this.Type;
    if(this.AppServiceID == 3)
    {
      this.popupTitle = "Optical HSN Notes";
      this.AppName = "Optical Application:";
      this.title= "Optical Application";
      this.HomePath=this.HomePaths.Optical;
    }
    else if(this.AppServiceID == 4)
    {
      this.popupTitle = "Hearing HSN Notes";
      this.AppName = "Hearing Application:";
      this.title= "Hearing Application";
      this.HomePath = this.HomePaths.Hearing;
    }
    else if(this.AppServiceID == 5)
    {
      this.popupTitle = "Podiatry HSN Notes";
      this.AppName = "Podiatry Application:";
      this.title= "Podiatry Application";
      this.HomePath = this.HomePaths.Podiatry;
    }

    this.DateFormat = this.$store.getters.GetDateFormat;   
    this.GetServiceType();
     this.GetProviders();
  },

  beforeCreate: function() {  
  },

  mounted: function () {
  this.GetAssessor();  
  },
}
 

</script>

<style scopped>
.btn{
  outline: none !important;
}
 .row.no-gutter [class*='col-']   {
   padding-right:1px;
   
 }
 .list-group-item {
    position: relative;
    display: block;
    padding: 0px 15px;
    margin-bottom: -1px;
    border: 1px solid #ddd;
    background-color: blue;
    line-height: 1em
}
.col-lg-1>div {background-color:#ddd;}

#docimg {
   
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50; 
}
#line {
  border-top:1px solid   rgba(7, 14, 109, 0.25);
}


.test-modal .modal {
    padding: 0 !important;
    padding-left: 0px !important;
    overflow-y: scroll;
}

.test-modal .modal-dialog { 
    max-width: 100%;
    height: 100%;
    margin: 0;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    display: flex;
    z-index: 100000;
    padding-right: 0px !important;
    padding-left: 0px !important;
}

.modal-open {
    padding: 0 !important;
    padding-left: 0px !important;
    overflow-y: scroll;
}

#phModal {
  padding-left: 0 !important;
  padding-right: 0 !important;
}
 
</style>