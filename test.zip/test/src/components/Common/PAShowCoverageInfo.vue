<template>
<div>
<div class="row Maintitle py-0"> 
<div class="col-sm-8 my-0" >
    <div class="row">
    <span class="col-sm-4"><h4><small class="text-muted">
        <b>{{AppName}}</b></small></h4> 
        </span>  
    <span class="col-sm-4"><h4><small class="text-muted">
    <i class="fas fa-user-injured"></i><b>HSN: {{HSN}}</b></small></h4> 
        </span> 
        </div>   
</div>
<div class="col-sm-4 mt-1 ">
    <button v-on:click="ClosePopup" type="button" class="btn BtnClose btn-sml float-right"><i class="fas fa-times"></i> Close  </button>
</div>
</div>

<div class="row no-gutters mt-2">  
<div class="col-12 pr-2"  v-if="Patient!=null" >
<div class="card py-0">
<div class="card-header d-flex align-items-center  pl-1" style="height: 2rem; text-align:center;">
<h5><small class="text-muted"><b><i class="fas fa-user-injured"></i>Patient Coverage Information </b></small></h5>
</div> 
<div class="row ml-1">
        <div class="col-4">
                <div class="row">
                        <div class="col">
                                <strong>Name:</strong>
                        </div>
                        <div class="col">
                                {{Patient.givenName}} {{Patient.surName}}
                        </div> 
                </div>
        </div>
        <div class="col">
                <div class="row">
                        <div class="col">
                                <strong>Registry (First Nations):</strong>
                        </div>
                        <div class="col">
                                {{Patient.treatyNumber}}
                        </div> 
                </div>
        </div>
</div>
<div class="row ml-1">
    <div class="col-4">
            <div class="row">
                    <div class="col">
                            <strong>Residency:</strong>
                    </div>
                    <div class="col">
                            {{Patient.currentResidentStatus}}
                    </div> 
            </div>
    </div>
    <div class="col">
            <div class="row">
                    <div class="col">
                            <strong>Spec Ben:</strong>
                    </div>
                    <div class="col">
                            {{SpecialBenefits}}
                    </div> 
            </div>
    </div>
</div>
<div class="row ml-1 mb-1">
        <div class="col-4">
                <div class="row">
                        <div class="col">
                                <strong>Pall Care:</strong>
                        </div>
                        <div class="col">
                                {{Patient.longTermCareInd}}
                        </div> 
                </div>
        </div>
        <div class="col">
                <div class="row">
                        <div class="col">
                                <strong>LTC:</strong>
                        </div>
                        <div class="col">
                                {{Patient.longTermCareInd}}
                        </div> 
                </div>
        </div>
</div>
</div>
</div>
 </div>

<div class="row no-gutters mt-2" v-if="Patient!=null">
<div class="col-6 pr-2">
<h4><small class="text-muted Subtitle"><b><i class="fas fa-question-circle my-1"></i>Program Information: {{Patient.highestProgramCode}} is highest Priority as of: {{asOf}}
</b></small></h4> 
<PatientCovProgramInfo :Data="Patient.programInformation" ></PatientCovProgramInfo>
</div>
<div class="col-6 pr-2">
<h4><small class="text-muted Subtitle"><b><i class="fas fa-history my-1"></i>Admin: Residency History</b></small></h4>
<PatientCovResidencyInfo :Data="Patient.residencyInformation" ></PatientCovResidencyInfo>
</div>
</div>
</div>
</template>

<script>
import Vue from 'vue';
import axios from 'axios';
import Card from "@/Common/Card.vue";
import CardBody from "@/Common/CardBody.vue";
import moment from 'moment';
import PatientCovProgramInfo from '@/components/DPEBB/Administrator/PatientCovProgramInfo.vue'
import PatientCovResidencyInfo from '@/components/DPEBB/Administrator/PatientCovResidencyInfo.vue'
export default {
    props:{
      PropHSN:'',
      AppName:''
    },
    data:function(){
            return{
                    HSN:'',
                    Patient:null,
                    SpecialBenefits:'',
                    isValid:false,
                    DOB:'',
                    asOf:''
            } 
        },
        components:{
                Card,
                CardBody,
                PatientCovProgramInfo,
                PatientCovResidencyInfo
        },
        
        computed:{
                UserName(){
                return !this.$store.getters.GetCurrentUser ? false : this.$store.getters.GetCurrentUser;
                },
        },
        methods:{
            ClosePopup: function() {     
            this.$root.$emit('bv::hide::modal', 'modal-HSN-Cov', '#btnShow') 
            
            },
            loadTables(){
            var vm = this;
            var params = new URLSearchParams();
            vm.Patient = null;
            params.append('HSN', this.HSN);
            axios.get('SaskHealthApi/Host/GetPatientCoverage', { headers: { 'Authorization': 'Bearer ' + localStorage.access_token },params})
            .then(function (response) {
                    vm.showModal = false;                    
                    vm.Patient = response.data;
                    vm.SpecialBenefits = vm.Patient.specialBenefitsInformation.length==0?"N":"Y";
                    vm.DOB =moment(vm.Patient.birthDate).format('YYYY/MM/DD');
                    vm.asOf = moment(new Date()).format('YYYY/MM/DD');
                    vm.isValid = true;
            })
            .catch(function (er) {
                console.log(er)
                vm.isValid = false;
                vm.showModal = true;
                vm.Patient =null;
            }) 

            },
            disableSearch(){
            // this.tableData = [];
            this.isValid = false;
            }
        },
        created: function(){
            this.HSN=this.PropHSN;
            this.loadTables();
        },
}
</script>

<style>

</style>
