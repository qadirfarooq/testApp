import Vue from 'vue';
import Router from 'vue-router';
import Login from '../components/Login';
import { store } from '../Store/store';
Vue.use(Router);
export default new Router( {mode: 'history',
  routes: [
    {
      name: 'home',
      path: '/',
      components: { default: Login}
    },
   
    {
      path: '*',
      name: 'all',
      component: Login
    }
  ]

});
