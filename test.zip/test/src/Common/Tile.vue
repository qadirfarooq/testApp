<template>
  <div class="mx-0 mt-0 mb-3">
    <slot></slot>
  </div>
</template>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss">
</style>
