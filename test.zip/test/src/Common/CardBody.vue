<template>
  <div class="card-body">
    <slot></slot>
  </div>
</template>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss">
.card-body > .subsection {
  padding: 0 15px;
} 
.card-body > .subsection > .sub-title {
  font-size: 16px;
  font-weight: bold;
} 
.card-body ul {
  margin: 8px 0;
}

.card-body ul > li {
  list-style-type: disc;
}

@media screen and (max-width: 768px) {
  .card-body {
    padding: 15px 7px;
  }
}

@media print {
  .card-body {
    padding: 0;
  }
}
</style>