<template>
  <div>
    <div class="text-center justify-content-center row ">
        <bar-loader class="text-center justify-content-center col-12" :color="color" :loading="loading" :size="Ringsize" :sizeUnit="unit"></bar-loader>          
    </div>
    <div class="row no-gutters Hometitle"> 
        <div class="col-sm-12">  
        <h4><small class="text-muted">  <strong>  Session Timeout :</strong> </small></h4> 
        </div> 
    </div>
    <div class="row no-gutters Hometitle"> 
        <div class="col-sm-12"> 
        For Security reasons your session timed out after 15 minutes of inactivity. You will be redirected to the login page in <strong class="redBig"> {{ second }} </strong>  seconds. 
        </div> 
    </div>
    <div class="row no-gutters"> 
         <beat-loader class="text-center justify-content-center col-12" :color="color" :loading="loading" :size="15" :margin="margin" ></beat-loader>          
    </div>

  </div>
</template>
<script>
 
import { BarLoader } from '@saeris/vue-spinners'; //PropagateLoader
import { BeatLoader } from '@saeris/vue-spinners'; //PropagateLoader
export default {
  name: 'app',
  props : 
          {
            
        } ,
  data () {
    return {
        time: 10000,
       layout: 'div', 
        loading: true,
        size: 150,
        Ringsize: 30,
        Risesize: 12,
        margin :'2px',
        unit: 'px',
        color:'#bada55',
     } 
  }, 
   computed: {
        second() {
            return this.time / 1000;
        }, 
   },
     watch: { 
 
    },
    created (){
    let timerId = setInterval(() => {
      this.time -= 1000;
      if (!this.$store.state.idleVue.isIdle) clearInterval(timerId);
      if (this.time < 1) {
        clearInterval(timerId);
        // Your logout function should be over here
        console.log(' out ')
        this.$store.state.message = "Your session has expired. Please Login again to restore your session.";
        this.$store.state.ShowLoginMsg = true;
        this.$store.dispatch('Logout');
      }
    }, 1000);
    },
      mounted: function () {
 
    },
  components: {
   BarLoader,
   BeatLoader
  },
  methods: { 
  } 
}
</script> 
 