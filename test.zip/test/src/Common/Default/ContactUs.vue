<template>
    <div>
    <span class="Maintitle"> 
    <h4><small class="text-muted">
             <i class="fas fa-envelope"></i> <strong> Contact Us : </strong> 
           
    </small></h4>  
    </span> 
 
    <Card>
      <CardBody>
           All General inquiries should be directed to:
        <div class="row mt-1">  
   
        </div>

      </CardBody>
        </Card>
</div>
</template>
<script>
import axios from 'axios'
import axiosauth from '@/axios-auth'
import Card from "@/Common/Card.vue";
import CardBody from "@/Common/CardBody.vue";
import TileNote from "@/Common/TileNote.vue";
import TileCard from "@/Common/TileCard.vue";
import { mapGetters } from 'vuex';
export default  {
     props:{
        error:''
     }, //['ServiceID','msg', 'MenuArray','error'],
  data: function () {
      
    return {
 
        }
    },
    components: { 
              Card,
            CardBody,
            TileNote,
            TileCard           
        },
    mounted: function () {
    this.$nextTick(function () {  
    })
    },
    created: function() { 
 
    },
    computed:{
        ...mapGetters({
                GetMessage: 'GetMessage',
                ShowLoginMsg: 'ShowLoginMsg'
            }),
        errorMsg: {
           get(){
             return this.GetMessage
           },
           set(newName){
             return newName
           } 
        }, 
        ...mapGetters({
                 
                ShowLoginMsg: 'ShowLoginMsg'
            }),
        ShowMsg: {
           get(){
             return this.ShowLoginMsg
           },
           set(val){
             return val
           } 
        },
    },
    watch: {
    ShowMsg: function (val) {
        //console.log (val)
        if(val)
        {
            //this.showMsg1("Seesion","","Con")
        }
        },
    },
    methods: {
    HideMsg: function(val){
        this.$store.dispatch('ResetLoginMSg');
        this.$bvModal.hide('modal-sm');
        },
    showMsg1(msg,data,Title) {
        this.boxTwo = ''
        this.$bvModal.msgBoxOk(msg, {
        title: Title,
        size: 'md',
        buttonSize: 'md',
        okVariant: 'primary',          
        okTitle: 'Close', 
        footerClass: 'p-2',
        hideHeaderClose: true,
        hideHeaderCancel: true,
        centered: true, 
        }); 
      }, 
    },
}
</script>
<style scoped>

</style>

