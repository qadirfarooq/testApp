<template>
<div>
<span class="ml-2">
  <!-- <i class="fas fa-clinic-medical"></i> -->
  <!-- <i class="fas fa-hand-holding-medical"></i> -->
  <!-- <i class="fas fa-hand-holding-medical"></i> -->
  <i class="fas fa-laptop-medical"></i>
   <span class="text-muted ml-3" style ="font-size: 1.0rem;" ><strong>TEST</strong></span>
 
</span>
  
  <ul class="main-menu" > 
    <li :id="'li' +item.menuitem" v-for="item in GetMainMenu" :key="item.menuitems">
      <router-link v-if="item.iconClass.search('fab') =='-1'" :to="{path: item.pageUrl}" :id="'a'+item.Menuitem" :exact="item.exact">  
        <i  class="fas" :class="item.iconClass"/> <span> {{item.menuitem}}</span>
      </router-link>
      <router-link v-else :to="{path: item.pageUrl}" :id="'a'+item.Menuitem" :exact="item.exact">  
         <i  class="fab" :class="item.iconClass"/> <span> {{item.menuitem}}</span>
       </router-link>
     </li> 
    </ul>
</div>
</template>

<script>
export default {
data: function () {
      return { 
          showbar : false,           
          menuitems:"",   
          //isToggled: false,       
        }
    },
    computed: {
         
          IsAuth () {  
              //alert(this.$store.getters.IsAuth)
             return this.$store.getters.IsAuth;
          },
        GetMainMenu () { 
                if(this.$store.getters.IsAuth)
                {
                // alert('computed')
                    
                    this.menuitems= this.$store.getters.GetMainMenu;
                    //alert(this.menuitems)
                return this.menuitems;
                }        
            },
        //  isToggled(){
        //         return this.$store.getters.GetToggle;
        //     }
    },
     watch: { 
      IsAuth : function()
      {
        return this.$store.getters.IsAuth;
      },
       
    },
    created: function(){
      //alert('At sidebar ')
      //console.log('at sidebar created')
       var vm = this; 
        // if(this.$store.getters.IsAuth)
        //    {
        //      this.$store.dispatch('GetMenuItems',1);
        //       vm.menuitems= vm.$store.getters.GetMainMenu;
        //       alert( vm.menuitems)
        //    }
    },
    beforeMount: function() {
        //   console.log('at sidebar before created')
        //    if(this.$store.getters.IsAuth)
        //    {
        //       var vm = this; 
        //       var ServiceID = this.$store.getters.GetServiceID;
        //       this.$store.dispatch('GetMenuItems',ServiceID);
        //       vm.menuitems= vm.$store.getters.GetMainMenu;
        //       console.log(vm.menuitems);  
        //     } 
    },
    methods: {
     
   
  },
}
</script> 
<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss">
.main-menu > li > a:hover,
.main-menu > li.active > a {
  // background-color:#f7f7f7;
  // border-left: 5px solid #f7f7f7; 
   background-color:#B9D9EB;
   border-left: 5px solid #a09573de;
  
}
.main-menu > li > span {
  background-color: #f7f7f7;
  border-left: 5px solid #FBDD40 !important;
  padding: 0px 5px 5px 5px;
  display: block;
  //font-weight: 500;
  position: relative;
  color: #4c4c4c;
  border-left: 5px solid #fff;
  -o-transition: color 0.2s linear, background 0.2s linear;
  -moz-transition: color 0.2s linear, background 0.2s linear;
  -webkit-transition: color 0.2s linear, background 0.2s linear;
  transition: color 0.2s linear, background 0.2s linear;
}
.main-menu {
  padding-left: 0;
  margin: 0;
}
.main-menu .active > a,
.main-menu a.active,
.main-menu a:hover {
  color: #262626;
}
.main-menu > li > a {
  padding: 7px 10px 10px 40px;
  display: block;
  font-weight: 500;
  position: relative;
  color: #046A38;
  border-left: 5px solid #fff;
  -o-transition: color 0.2s linear, background 0.2s linear;
  -moz-transition: color 0.2s linear, background 0.2s linear;
  -webkit-transition: color 0.2s linear, background 0.2s linear;
  transition: color 0.2s linear, background 0.2s linear;
}
.main-menu > li > a > i {
  position: absolute;
  left: 7px;
  font-size: 19px;
  top: 1px;
  width: 10px;
  text-align: center;
  padding: 10px 0;
}

.main-menu li > a.router-link-active {
  background-color: #F5F5F5;
  border-left: 5px solid #FBDD40 !important;
}
 
</style>

