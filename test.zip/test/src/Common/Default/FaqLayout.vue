<template>
  <div id="LoginLayout">
       <AppHeader/>
          <section id="main" class="ml-1">
         
             <slot></slot> 
          
          <!-- <aside > 
          </aside>
          <div class="clsSidebar"></div>
            <section id="content"> 
              <div class="container">
              <transition name="fade" mode="out-in">
                <slot></slot> 
              </transition>
              </div>
              </section>  -->
          </section>
      <AppFooter/>
   </div>
</template> 
<script>
import AppHeader from '@/Common/Default/FaqHeader.vue'; 
import AppFooter from '@/Common/Default/AppFooter.vue';
export default {
 name: "FaqLayout",
  data() {
    return {
      
    };
  },
  components: {
    AppHeader, 
    AppFooter
  },
  computed: { 
         
    },
     watch: {  
    },
    methods: {
     
    },
  created() {
    
  },
};
</script>
 <style lang="scss"> 
</style>
