export const PopUpVariant = {
      //variants: ['primary', 'secondary', 'success', 'warning', 'danger', 'info', 'light', 'dark'],
      // headerBgVariant: 'dark',
      // headerTextVariant: 'light',
      // bodyBgVariant: 'light',
      // bodyTextVariant: 'dark',
      // footerBgVariant: 'warning',
      // footerTextVariant: 'dark' 

      headerBgVariant: 'info',
      headerTextVariant: 'dark',
      bodyBgVariant: 'white',
      bodyTextVariant: 'dark',
      footerBgVariant: 'warning sm btn-block disabled',
      footerTextVariant: 'dark' 

};