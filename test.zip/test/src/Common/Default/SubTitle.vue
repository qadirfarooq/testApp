<template>
<div>
<span class="Maintitle"> 
  <i :class="MainIconClass"></i>
  <strong> {{Appname}}:</strong> 
  <span class="float-right"><strong>User ID: {{UserName}}</strong></span>
 </span>  
<div class="row no-gutters Hometitle pl-2"> 
    <div class="col-sm-8">            
    <h4><small class="text-muted"><slot name="header"></slot></small></h4> 
    </div> 
    <div class="col-sm-4">
    <button type="button" v-if="!MainPage"  v-on:click="GotoHome" class="ml-1 btn btn-primary btn-sml float-right" aria-label="First group"><i class="fas fa-home"></i> Home</button>
    <button v-if="ShowHomeBtn"  v-on:click="GotoMain"  type="button" class="btn btn-outline-primary btn-sml float-right" aria-label="Second group"><i class="fas fa-clinic-medical"></i> Main Menu</button> 
    </div>  
</div>
</div>
</template>
<script> 
import Vue from 'vue';
import { HomePaths } from '@/Common/Default/HomePaths';
import axios from 'axios';
export default  {
     props:{
        //HomePath:'',
        ServiceID:'',
        MainPage: false
     },  
  data: function () { 
    return {
        MainPath :'/DPEBB/MainHome',
        HomePath:'',
        ShowHomeBtn:false,
        HomePaths:HomePaths,
        MainIconClass:'',
        Appname: '', 
    }
  },
  created: function() { 
      this.CanAccessAllApp();
      this.MainIcon();
      //console.log('ServiceID: '+ this.ServiceID)
      if(this.ServiceID==1)
      {
         this.HomePath = this.HomePaths.Dental;
      }
      else if(this.ServiceID==2)
      {
         this.HomePath = this.HomePaths.Medical;
      }
      else if(this.ServiceID==3)
      {
         this.HomePath = this.HomePaths.Optical;
      }
       else if(this.ServiceID==4)
      {
         this.HomePath = this.HomePaths.Hearing;
      }
        else if(this.ServiceID==5)
      {
         this.HomePath = this.HomePaths.Podiatry;
      }
      else if(this.ServiceID==6)
      {
         this.HomePath = this.HomePaths.Admin;
      }
      //console.log('homepath : '+ this.HomePath)
    },
    computed:{
        UserName(){
            return !this.$store.getters.GetCurrentUser ? false : this.$store.getters.GetCurrentUser;
        },
    },
  methods: {
      GotoHome: function () {
          this.$router.push(this.HomePath)
        },
        GotoMain: function () {
          this.$router.push(this.MainPath)
        }, 
        CanAccessAllApp(){
            var vm = this;
              axios.get('SaskHealthApi/Codes/AccessAllApp', { headers: { 'Authorization': 'Bearer ' + localStorage.access_token }})
             .then(function (response) {
                   vm.ShowHomeBtn = response.data; 
                })
            .catch(function (er) {
                console.log(er)
            }).then(function()
            {  
            })
        },
        MainIcon(){ 
           var vm = this;
           var params = new URLSearchParams();            
           params.append('ServiceID', this.ServiceID);
            axios.get('SaskHealthApi/Codes/GetServiceIcon?_='+Date.now(), { headers: { 'Authorization': 'Bearer ' + localStorage.access_token }, params})
            .then(function (response) {
              //console.log(response.data)
                   vm.MainIconClass=response.data[0].icon;
                   vm.Appname=response.data[0].description + ' Application';
                })
            .catch(function (er) {
                console.log(er)
                }).then(function () {
                  if(vm.ServiceID ==6)
                  {
                    vm.Appname= "TEST Administration Application";
                  }
            }); 
        } 
    }
}
</script>

<style>

</style>
