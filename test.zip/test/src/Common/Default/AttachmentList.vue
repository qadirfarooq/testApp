<template>
  <div>
    <ul v-if="tempAttachments.length > 0" class="ulClass m-0 p-0 mb-0">
      <li v-for="tempAttachment in tempAttachments" :key="tempAttachment._id" class="liClass">
        <div class="">
          <div class="file-name display-flex align-left"> 
            
            <p class="file-details" ref="attachmentTitle"><span class=""><i class="fas fa-eye" ></i></span>{{ tempAttachment.title }}<b>: {{parseInt(Math.floor((tempAttachment.size) / (1000)))}} KB </b>
           
            <span class="ml-3"><i class="fas fa-trash-alt"></i></span></p>
          </div>
        </div> 
      </li>
    </ul>

          <!-- <span v-if="checkProgress(tempAttachment)" class="upload-prgress">
              {{ `${tempAttachment.progress} %` }}
            </span>  -->
  </div>
</template>

<script>
export default {
  name: "AttachmentList",
  methods: {
    checkProgress(attachment) {
        console.log(attachment.progress)
      return attachment.progress === null ? false : true;
    }
  },
  props: {
    tempAttachments: {
      type: Array
    },
    attachments: {
      type: Array
    }
  }
};
</script>

<style scopped>
.ulClass {
  display: flex;
  flex-wrap: wrap;
  list-style: none;
  padding: 0px ! important;
}
.liClass {
  border: 1px solid;
  margin-bottom: 5px;
  border-radius: 5px;
  margin-right: 5px;
  padding: 0 5px;
}
.file-name {
  min-width: 150px;
  font-size: 13px;
}
.uploaded-date {
  font-size: 12px;
}
.upload-progress {
  font-size: 12px;
}
.file-info {
  display: flex;
  justify-content: space-between;
  margin-bottom: 0px !important;
}
.file-details { 
  margin-bottom: 0px !important;
}
 
</style>
