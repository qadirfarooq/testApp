<template>
  <footer class="d-print-none">
    Copyright &copy; {{cYear()}} - Government of TEST: TEST and Extended Benefits Branch
  </footer>
</template>
<script>
export default { 
     props :
     {}
     ,  
   data: function () {
      return {            
                   
        }
    },
    methods: {
        cYear() {
      return new Date().getFullYear();
     }
    },
     
}
</script> 
<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
footer {
  color: #a2a2a2;
  position: fixed;
  bottom: 0;
  width: 100%;
  padding-top: 3px;
  padding-bottom: 3px;
  text-align: center;
  font-size: 0.9em;
  background-color: #f3f3f3;
}
footer .f-menu {
  display: block;
  width: 100%;
  padding-left: 0;
  list-style: none;
  margin-left: -5px;
  margin-top: 8px;
}
footer .f-menu > li {
  display: inline-block;
  padding-left: 5px;
  padding-right: 5px;
}
footer .f-menu > li > a {
  color: #a2a2a2;
}
footer .f-menu > li > a:hover {
  color: #777;
}

@media (min-width: 1200px) {
  footer {
    padding-left: 268px;
  }
}

@media screen and (max-width: 767.98px) {
  footer {
    display: none !important;
  }
}
</style>
