export const HomePaths = { 
    Dental: '/Dental/Home',
    Medical: '/MedicalSupply/Home',
    Hearing: '/Hearing/Home',
    Podiatry: '/Podiatry/Home',
    Optical: '/Optical/Home',
    Admin: '/DPEBB/Home',
    DPEBB: '/DPEBB/MainHome' 

};