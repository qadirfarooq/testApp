<template> 
  <header class="clearfix d-print-none" data-my-theme="saskGreen">
   <a id="app-logo" href="/" target="_blank">
   
    </a> 
    <ul>
      <li class="menu-trigger d-xl-none" id="BtnToggle">
        <input type="checkbox" id="chkTrigger" v-model="checked" />
        <label id="menuTriggerLbl" for="chkTrigger"></label>
        <div class="line-wrap">
          <div class="line top"></div>
          <div class="line center"></div>
          <div class="line bottom"></div>
        </div>
      </li>
      <li class="app-name">
        <a href="/">TEST</a>
      </li>
       <!-- <li class="app-text-keep float-right" v-if="IsAuth" v-on:click="Logout">
        <router-link v-bind:to="{name: 'home'}" >
          <i class="fas fa-sign-out-alt"></i>Log Out</router-link>
      </li>
       <li class="app-text-keep float-right" v-if="!IsAuth">
        <router-link v-bind:to="{name: 'home'}">
         <i class="fas fa-sign-in-alt" aria-hidden="true"></i><i class="fas fa-user-circle"></i>
        Log In</router-link>
           
      </li> -->
<!--    
      <li class="app-text-keep float-right">
        <router-link v-bind:to="{name: faq}">
           <i class="fas fa-question"> Faq</i> </router-link>
      </li>
      <li class="app-text-keep float-right">
        <router-link v-bind:to="{name: contactus}">
          <i class="fas fa-envelope"></i>Contact Us</router-link>
      </li>    -->
    </ul>
  </header>
</template>
<script>
 
export default { 
     props : 
          {            
            chkVal:false,
            //chkStatus: false,
            ServiceID: {
                type: Number,
                required:false             
            }
        } ,
  data: function () {
      return {    
          chkStatus: false,        
          menuitems:[],
          faq:'',
          contactus:''   
        }
    },
    components:{
        
    },
      created: function() { 
        this.faq = this.$store.getters.GetFaqLink; 
        console.log('faq = ' +  this.faq)
        this.contactus = this.$store.getters.GetContactUsLink;
        console.log('contact us ' + this.contactus)
    },
    methods :{
        Logout:function()
        {
            this.$store.dispatch('Logout');
        }
    },
    computed: {
      checked: {
        // getter
        get: function () {
          //var vm = this;
         // alert('at header get')
         // alert(this.$store.getters.GetToggle)
           return this.$store.getters.GetToggle;
            //return this.chkStatus;
        },
        // setter
        set: function (val) {
          //this.$emit("menuToggle", val); 
           //alert('at header set')
           //alert(val)          
          this.$store.dispatch('ChangeToggle',val);
          //this.chkStatus = val;
        },       
      },
      IsAuth : function()
        { 
          return this.$store.getters.IsAuth;
        },
    }, 
    watch: { 
     
    }
}
</script>
<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
header {
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.3);
  top: 0;
  left: 0;
  width: 100%;
  min-height: 70px;
  padding: 0 20px;
  position: fixed;
  user-select: none;
  z-index: 11;
}

header ul {
  margin-bottom: 0;
  line-height: 70px;
  padding: 0;
  position: relative;
}

header ul > li:not(.float-right) {
  float: left;
}

header ul li {
  display: inline-block;
  margin-right: 1rem !important;
}

header #chkTrigger {
  display: none;
  position: absolute;
}
header #chkTrigger:checked ~ #menuTriggerLbl:before {
  -webkit-transform: scale(1);
  -ms-transform: scale(1);
  -o-transform: scale(1);
  transform: scale(1);
}
header #chkTrigger:checked ~ .line-wrap {
  -webkit-transform: rotate(180deg);
  -ms-transform: rotate(180deg);
  -o-transform: rotate(180deg);
  transform: rotate(180deg);
}
header #chkTrigger:checked ~ .line-wrap > .line.top {
  width: 12px;
  transform: translateX(8px) translateY(1px) rotate(45deg);
  -webkit-transform: translateX(8px) translateY(1px) rotate(45deg);
}
header #chkTrigger:checked ~ .line-wrap > .line.bottom {
  width: 12px;
  transform: translateX(8px) translateY(-1px) rotate(-45deg);
  -webkit-transform: translateX(8px) translateY(-1px) rotate(-45deg);
}

header .menu-trigger {
  cursor: pointer;
  margin-left: -5px;
  padding: 17px 0px;
}

header #menuTriggerLbl {
  width: 58px;
  height: 36px;
  top: 17px;
  left: -5px;
  position: absolute;
  z-index: 5;
}
header #menuTriggerLbl:before {
  content: "";
  position: absolute;
  top: 50%;
  left: 50%;
  width: 45px;
  height: 45px;
  margin-top: -22px;
  margin-left: -22px;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.22);
  -webkit-transition: all;
  -o-transition: all;
  transition: all;
  -webkit-transition-duration: 0.3s;
  transition-duration: 0.3s;
  transform: scale(0);
  z-index: 0;
}

header .line-wrap {
  height: 12px;
  margin: 12px 20px;
  -webkit-transition: all;
  transition: all;
  -webkit-transition-duration: 0.3s;
  transition-duration: 0.3s;
  width: 18px;
  /* -webkit-transition: all;
  transition: all; */
}
header .line-wrap .line {
  width: 18px;
  -webkit-transition: all;
  transition: all;
  height: 2px;
  /* transition: all;
  -webkit-transition: all; */
  transition-duration: 0.3s;
  -webkit-transition-duration: 0.3s;
  background-color: #fff;
}
header .line-wrap .line.center {
  margin: 3px 0;
}

header a {
  color: #fff;
  text-transform: uppercase;
  display: block;
  padding: 0px 10px;
}
header a:hover,
header .btn-link:hover {
  color: #fff;
}
header .btn-link {
  color: #fff;
  text-transform: uppercase;
  display: block;
}

header a.router-link-active {
  background-color: #006537;
  border-left: 0px !important;
}

header #app-logo {
  position: relative;
  float: left;
  margin: 0px 50px 0 0px;
  font-size: 3.1rem;
  line-height: 60px;
}
header #app-logo span {
  vertical-align: baseline;
}

/* header #app-logo { */
/* background-image: url("../../MyCss/images/SK-Government-Logo-without-color.png");
  background-position: left center;
  background-repeat: no-repeat;
  background-size: auto 50px;
  float: left;
  width: 120px;
  height: 70px;
  margin: 0px 50px 0 10px;
  z-index: 1000; */
/* } */

header .btn {
  padding: 0;
  line-height: 70px;
  border: 0px;
  vertical-align: middle;
}

@media (max-width: 1199.98px) {
  header #app-logo {
    float: right;
    margin-right: 0;
  }
}

@media screen and (max-width: 884px) {
  header .app-text {
    display: none !important;
  }
}

@media screen and (max-width: 627px) {
  header .app-name {
    display: none !important;
  }

  header .app-text-keep {
    margin-right: 0 !important;
  }
}

@media screen and (max-width: 381px) {
  header #app-logo {
    display: none !important;
  }
}
</style>
