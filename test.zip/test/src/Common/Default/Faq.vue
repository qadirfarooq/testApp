<template>
<div id="faq"> 
           <span class="Maintitle"> 
            <i class="fas fa-clinic-medical"></i>
            <strong> Medical Supplies and Services Claims Application (TEST) </strong> 
       </span> 
       <span class=""> 
        <h4><small class="text-muted">
                <i class="far fa-question-circle"></i>
                <strong> Frequently Asked Questions : </strong> 
        </small></h4>  
        </span> 
<div class="ml-0">
 
<!-- <div v-b-toggle.collapse-a.collapse-b class="card-title pointer row  ml-1 Maintitle">  -->
<div v-b-toggle.collapse-1 class="card-title pointer row  ml-1 mr-1 Maintitle">
     <kbd>1</kbd><span style="text-decoration:underline">What TEST stands for?</span>
</div>
<b-collapse id="collapse-1" class="mb-2 ml-1">
    <b-card>Medical Supplies and Services Claims Application</b-card>
</b-collapse>
 <div v-b-toggle.collapse-2 class="card-title pointer row  ml-1 mr-1 Maintitle">
     <kbd>2</kbd><span style="text-decoration:underline">What TEST stands for?</span>
</div>
<b-collapse id="collapse-2" class="mb-2 ml-1">
    <b-card>Medical Supplies and Services Claims Application</b-card>
</b-collapse>
<div v-b-toggle.collapse-3 class="card-title pointer row  ml-1 mr-1 Maintitle">
     <kbd>3</kbd><span style="text-decoration:underline">What TEST stands for?</span>
</div>
<b-collapse id="collapse-3" class="mb-2 ml-1">
    <b-card>Medical Supplies and Services Claims Application</b-card>
</b-collapse>
<div v-b-toggle.collapse-4 class="card-title pointer row  ml-1 mr-1 Maintitle">
     <kbd>4</kbd><span style="text-decoration:underline">What TEST stands for?</span>
</div>
 <b-collapse id="collapse-4" class="mt-2 ml-1">
    <b-card>Medical Supplies and Services Claims Application Medical Supplies and Services Claims Application Medical Supplies and Services Claims Application Medical Supplies and Services Claims Application Medical Supplies and Services Claims Application Medical Supplies and Services Claims Application Medical Supplies and Services Claims Application Medical Supplies and Services Claims Application Medical Supplies and Services Claims Application Medical Supplies and Services Claims Application Medical Supplies and Services Claims Application</b-card>
  </b-collapse>
</div>
 <!-- <div role="tablist">
    <b-card no-body class="mb-1">
      <b-card-header header-tag="header" class="p-1" role="tab">
        <b-button block v-b-toggle.accordion-1 variant="primary">Accordion 1</b-button>
      </b-card-header>
      <b-collapse id="accordion-1" visible accordion="my-accordion" role="tabpanel">
        <b-card-body>
          <b-card-text>I start opened because <code>visible</code> is <code>true</code></b-card-text>
          <b-card-text>{{ text }}</b-card-text>
        </b-card-body>
      </b-collapse>
    </b-card>

    <b-card no-body class="mb-1">
      <b-card-header header-tag="header" class="p-1" role="tab">
        <b-button block v-b-toggle.accordion-2 variant="info">Accordion 2</b-button>
      </b-card-header>
      <b-collapse id="accordion-2" accordion="my-accordion" role="tabpanel">
        <b-card-body>
          <b-card-text>{{ text }}</b-card-text>
        </b-card-body>
      </b-collapse>
    </b-card>

    <b-card no-body class="mb-1">
      <b-card-header header-tag="header" class="p-1" role="tab">
        <b-button block v-b-toggle.accordion-3 variant="info">Accordion 3</b-button>
      </b-card-header>
      <b-collapse id="accordion-3" accordion="my-accordion" role="tabpanel">
        <b-card-body>
          <b-card-text>{{ text }}</b-card-text>
        </b-card-body>
      </b-collapse>
    </b-card>
  </div> -->
</div>
</template>
<script> 
 
 import Card from "@/Common/Card.vue";
import CardBody from "@/Common/CardBody.vue";
import TileNote from "@/Common/TileNote.vue";
import Subtitle from '@/Common/Default/SubTitle.vue'; 
import Accordion from '@/Common/Default/Accordion.vue'; 

export default  {
     props:{
        
     },  
  data: function () {
      
    return {
 	         text: ''
        }
    },
    components: { 
              Card,
            CardBody,
            TileNote,
            Subtitle ,
            Accordion           
        },
    mounted: function () {
    this.$nextTick(function () {  
    })
    },
    created: function() { 
       // this.$emit('update:layout', FaqLayout);
        //console.log('at Dental Main home')
        //this.menuitems = this.$store.getters.GetMainMenu; 
    },
    computed:{  
    },
    watch: { 
    },
    methods: {
    HideMsg: function(val){
 
        },
    showMsg1(msg,data,Title) {
        this.boxTwo = ''
        this.$bvModal.msgBoxOk(msg, {
        title: Title,
        size: 'md',
        buttonSize: 'md',
        okVariant: 'primary',          
        okTitle: 'Close', 
        footerClass: 'p-2',
        hideHeaderClose: true,
        hideHeaderCancel: true,
        centered: true, 
        }); 
      }, 
    },
}
</script>
<style scoped>
 
</style>

