<template>
  <div id="LoginLayout">
       <AppHeader/>
          <section id="main">
          <aside > 
          </aside>
          <div class="clsSidebar"></div>
            <section id="content"> 
              <div class="container">
              <transition name="fade" mode="out-in">
                <slot></slot> 
              </transition>
            </div>
              </section> 
          </section>
      <AppFooter/>
   </div>
</template> 
<script>
import AppHeader from '@/Common/Default/LoginHeader.vue'; 
import AppFooter from '@/Common/Default/AppFooter.vue';
export default {
 name: "LoginLayout",
  data() {
    return {
      
    };
  },
  components: {
    AppHeader, 
    AppFooter
  },
  computed: { 
         
    },
     watch: {  
    },
    methods: {
     
    },
  created() {
    
  },
};
</script>
 <style lang="scss" <style lang="less" scoped>
 
 </style>>
.container,
.container-fluid {
  /*padding-left: 15px;
    padding-right: 15px;
    margin-right: auto;
    margin-left: auto;*/
  padding-left: 15px;
  padding-bottom: 5px;
}

#content {
  height: calc(100vh - 100px);
  //height: calc(100vh - 80px);
  padding-top: 10px;
  position: relative;
  //border-right: 1px solid #eee;
  /*overflow-y: auto;
  border-right: 1px solid #eee;*/
  //padding-left: 230px !important;
}

#content .container {
  max-width: 100%;
   padding-left:5px !important;
}
#content ul {
  padding-left: 1.9em;
}
#content ol {
  padding-left: 1.4em;
}
#content li {
  margin-bottom: 0.4rem;
}
#content a {
  font-weight: bold;
}
#content a:hover {
  text-decoration: underline;
}

.clsSidebar {
  position: fixed;
  width: 100%;
  height: 100%;
  left: 0;
  top: 0;
  z-index: 9;
  cursor: pointer;
  display: none;
}

#sidebar {
  padding: 5px 0;
  position: fixed;
  background: #fff;
  width: 230px;
  height: calc(100% - 70px);
  top: 70px;
  overflow-y: auto;
  transition: all;
  -webkit-transition-duration: 0.3s;
  transition-duration: 0.3s;
  z-index: 10;
  box-shadow: 0 1px 1px rgba(0, 0, 0, 0.1);
  border-right: 1px solid #eee;
}

#main {
  position: relative;
}

#main {
  /*padding-bottom: 60px;*/
  padding-top: 70px;
  height: calc(100vh - 30px);
}
.Maintitle   {
  background-color: #f7f7f7;
  border-left: 5px solid #ff9800 !important;
  padding: 0px 5px 5px 5px;
  display: block;
  //font-weight: 500;
  position: relative;
  font-size: 18px;
  /* margin: 10px 0; error*/ 
  color: #4c4c4c;
  border-left: 5px solid #fff;
  -o-transition: color 0.2s linear, background 0.2s linear;
  -moz-transition: color 0.2s linear, background 0.2s linear;
  -webkit-transition: color 0.2s linear, background 0.2s linear;
  transition: color 0.2s linear, background 0.2s linear;
}
@media (min-width: 1200px) {
  #content:not(.content-alt) {
    padding-left: 230px !important;
    //padding-left: 0 !important;
    padding-right: 15px;
  }
}

@media (max-width: 1199.98px) {
  #sidebar {
    -webkit-transform: translate3d(-240Sx, 0, 0);
    transform: translate3d(-240px, 0, 0);
    box-shadow: 0 0 20px rgba(14, 18, 21, 0.38);
  }

  #sidebar.toggled {
    -webkit-transform: translate3d(0, 0, 0);
    transform: translate3d(0, 0, 0);
  }
  .maskToggled {
    display: block;
  }
}

@media screen and (max-width: 767.98px) {
  #content {
    height: calc(100vh - 80px);
  }
  #content .container {
    padding-left: 0px;
    padding-right: 7px;
  }
}

@media print {
  #main {
    padding-top: 0px;
  }
  #content {
    padding-left: 0 !important;
  }
  #content > .container {
    padding: 0 !important;
  }
}
</style>
