<template>
<div>
<div class="select-list-wrapper">
  <header class="select-list-actions is-clearfix">
      <p class="control" v-if="selectedOptions.length > 0">
        <a href="#" role="button" class="button is-link" @click="clear"> Clear selected </a>
      </p>
      <p class="control">
        <input class="input" v-model="filterText" type="text" placeholder="Filter list">
      </p>
  </header>
  <div class="select-list" v-if="filteredOptions.length > 0">
    <toggle-button
            v-for="option in filteredOptions"
            :text="option.label"
            :value="option.value"
            :selected="option.selected"
            class="select-item"
            @toggle="onToggle($event)"
            ></toggle-button>
  </div>
  <div v-else>No items to display</div>
</div>

</div>
</template>
<script >
import Vue from 'vue'
export default  {
  data: function () {
    return {
        brands: ["Yamaha", "Honda", "Suzuki", "Kawasaki", "Piaggio", "Aprilia", "BMW", "Peugeot", "KTM", "Ducati", "Cagiva", "Harley Davidson", "Polaris", "Vespa", "Hyosung", "Husaberg", "Husqvarna", "Daelim", "Moto Guzzi", "Triumph"],
        selectedBrands: []
      }
  },
  components: {


      },
    methods: {
       onChange(changed) {}
    },
    computed:{
      },
}
</script>



Vue.component('select-list', {
  template: `
<div class="select-list-wrapper">
  <header class="select-list-actions is-clearfix">
      <p class="control" v-if="selectedOptions.length > 0">
        <a href="#" role="button" class="button is-link" @click="clear"> Clear selected </a>
      </p>
      <p class="control">
        <input class="input" v-model="filterText" type="text" placeholder="Filter list">
      </p>
  </header>
  <div class="select-list" v-if="filteredOptions.length > 0">
    <toggle-button
            v-for="option in filteredOptions"
            :text="option.label"
            :value="option.value"
            :selected="option.selected"
            class="select-item"
            @toggle="onToggle($event)"
            ></toggle-button>
  </div>
  <div v-else>No items to display</div>
</div>
  `,
  data() {
    return {
      filterText: '',
      selectedOptions: this.selected
    }
  },
  props: ['options', 'selected'],
  methods: {
    onToggle(option) {

      if (option.selected) {

        this.selectedOptions.push(option.value);
      } else {

        this.selectedOptions.splice(this.selectedOptions.indexOf(option.value), 1);
      }

      this.$emit('change', {
        changed: option,
        selected: this.selectedOptions
      });
    },
    clear() {
      this.selectedOptions = [];
      this.$emit('change', {
        changed: null,
        selected: []
      });
    }
  },
  computed: {
    filteredOptions() {
      var visibleOptions = [],
        filterText = this.filterText.trim().length > 0 ? this.filterText.toLowerCase() : null;

      if (filterText) {

        visibleOptions = this.options.filter((option) => {
          let optWords = option.split(' ');

          return optWords.some((word) => {
            return word.toLowerCase().indexOf(filterText) === 0;
          });
        });

      } else {

        visibleOptions = this.options;
      }

      return visibleOptions.map((option) => {
        let label = '';

        if (filterText) {
          let searchStartIndex = option.toLowerCase().indexOf(filterText),
            filterPart = option.substring(searchStartIndex, searchStartIndex + filterText.length);

          label = option.replace(filterPart, `<b>${filterPart}</b>`);
        } else {
          label = option;
        }

        return {
          value: option,
          label,
          selected: this.selectedOptions.includes(option)
        }
      });
    }
  }
});

Vue.component('select-dropdown', {
  template: `
<div class="select-dropdown">
  <a href="#"
    role="button"
    class="button is-primary"
    @click="toggle($event)"
  >
 {{buttonText}}
  </a>
  <transition name="slide-fade">
      <div class="select-dropdown-panel card arrow-box" v-show="panelOpen">
        <select-list
          ref="selectList"
          :options="options"
          :selected="selected"
          @change="onChange($event)"
          >

      </select-list>
      </div>
  </transition>
</div>
  `,
  data() {
    return {
      panelOpen: true,
      buttonText: this.label + ' ' + this.placeholder
    }
  },
  props: ['options', 'selected', 'label', 'placeholder'],
  methods: {
    toggle() {
      this.panelOpen = !this.panelOpen;
    },
    onChange(event) {

      this.setButtonText(event.selected);
      this.$emit(event);
    },
    setButtonText(selectedOptions) {

      if (selectedOptions.length === 0) {

        this.buttonText = this.label + ' ' + this.placeholder;
      } else {
        let text = this.placeholder.charAt(0).toUpperCase() + this.placeholder.slice(1) + ': ' + selectedOptions[0];

        if (selectedOptions.length > 1) {
          text += ' & ' + (selectedOptions.length - 1) + ' more'
        }

        this.buttonText = text;
      }
    }
  }
});



