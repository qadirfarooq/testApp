<template>
  <div id="PageHeader" class="page-header">
    <h4>
      <strong>{{title}}</strong>
      <small class="text-muted">{{subtitle}}</small>
    </h4>
    <slot></slot>
  </div>
</template>

<script>
 
export default  {
  name: 'PageHeader',
  props : 
          {
            title:"",
            subtitle:""
        } ,
 data: function () {
      return { 
                
        }
    }, 
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss">
.page-header {
  position: relative;
  /* margin: 10px 0; error*/
  padding: 0.6rem 2rem 0;
}

/* .page-header > h4 {
  font-size: 20px;
} */

.page-header small {
  display: block;
  text-transform: none;
  margin-top: 8px;
  margin-bottom: 10px;
  /* color: #9e9e9e; */
  /*line-height: 140%;*/
  min-height: 24px;
}

/* @media (max-width: 991.98px) {
  .page-header {
    padding: 0 20px;
  }
} */

/* @media (min-width: 768px) {
  .page-header {
    padding: 0 35px;
  }
} */
</style>
