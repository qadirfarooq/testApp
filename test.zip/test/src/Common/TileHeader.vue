<template>
  <div class="tile-header">
    <slot></slot>
  </div>
</template>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss">
.tile-header {
  position: relative;
  padding: 6px 30px;
  background-color: #eee;
  border-left: 5px solid #ff9800;
  color: #006537;
  font-weight: bold;
  border-radius: 2px 2px 0 0;
  /*border-right: 1px solid #00b5cc;*/
  /*border-top: 1px solid #00b5cc;*/
}
</style>
