<template>
  <!-- <TileCard>
    <template slot="header">
      {{title}}</template>
    <template slot="body">
      <div class="row">
        <slot></slot>
      </div>
    </template>
  </TileCard> -->
</template>

<script lang="ts">
//import TileCard from "@/components/TileCard.vue";

import { Component, Prop, Vue } from "vue-property-decorator";

//@Component({
 // components: {
 //   TileCard
 // }
//})
export default class TileTableCard extends Vue{
 // @Prop() private title!: string;
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss">
</style>
