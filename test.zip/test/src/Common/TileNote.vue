<template>
  <Tile>
    <div class="tile-note">
      <slot></slot>
    </div>
  </Tile>
</template>

<script >
import Tile from "../Common/Tile.vue"; 
export default  {
  name:'TileNote',
  data: function () {
      return { 
          showbar : false,           
          menuitems:"",   
          //isToggled: false,       
        }
    },
     components: {
    Tile
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss">
.tile-note {
  padding: 10px 30px;
  background-color: #efefef;
  border-radius: 2px;
  border-left: 5px solid #FBDD40;
}
</style>
