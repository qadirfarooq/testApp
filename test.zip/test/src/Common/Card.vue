<template>
  <div class="card mb-2">
    <slot></slot>
  </div>
</template>
<script>
 
export default  {
   name: 'Card',
  props : 
          {
            
        } ,
 data: function () {
      return { 
                
        }
    }, 
}
</script>
<!-- Add "scoped" attribute to limit CSS to this component only -->
<style>
.card {
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
}

@media print {
  .card {
    box-shadow: none !important;
    display: block;
  }
}
</style>