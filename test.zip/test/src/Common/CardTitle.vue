<template>
  <div class="card-title">
    <template v-if="num">
      <kbd>{{num}}</kbd>
    </template>{{title}}
  </div>
</template>

<script> 
export default   {
  name: 'PageHeader',
  props : 
          {
            num:"",
            title:""
        } ,
 data: function () {
      return { 
                
        }
    }, 
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss">
.card-title {
  font-size: 1.1em;
  font-weight: bold;
  margin-bottom: 10px;
}
</style>