<template> 
 <transition name="modal">
<div class="modal-mask">
      <div class="modal-wrapper">
        <div class="modal-container">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        <slot name="header">
              default header
            </slot>
      </div>
      <div class="modal-body">
       <slot name="body">
              default body
            </slot>
      </div>
      <div class="modal-footer">
          <slot name="footer">
               
            </slot>
   
      </div>
    </div>
  </div>
</div>
 </transition>
</template>
    
 
 
