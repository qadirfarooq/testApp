<template>
  <Tile>
    <TileHeader>
      <slot name="header"></slot>
    </TileHeader>
    <TileBody>
      <slot name="body"></slot>
    </TileBody>
  </Tile>
</template>

<script>
 
import Tile from "@/Common/Tile.vue";
import TileHeader from "@/Common/TileHeader.vue";
import TileBody from "@/Common/TileBody.vue"; 
export default  {
name: 'DentalHome',
  components: {
    Tile,
    TileHeader,
    TileBody
  }}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss">
</style>
