<template>
  <div class="tile-body">
    <slot></slot>
  </div>
</template>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss">
.tile-body {
  padding: 10px 30px;
  border-left: 5px solid #ff9800;
  background-color: rgba(243, 243, 243, 0.62);
  border-radius: 0 0 2px 2px;
}
</style>
