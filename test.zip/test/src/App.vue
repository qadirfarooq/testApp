<template>
  <div id="app"> 
     <component :is="layout">
        <router-view :layout.sync="layout"/>
    </component>  
<b-modal id="modal-sm" v-if="IsAuth"  size="md" title="Void Claims" v-model="isIdle"
 no-close-on-esc no-close-on-backdrop hide-header-close hide-header hide-footer> 
<div slot="default"> 
    <div class='alert alert-success' role='alert'> <ModalIdle v-if="isIdle" /> </div>
</div>  
</b-modal>
</div>
</template>
<script>
import ModalIdle from "@/Common/SessionModal";
import { BarLoader } from '@saeris/vue-spinners';
 
export default {
  name: 'app',
  props : 
          {
            
        } ,
  data () {
    return {
       layout: 'div',
        isToggled: false,
        // loading: true,
        // size: 250,
        // Ringsize: 40,
        // Risesize: 12,
        // margin :'2px',
        // unit: 'px',
        // color:'#bada55',
     } 
  }, 
   computed: {
     		isIdle() {
          return this.$store.state.idleVue.isIdle;
        },
        GetMainMenu () { 
            if(this.$store.getters.IsAuth)
            return this.$store.getters.GetMainMenu;
        },
         IsAuth () {  
             //alert(this.$store.getters.IsAuth)
             return this.$store.getters.IsAuth;
          },
          BuildMenu () {  
             //alert(this.$store.getters.IsAuth)
             return this.$store.getters.GetuildMainMenu;
          },
    },
     watch: { 
      IsAuth : function(val)
      {
        //alert(this.$store.getters.isAuth)
        return this.$store.getters.IsAuth;
      }, 
    },
    created (){
     this.$store.dispatch('AutoLogin');
    },
      mounted: function () {
    //   let recaptchaScript = document.createElement('script')
    //     recaptchaScript.setAttribute('src', 'http://w2ui.com/src/w2ui-1.5.rc1.min.js')
    //      document.head.appendChild(recaptchaScript)
    },
  components: {
   ModalIdle,
   BarLoader
  },
  methods: {
     closeMenu(val) {
    this.isToggled = val;
  }
  },
  //  mounted() {
  //   this.$root.$on('bv::modal::show', (bvEvent, modalId) => {
  //     console.log('Modal is about to be shown', bvEvent, modalId)
  //   })
  //}
}
</script> 
<style scoped>
.modalHeader {
  color: black;
  background-color: #00558C;
  text-align: center;
  font-weight: 600;
}
.info {
  background-color: #00558C;
}  
</style>